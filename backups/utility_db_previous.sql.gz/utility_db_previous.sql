--
-- PostgreSQL database dump
--

\restrict mISglS51c2JlVXjVNe3r96cox5rLAqcWd4hOfj6V5p4JFXBC4VGBMVNtpvOsMyS

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adjustments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adjustments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    period_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    description character varying NOT NULL,
    created_at timestamp without time zone,
    account_type character varying NOT NULL
);


ALTER TABLE public.adjustments OWNER TO postgres;

--
-- Name: adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adjustments_id_seq OWNER TO postgres;

--
-- Name: adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.adjustments_id_seq OWNED BY public.adjustments.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.periods (
    id integer NOT NULL,
    name character varying NOT NULL,
    is_active boolean,
    created_at timestamp without time zone,
    tariff_id integer
);


ALTER TABLE public.periods OWNER TO postgres;

--
-- Name: periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.periods_id_seq OWNER TO postgres;

--
-- Name: periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.periods_id_seq OWNED BY public.periods.id;


--
-- Name: readings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
)
PARTITION BY RANGE (created_at);


ALTER TABLE public.readings OWNER TO postgres;

--
-- Name: readings_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.readings_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.readings_id_seq1 OWNER TO postgres;

--
-- Name: readings_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.readings_id_seq1 OWNED BY public.readings.id;


--
-- Name: readings_2024; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2024 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2024 OWNER TO postgres;

--
-- Name: readings_2025; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2025 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2025 OWNER TO postgres;

--
-- Name: readings_2026; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2026 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2026 OWNER TO postgres;

--
-- Name: readings_2027; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2027 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2027 OWNER TO postgres;

--
-- Name: readings_2028; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2028 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2028 OWNER TO postgres;

--
-- Name: readings_2029; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2029 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2029 OWNER TO postgres;

--
-- Name: readings_2030; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2030 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2030 OWNER TO postgres;

--
-- Name: readings_2031; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2031 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2031 OWNER TO postgres;

--
-- Name: readings_2032; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2032 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2032 OWNER TO postgres;

--
-- Name: readings_2033; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2033 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2033 OWNER TO postgres;

--
-- Name: readings_2034; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2034 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2034 OWNER TO postgres;

--
-- Name: readings_2035; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2035 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2035 OWNER TO postgres;

--
-- Name: readings_default; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_default (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_default OWNER TO postgres;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value character varying NOT NULL,
    description character varying
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: tariffs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tariffs (
    id integer NOT NULL,
    is_active boolean,
    valid_from timestamp without time zone,
    maintenance_repair numeric(10,4),
    social_rent numeric(10,4),
    heating numeric(10,4),
    water_heating numeric(10,4),
    water_supply numeric(10,4),
    sewage numeric(10,4),
    waste_disposal numeric(10,4),
    electricity_per_sqm numeric(10,4),
    electricity_rate numeric(10,4),
    name character varying NOT NULL
);


ALTER TABLE public.tariffs OWNER TO postgres;

--
-- Name: tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tariffs_id_seq OWNER TO postgres;

--
-- Name: tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tariffs_id_seq OWNED BY public.tariffs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying NOT NULL,
    role character varying NOT NULL,
    dormitory character varying,
    workplace character varying,
    residents_count integer,
    total_room_residents integer,
    apartment_area numeric(10,2),
    is_deleted boolean,
    totp_secret character varying,
    is_initial_setup_done boolean DEFAULT false,
    telegram_id character varying,
    tariff_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: readings_2024; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2024 FOR VALUES FROM ('2024-01-01 00:00:00') TO ('2025-01-01 00:00:00');


--
-- Name: readings_2025; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2025 FOR VALUES FROM ('2025-01-01 00:00:00') TO ('2026-01-01 00:00:00');


--
-- Name: readings_2026; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2026 FOR VALUES FROM ('2026-01-01 00:00:00') TO ('2027-01-01 00:00:00');


--
-- Name: readings_2027; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2027 FOR VALUES FROM ('2027-01-01 00:00:00') TO ('2028-01-01 00:00:00');


--
-- Name: readings_2028; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2028 FOR VALUES FROM ('2028-01-01 00:00:00') TO ('2029-01-01 00:00:00');


--
-- Name: readings_2029; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2029 FOR VALUES FROM ('2029-01-01 00:00:00') TO ('2030-01-01 00:00:00');


--
-- Name: readings_2030; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2030 FOR VALUES FROM ('2030-01-01 00:00:00') TO ('2031-01-01 00:00:00');


--
-- Name: readings_2031; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2031 FOR VALUES FROM ('2031-01-01 00:00:00') TO ('2032-01-01 00:00:00');


--
-- Name: readings_2032; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2032 FOR VALUES FROM ('2032-01-01 00:00:00') TO ('2033-01-01 00:00:00');


--
-- Name: readings_2033; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2033 FOR VALUES FROM ('2033-01-01 00:00:00') TO ('2034-01-01 00:00:00');


--
-- Name: readings_2034; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2034 FOR VALUES FROM ('2034-01-01 00:00:00') TO ('2035-01-01 00:00:00');


--
-- Name: readings_2035; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2035 FOR VALUES FROM ('2035-01-01 00:00:00') TO ('2036-01-01 00:00:00');


--
-- Name: readings_default; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_default DEFAULT;


--
-- Name: adjustments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments ALTER COLUMN id SET DEFAULT nextval('public.adjustments_id_seq'::regclass);


--
-- Name: periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods ALTER COLUMN id SET DEFAULT nextval('public.periods_id_seq'::regclass);


--
-- Name: readings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ALTER COLUMN id SET DEFAULT nextval('public.readings_id_seq1'::regclass);


--
-- Name: tariffs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tariffs ALTER COLUMN id SET DEFAULT nextval('public.tariffs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: adjustments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adjustments (id, user_id, period_id, amount, description, created_at, account_type) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
dd2c767d6f06
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.periods (id, name, is_active, created_at, tariff_id) FROM stdin;
1	Начальный период	f	2026-03-05 20:51:16.417666	\N
\.


--
-- Data for Name: readings_2024; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2024 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2025; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2025 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2026; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2026 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
2	2026-03-05 21:26:11.748841	3	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
3	2026-03-05 21:26:11.748915	4	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
4	2026-03-05 21:26:11.748973	5	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
5	2026-03-05 21:26:11.749025	6	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
6	2026-03-05 21:26:11.749085	7	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
7	2026-03-05 21:26:11.749256	8	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
8	2026-03-05 21:26:11.749313	9	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
9	2026-03-05 21:26:11.749645	10	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
10	2026-03-05 21:26:11.749703	11	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
11	2026-03-05 21:26:11.749755	12	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
12	2026-03-05 21:26:11.749806	13	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
13	2026-03-05 21:26:11.749857	14	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
14	2026-03-05 21:26:11.749907	15	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
15	2026-03-05 21:26:11.749957	16	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
16	2026-03-05 21:26:11.750006	17	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
17	2026-03-05 21:26:11.750056	18	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
18	2026-03-05 21:26:11.750105	19	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
19	2026-03-05 21:26:11.750155	20	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
20	2026-03-05 21:26:11.750254	21	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
21	2026-03-05 21:26:11.75031	22	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
22	2026-03-05 21:26:11.75036	23	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
23	2026-03-05 21:26:11.750409	24	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
24	2026-03-05 21:26:11.750459	25	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
25	2026-03-05 21:26:11.750535	26	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
26	2026-03-05 21:26:11.750655	27	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
27	2026-03-05 21:26:11.75072	28	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
28	2026-03-05 21:26:11.750795	29	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
29	2026-03-05 21:26:11.750877	30	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
30	2026-03-05 21:26:11.750944	31	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
31	2026-03-05 21:26:11.750999	32	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
32	2026-03-05 21:26:11.751049	33	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
33	2026-03-05 21:26:11.751105	34	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
34	2026-03-05 21:26:11.751156	35	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
35	2026-03-05 21:26:11.751209	36	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
36	2026-03-05 21:26:11.751263	37	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
37	2026-03-05 21:26:11.751313	38	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
38	2026-03-05 21:26:11.751362	39	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
39	2026-03-05 21:26:11.751425	40	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
40	2026-03-05 21:26:11.751478	41	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
41	2026-03-05 21:26:11.751528	42	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
42	2026-03-05 21:26:11.751577	43	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
43	2026-03-05 21:26:11.75168	44	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
44	2026-03-05 21:26:11.751792	45	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
45	2026-03-05 21:26:11.751873	46	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
46	2026-03-05 21:26:11.751933	47	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
47	2026-03-05 21:26:11.751984	48	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
48	2026-03-05 21:26:11.75204	49	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
49	2026-03-05 21:26:11.752094	50	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
50	2026-03-05 21:26:11.752202	51	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
51	2026-03-05 21:26:11.752261	52	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
52	2026-03-05 21:26:11.752319	53	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
53	2026-03-05 21:26:11.75237	54	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
54	2026-03-05 21:26:11.752419	55	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
55	2026-03-05 21:26:11.752483	56	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
56	2026-03-05 21:26:11.752537	57	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
57	2026-03-05 21:26:11.752598	58	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
58	2026-03-05 21:26:11.752652	59	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
59	2026-03-05 21:26:11.752704	60	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
60	2026-03-05 21:26:11.752764	61	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
61	2026-03-05 21:26:11.752817	62	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
62	2026-03-05 21:26:11.752872	63	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
63	2026-03-05 21:26:11.752925	64	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
64	2026-03-05 21:26:11.752982	65	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
65	2026-03-05 21:26:11.753035	66	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
66	2026-03-05 21:26:11.753085	67	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
67	2026-03-05 21:26:11.753135	68	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
68	2026-03-05 21:26:11.753234	69	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
69	2026-03-05 21:26:11.753289	70	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
70	2026-03-05 21:26:11.753339	71	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
71	2026-03-05 21:26:11.753392	72	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
72	2026-03-05 21:26:11.753442	73	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
73	2026-03-05 21:26:11.753491	74	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
74	2026-03-05 21:26:11.753544	75	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
75	2026-03-05 21:26:11.753597	76	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
76	2026-03-05 21:26:11.753647	77	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
77	2026-03-05 21:26:11.7537	78	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
78	2026-03-05 21:26:11.75375	79	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
79	2026-03-05 21:26:11.7538	80	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
80	2026-03-05 21:26:11.753849	81	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
81	2026-03-05 21:26:11.753901	82	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
82	2026-03-05 21:26:11.75395	83	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
83	2026-03-05 21:26:11.753999	84	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
84	2026-03-05 21:26:11.754052	85	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
85	2026-03-05 21:26:11.754101	86	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
86	2026-03-05 21:26:11.754196	87	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
87	2026-03-05 21:26:11.754342	88	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
88	2026-03-05 21:26:11.754402	89	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
89	2026-03-05 21:26:11.754453	90	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
90	2026-03-05 21:26:11.75451	91	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
91	2026-03-05 21:26:11.754565	92	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
92	2026-03-05 21:26:11.754614	93	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
93	2026-03-05 21:26:11.754667	94	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
94	2026-03-05 21:26:11.754717	95	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
95	2026-03-05 21:26:11.754767	96	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
96	2026-03-05 21:26:11.754819	97	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
97	2026-03-05 21:26:11.754869	98	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
98	2026-03-05 21:26:11.754918	99	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
99	2026-03-05 21:26:11.754967	100	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
100	2026-03-05 21:26:11.755019	101	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
101	2026-03-05 21:26:11.755083	102	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
102	2026-03-05 21:26:11.755137	103	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
103	2026-03-05 21:26:11.755235	104	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
104	2026-03-05 21:26:11.75529	105	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
105	2026-03-05 21:26:11.755339	106	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
106	2026-03-05 21:26:11.755406	107	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
107	2026-03-05 21:26:11.75546	108	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
108	2026-03-05 21:26:11.75551	109	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
109	2026-03-05 21:26:11.755565	110	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
110	2026-03-05 21:26:11.755615	111	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
111	2026-03-05 21:26:11.755678	112	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
112	2026-03-05 21:26:11.755833	113	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
113	2026-03-05 21:26:11.755889	114	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
114	2026-03-05 21:26:11.755939	115	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
115	2026-03-05 21:26:11.755987	116	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
116	2026-03-05 21:26:11.756054	117	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
117	2026-03-05 21:26:11.756108	118	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
118	2026-03-05 21:26:11.756197	119	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
119	2026-03-05 21:26:11.756262	120	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
120	2026-03-05 21:26:11.756313	121	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
121	2026-03-05 21:26:11.756377	122	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
122	2026-03-05 21:26:11.756438	123	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
123	2026-03-05 21:26:11.756488	124	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
124	2026-03-05 21:26:11.756537	125	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
125	2026-03-05 21:26:11.75659	126	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
126	2026-03-05 21:26:11.75664	127	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
127	2026-03-05 21:26:11.7567	128	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
128	2026-03-05 21:26:11.756758	129	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
129	2026-03-05 21:26:11.756808	130	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
130	2026-03-05 21:26:11.756857	131	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
131	2026-03-05 21:26:11.75692	132	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
132	2026-03-05 21:26:11.756974	133	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
133	2026-03-05 21:26:11.757024	134	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
134	2026-03-05 21:26:11.757079	135	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
135	2026-03-05 21:26:11.757135	136	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
136	2026-03-05 21:26:11.757225	137	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
137	2026-03-05 21:26:11.757294	138	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
138	2026-03-05 21:26:11.757362	139	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
139	2026-03-05 21:26:11.757412	140	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
140	2026-03-05 21:26:11.757461	141	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
141	2026-03-05 21:26:11.7576	142	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
142	2026-03-05 21:26:11.75767	143	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
143	2026-03-05 21:26:11.757725	144	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
144	2026-03-05 21:26:11.75778	145	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
145	2026-03-05 21:26:11.75783	146	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
146	2026-03-05 21:26:11.757879	147	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
147	2026-03-05 21:26:11.757943	148	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
148	2026-03-05 21:26:11.757996	149	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
149	2026-03-05 21:26:11.758046	150	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
150	2026-03-05 21:26:11.7581	151	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
151	2026-03-05 21:26:11.758185	152	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
152	2026-03-05 21:26:11.758262	153	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
153	2026-03-05 21:26:11.758317	154	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
154	2026-03-05 21:26:11.758372	155	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
155	2026-03-05 21:26:11.758422	156	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
156	2026-03-05 21:26:11.758471	157	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
157	2026-03-05 21:26:11.758534	158	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
158	2026-03-05 21:26:11.758587	159	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
159	2026-03-05 21:26:11.758637	160	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
160	2026-03-05 21:26:11.758692	161	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
161	2026-03-05 21:26:11.758751	162	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
162	2026-03-05 21:26:11.758804	163	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
163	2026-03-05 21:26:11.758858	164	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
164	2026-03-05 21:26:11.758908	165	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
165	2026-03-05 21:26:11.758956	166	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
166	2026-03-05 21:26:11.759017	167	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
167	2026-03-05 21:26:11.75907	168	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
168	2026-03-05 21:26:11.759119	169	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
169	2026-03-05 21:26:11.759209	170	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
170	2026-03-05 21:26:11.759272	171	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
171	2026-03-05 21:26:11.759409	172	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
172	2026-03-05 21:26:11.759475	173	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
173	2026-03-05 21:26:11.759532	174	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
174	2026-03-05 21:26:11.759582	175	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
175	2026-03-05 21:26:11.759636	176	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
176	2026-03-05 21:26:11.759707	177	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
177	2026-03-05 21:26:11.759761	178	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
178	2026-03-05 21:26:11.75981	179	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
179	2026-03-05 21:26:11.759863	180	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
180	2026-03-05 21:26:11.759913	181	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
181	2026-03-05 21:26:11.759972	182	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
182	2026-03-05 21:26:11.760029	183	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
183	2026-03-05 21:26:11.760079	184	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
184	2026-03-05 21:26:11.760128	185	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
185	2026-03-05 21:26:11.760253	186	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
186	2026-03-05 21:26:11.760322	187	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
187	2026-03-05 21:26:11.760377	188	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
188	2026-03-05 21:26:11.760426	189	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
189	2026-03-05 21:26:11.76048	190	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
190	2026-03-05 21:26:11.760529	191	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
191	2026-03-05 21:26:11.760588	192	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
192	2026-03-05 21:26:11.760646	193	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
193	2026-03-05 21:26:11.760696	194	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
194	2026-03-05 21:26:11.760754	195	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
195	2026-03-05 21:26:11.760972	196	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
196	2026-03-05 21:26:11.761026	197	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
197	2026-03-05 21:26:11.761075	198	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
198	2026-03-05 21:26:11.761132	199	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
199	2026-03-05 21:26:11.761224	200	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
200	2026-03-05 21:26:11.761279	201	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
201	2026-03-05 21:26:11.761472	202	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
202	2026-03-05 21:26:11.761544	203	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
203	2026-03-05 21:26:11.761596	204	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
204	2026-03-05 21:26:11.761715	205	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
205	2026-03-05 21:26:11.761771	206	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
206	2026-03-05 21:26:11.761834	207	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
207	2026-03-05 21:26:11.761889	208	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
208	2026-03-05 21:26:11.761944	209	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
209	2026-03-05 21:26:11.761994	210	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
210	2026-03-05 21:26:11.762043	211	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
211	2026-03-05 21:26:11.762106	212	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
212	2026-03-05 21:26:11.762222	213	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
213	2026-03-05 21:26:11.762284	214	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
214	2026-03-05 21:26:11.762343	215	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
215	2026-03-05 21:26:11.762393	216	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
216	2026-03-05 21:26:11.762463	217	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
217	2026-03-05 21:26:11.762528	218	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
218	2026-03-05 21:26:11.762583	219	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
219	2026-03-05 21:26:11.762632	220	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
220	2026-03-05 21:26:11.762685	221	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
221	2026-03-05 21:26:11.762735	222	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
222	2026-03-05 21:26:11.762795	223	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
223	2026-03-05 21:26:11.762852	224	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
224	2026-03-05 21:26:11.762908	225	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
225	2026-03-05 21:26:11.762957	226	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
226	2026-03-05 21:26:11.763007	227	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
227	2026-03-05 21:26:11.763074	228	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
228	2026-03-05 21:26:11.763145	229	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
229	2026-03-05 21:26:11.763238	230	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
230	2026-03-05 21:26:11.763297	231	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
231	2026-03-05 21:26:11.763347	232	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
232	2026-03-05 21:26:11.763485	233	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
233	2026-03-05 21:26:11.763558	234	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
234	2026-03-05 21:26:11.763614	235	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
235	2026-03-05 21:26:11.763673	236	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
236	2026-03-05 21:26:11.763726	237	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
237	2026-03-05 21:26:11.763797	238	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
238	2026-03-05 21:26:11.763861	239	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
239	2026-03-05 21:26:11.763917	240	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
240	2026-03-05 21:26:11.764017	241	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
241	2026-03-05 21:26:11.764099	242	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
242	2026-03-05 21:26:11.764212	243	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
243	2026-03-05 21:26:11.764282	244	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
244	2026-03-05 21:26:11.764333	245	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
245	2026-03-05 21:26:11.764396	246	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
246	2026-03-05 21:26:11.764455	247	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
247	2026-03-05 21:26:11.764506	248	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
248	2026-03-05 21:26:11.764555	249	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
249	2026-03-05 21:26:11.76461	250	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
250	2026-03-05 21:26:11.76467	251	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
251	2026-03-05 21:26:11.764723	252	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
252	2026-03-05 21:26:11.764777	253	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
253	2026-03-05 21:26:11.764827	254	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
254	2026-03-05 21:26:11.764876	255	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
255	2026-03-05 21:26:11.764939	256	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
256	2026-03-05 21:26:11.765001	257	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
257	2026-03-05 21:26:11.765069	258	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
258	2026-03-05 21:26:11.765132	259	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
259	2026-03-05 21:26:11.765236	260	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
260	2026-03-05 21:26:11.765408	261	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
261	2026-03-05 21:26:11.765474	262	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
262	2026-03-05 21:26:11.765531	263	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
263	2026-03-05 21:26:11.765581	264	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
264	2026-03-05 21:26:11.76563	265	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
265	2026-03-05 21:26:11.765726	266	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
266	2026-03-05 21:26:11.7658	267	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
267	2026-03-05 21:26:11.765864	268	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
268	2026-03-05 21:26:11.765927	269	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
269	2026-03-05 21:26:11.765986	270	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
270	2026-03-05 21:26:11.766035	271	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
271	2026-03-05 21:26:11.766103	272	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
272	2026-03-05 21:26:11.766154	273	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
273	2026-03-05 21:26:11.766203	274	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
274	2026-03-05 21:26:11.766256	275	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
275	2026-03-05 21:26:11.766316	276	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
276	2026-03-05 21:26:11.76637	277	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
277	2026-03-05 21:26:11.766426	278	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
278	2026-03-05 21:26:11.766477	279	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
279	2026-03-05 21:26:11.766528	280	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
280	2026-03-05 21:26:11.766578	281	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
281	2026-03-05 21:26:11.766648	282	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
282	2026-03-05 21:26:11.76675	283	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
283	2026-03-05 21:26:11.766829	284	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
284	2026-03-05 21:26:11.766888	285	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
285	2026-03-05 21:26:11.766939	286	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
286	2026-03-05 21:26:11.766988	287	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
287	2026-03-05 21:26:11.767043	288	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
288	2026-03-05 21:26:11.767179	289	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
289	2026-03-05 21:26:11.767245	290	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
290	2026-03-05 21:26:11.767308	291	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
291	2026-03-05 21:26:11.767359	292	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
292	2026-03-05 21:26:11.767413	293	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
293	2026-03-05 21:26:11.767478	294	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
294	2026-03-05 21:26:11.767532	295	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
295	2026-03-05 21:26:11.767582	296	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
296	2026-03-05 21:26:11.767631	297	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
297	2026-03-05 21:26:11.767728	298	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
298	2026-03-05 21:26:11.767794	299	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
299	2026-03-05 21:26:11.767869	300	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
300	2026-03-05 21:26:11.767929	301	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
301	2026-03-05 21:26:11.767979	302	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
302	2026-03-05 21:26:11.768029	303	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
303	2026-03-05 21:26:11.768091	304	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
304	2026-03-05 21:26:11.76815	305	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
305	2026-03-05 21:26:11.768204	306	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
306	2026-03-05 21:26:11.768259	307	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
307	2026-03-05 21:26:11.768309	308	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
308	2026-03-05 21:26:11.768358	309	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
309	2026-03-05 21:26:11.768419	310	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
310	2026-03-05 21:26:11.768472	311	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
311	2026-03-05 21:26:11.768534	312	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
312	2026-03-05 21:26:11.76859	313	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
313	2026-03-05 21:26:11.768649	314	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
314	2026-03-05 21:26:11.768747	315	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
315	2026-03-05 21:26:11.768803	316	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
316	2026-03-05 21:26:11.768862	317	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
317	2026-03-05 21:26:11.768912	318	1	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	AUTO_GENERATED	t
1	2026-03-05 21:20:41.545539	2	1	111.000	111.000	11111.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	55555.00	0.00	55555.00	0.00	0.00	55555.00	0.00	0.00	0.00	0.00	0.00	\N	t
\.


--
-- Data for Name: readings_2027; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2027 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2028; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2028 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2029; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2029 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2030; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2030 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2031; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2031 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2032; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2032 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2033; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2033 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2034; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2034 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2035; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2035 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_default; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_default (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (key, value, description) FROM stdin;
submission_start_day	20	День начала приема показаний
submission_end_day	25	День окончания приема показаний
\.


--
-- Data for Name: tariffs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tariffs (id, is_active, valid_from, maintenance_repair, social_rent, heating, water_heating, water_supply, sewage, waste_disposal, electricity_per_sqm, electricity_rate, name) FROM stdin;
1	t	2026-03-05 20:51:16.398966	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	5.0000	Базовый тариф
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, hashed_password, role, dormitory, workplace, residents_count, total_room_residents, apartment_area, is_deleted, totp_secret, is_initial_setup_done, telegram_id, tariff_id) FROM stdin;
1	admin	$argon2id$v=19$m=65536,t=2,p=2$hJCSMoYwxhjDGONcK2XsXQ$J4NEWWkoHUOHZ4aosWtWDJPeBqWs8IxHR4eigpRRn6g	accountant	\N	\N	1	1	0.00	f	\N	t	\N	\N
2	Емельяненко Михаил Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	49.50	f	\N	t	\N	\N
3	Матус Антон Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.50	f	\N	f	\N	\N
4	Жданов Николай Федорович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.00	f	\N	f	\N	\N
5	Косенко Екатерина Васильевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	2	2	68.60	f	\N	f	\N	\N
6	Лушников Анатолий Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	66.40	f	\N	f	\N	\N
7	Алискеров Тимур Шихрагимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	63.50	f	\N	f	\N	\N
8	Корепанов Андрей Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.00	f	\N	f	\N	\N
9	Орлов Алексей Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	43.70	f	\N	f	\N	\N
10	Лагутин Николай Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	49.00	f	\N	f	\N	\N
11	Семенцов Алексей Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	45.80	f	\N	f	\N	\N
12	Почекунин Александр Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	48.90	f	\N	f	\N	\N
13	Бельков Юрий Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.90	f	\N	f	\N	\N
14	Осипов Павел Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	66.20	f	\N	f	\N	\N
15	Каримов Булат Ильфатович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	68.50	f	\N	f	\N	\N
16	Мальков Дмитрий Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	60.30	f	\N	f	\N	\N
17	Олейник Елена Александровна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	ЦА	1	1	63.20	f	\N	f	\N	\N
18	Карачевцев Алексей Анатольевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.90	f	\N	f	\N	\N
19	Покидин Николай Валентинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	ЦА	1	1	44.30	f	\N	f	\N	\N
20	Лучка Александр Павлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	ЦА	2	2	64.90	f	\N	f	\N	\N
21	Волков Владимир Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.80	f	\N	f	\N	\N
22	Пушкарев Александр Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.30	f	\N	f	\N	\N
23	Резунов Роман Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	3	3	47.10	f	\N	f	\N	\N
24	Керн Ольга Алексеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	49.40	f	\N	f	\N	\N
25	Пегарьков Александр Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.90	f	\N	f	\N	\N
26	Иваницкий Константин Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.70	f	\N	f	\N	\N
27	Арцаев Руслан Султанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	66.40	f	\N	f	\N	\N
28	Вагидов Руслан Мирзалиевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	66.80	f	\N	f	\N	\N
29	Панасецкий Петр Петрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.10	f	\N	f	\N	\N
30	Панкратов Иван Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	45.80	f	\N	f	\N	\N
31	Семченкова Валерия Андреевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	НЦУКС	3	3	64.30	f	\N	f	\N	\N
32	Кешоков Азамат Ахмедович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	49.10	f	\N	f	\N	\N
33	Душин Дмитрий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.90	f	\N	f	\N	\N
34	Завацкий Алексей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	45.90	f	\N	f	\N	\N
35	Семенченко Никита Олегович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	46.40	f	\N	f	\N	\N
36	Прокопенко Максим Борисович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.60	f	\N	f	\N	\N
37	Шевченко Александр Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.70	f	\N	f	\N	\N
38	Черняев Максим Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	61.90	f	\N	f	\N	\N
39	Смирнов Александр Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	63.90	f	\N	f	\N	\N
40	Мироненко Александр Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.50	f	\N	f	\N	\N
41	Андросов Сергей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.90	f	\N	f	\N	\N
42	Ильин Никита Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.80	f	\N	f	\N	\N
43	Ревин Денис Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.40	f	\N	f	\N	\N
44	Глушакова Анастасия Олеговна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.80	f	\N	f	\N	\N
45	Еремин Павел Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	45.70	f	\N	f	\N	\N
46	Резевский Виктор Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.20	f	\N	f	\N	\N
47	Айвазов Халил Кашалыевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.30	f	\N	f	\N	\N
48	Азимов Виталий Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.90	f	\N	f	\N	\N
49	Таранюк Алексей Валерьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	61.90	f	\N	f	\N	\N
50	Гюрджян Сергей Левонович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.80	f	\N	f	\N	\N
51	Платов Денис Максимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.50	f	\N	f	\N	\N
52	Мурадов Руслан Фикретович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.20	f	\N	f	\N	\N
53	Мурнаев Никита Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	48.00	f	\N	f	\N	\N
54	Дибирасулаев Тимур Магамедович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	48.40	f	\N	f	\N	\N
55	Кузнецов Виталий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	46.30	f	\N	f	\N	\N
56	Запарин Михаил Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	47.30	f	\N	f	\N	\N
57	Кудрявцев Владимир Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.30	f	\N	f	\N	\N
58	Кулешов Максим Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	28.90	f	\N	f	\N	\N
59	Юриков Даниил Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.50	f	\N	f	\N	\N
60	Попков Максим Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.20	f	\N	f	\N	\N
61	Рыбальченко Сергей Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	42.10	f	\N	f	\N	\N
62	Атиков Илия Рафаэльевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.20	f	\N	f	\N	\N
63	Джиоев Георгий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	15.10	f	\N	f	\N	\N
64	Осипов Руслан Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	47.30	f	\N	f	\N	\N
65	Струкова Ольга Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.60	f	\N	f	\N	\N
66	Седякин Игорь Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	48.10	f	\N	f	\N	\N
67	Крючков Артем Геннадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.00	f	\N	f	\N	\N
68	Прохоренко Константин Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.10	f	\N	f	\N	\N
69	Кармов Беслан Ризуанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.70	f	\N	f	\N	\N
70	Снегирева Людмила Валерьевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	2	2	32.40	f	\N	f	\N	\N
71	Хабибулин Данила Романович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	3	3	28.70	f	\N	f	\N	\N
72	Нурмагамедов Абдулнасир Магомедович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.70	f	\N	f	\N	\N
73	Дуденко Максим Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.00	f	\N	f	\N	\N
74	Соловьев Евгений Витальевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.80	f	\N	f	\N	\N
75	Смирнов Максим Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.90	f	\N	f	\N	\N
76	Левшин Александр Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.90	f	\N	f	\N	\N
77	Закамалдин Андрей Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.60	f	\N	f	\N	\N
78	Ярощук Александр Павлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.50	f	\N	f	\N	\N
79	Беленьких Андрей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.80	f	\N	f	\N	\N
80	Чернов Сергей Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.40	f	\N	f	\N	\N
81	Чаптыков Роман Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	49.90	f	\N	f	\N	\N
82	Чистяков Николай Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	АД	3	3	29.00	f	\N	f	\N	\N
83	Шорошева Наталья Валентиновна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	2	2	31.10	f	\N	f	\N	\N
84	Муртазина Алия Мифтяхотдиновна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.40	f	\N	f	\N	\N
85	Тихонова Оксана Игоревна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	НТУ	3	3	32.70	f	\N	f	\N	\N
86	Гребенькова Ксения Юрьевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.30	f	\N	f	\N	\N
87	Сабаткоев Казбек Аланович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.50	f	\N	f	\N	\N
88	Колемагин Дмитрий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.60	f	\N	f	\N	\N
89	Фахреев Альберт Тимурович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	33.70	f	\N	f	\N	\N
90	Сорокин Александр Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.30	f	\N	f	\N	\N
91	Сорокин Сергей Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.20	f	\N	f	\N	\N
92	Хизанашвили Михаил Ясонович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.10	f	\N	f	\N	\N
93	Безродний Сергей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.20	f	\N	f	\N	\N
94	Мясников Даниил Геннадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.10	f	\N	f	\N	\N
95	Косынкин Даниил Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	33.20	f	\N	f	\N	\N
96	Данилов Дмитрий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.60	f	\N	f	\N	\N
97	Дронин Константин Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.90	f	\N	f	\N	\N
98	Анюхин Роман Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.80	f	\N	f	\N	\N
99	Писарев Александр Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	44.60	f	\N	f	\N	\N
100	Дегтярев Владислав Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	47.20	f	\N	f	\N	\N
101	Подловилин Давид Витальевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	3	3	27.70	f	\N	f	\N	\N
102	Катунькина Иннеса Ивановна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.50	f	\N	f	\N	\N
103	Грибач Виталий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	ЦА	1	1	31.20	f	\N	f	\N	\N
104	Пинских Юрий Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.50	f	\N	f	\N	\N
105	Бендас Вадим Родионович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.60	f	\N	f	\N	\N
106	Тюрин Александр Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.10	f	\N	f	\N	\N
107	Куликов Сергей Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.60	f	\N	f	\N	\N
108	Шуянов Иван Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.20	f	\N	f	\N	\N
109	Вастаев Валерий Сидорович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.70	f	\N	f	\N	\N
110	Лапатько Кирилл Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.10	f	\N	f	\N	\N
111	Кочелаев Денис Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.80	f	\N	f	\N	\N
112	Приходченков Игорь Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.50	f	\N	f	\N	\N
113	Кондратьева Мария Александровна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	27.10	f	\N	f	\N	\N
114	Степанков Дмитрий Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.20	f	\N	f	\N	\N
115	Ермолаев Игорь Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	15.10	f	\N	f	\N	\N
116	Рудь Руслан Рамазанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	15.10	f	\N	f	\N	\N
117	Смолин Кирилл Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.10	f	\N	f	\N	\N
118	Мальков Сергей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	3	3	14.55	f	\N	f	\N	\N
119	Тищенко Максим Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	14.55	f	\N	f	\N	\N
120	Хруберов Кирилл Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	33.10	f	\N	f	\N	\N
121	Залитдинов Шарапутдин Залитдинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	11.03	f	\N	f	\N	\N
122	Война Владислав Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	33.60	f	\N	f	\N	\N
123	Лисник Кирилл Борисович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	8.40	f	\N	f	\N	\N
124	Попелов Алексей Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	8.40	f	\N	f	\N	\N
125	Жуков Савелий Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	8.40	f	\N	f	\N	\N
126	Серый Артем Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	16.80	f	\N	f	\N	\N
127	Тарасов Валерий Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	16.80	f	\N	f	\N	\N
128	Том Богдан Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	10.66	f	\N	f	\N	\N
129	Кудинов Максим Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	10.66	f	\N	f	\N	\N
130	Арутюнян Арман Горович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	10.66	f	\N	f	\N	\N
131	Смирнов Даниил Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	14.80	f	\N	f	\N	\N
132	Чекалин Александр Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	34.00	f	\N	f	\N	\N
133	Тер-Саакян Даниил Витальевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	11.34	f	\N	f	\N	\N
134	Легконогих Александр Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	11.34	f	\N	f	\N	\N
135	Югай Арсений Анатольевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	\N	1	1	19.64	f	\N	f	\N	\N
136	Усатая Елена Павловна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	45.00	f	\N	f	\N	\N
137	Никитина Екатерина Александровна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	36.00	f	\N	f	\N	\N
138	Агуреев Валерий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	13.60	f	\N	f	\N	\N
139	Бирюлькин Михаил Анатольевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	36.00	f	\N	f	\N	\N
140	Сивицкая Елена Олеговна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	37.00	f	\N	f	\N	\N
141	Конопихин Евгений Леонидович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	16.00	f	\N	f	\N	\N
142	Приходько Алена Игоревна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	1	1	31.00	f	\N	f	\N	\N
143	Умнов Михаил Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	ОК	Лидер	1	1	46.10	f	\N	f	\N	\N
144	Меликов Санжарбек Ашуралиевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	ОК	Лидер	1	1	23.05	f	\N	f	\N	\N
145	Матисон Игорь Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	61.80	f	\N	f	\N	\N
146	Белов Иван Максимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	8.83	f	\N	f	\N	\N
147	Терехов Максим Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	8.83	f	\N	f	\N	\N
148	Рыбин Павел Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	15.50	f	\N	f	\N	\N
149	Гуков Эльдар Альбертович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	8.83	f	\N	f	\N	\N
150	Прасков Николай Валентинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	49.50	f	\N	f	\N	\N
151	Власов Станислав Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	24.75	f	\N	f	\N	\N
152	Очетов Евгений Леонтьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	50.30	f	\N	f	\N	\N
153	Шаргаев Дмитрий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	16.77	f	\N	f	\N	\N
154	Кондрашов Герман Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	16.77	f	\N	f	\N	\N
155	Гурин Дмитрий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	44.80	f	\N	f	\N	\N
156	Тихон Михаил Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	14.94	f	\N	f	\N	\N
157	Серебряков Валерий Аркадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	15.50	f	\N	f	\N	\N
158	Муравьев Павел Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	44.90	f	\N	f	\N	\N
159	Шелюков Виктор Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	14.97	f	\N	f	\N	\N
160	Мороз Артем Анатольевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	15.95	f	\N	f	\N	\N
161	Гасымов Рамиз Рассадин Оглы	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	\N	1	1	42.60	f	\N	f	\N	\N
162	Акбашев Ильфат Ильдарович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	14.20	f	\N	f	\N	\N
163	Соколов Илья Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	38.10	f	\N	f	\N	\N
164	Аникин Альберт Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	9.53	f	\N	f	\N	\N
165	Буйнов Марк Геннадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	35.20	f	\N	f	\N	\N
166	Абдулкеримов Арсен Гайдарович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	11.74	f	\N	f	\N	\N
167	Смирнов Руслан Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	11.74	f	\N	f	\N	\N
168	Хрипачев Андрей Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	47.64	f	\N	f	\N	\N
169	Устимов Роман Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	50.72	f	\N	f	\N	\N
170	Оболенская Кира Олеговна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.60	f	\N	f	\N	\N
171	Никольский Дмитрий Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.70	f	\N	f	\N	\N
172	Дарий Андрей Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.00	f	\N	f	\N	\N
173	Солоденко Роман Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	46.90	f	\N	f	\N	\N
174	Баскаков Андрей Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.70	f	\N	f	\N	\N
175	Шаховский Дмитрий Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	30.50	f	\N	f	\N	\N
176	Валкович Андрей Петрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.30	f	\N	f	\N	\N
177	Безруков Михаил Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.40	f	\N	f	\N	\N
178	Калачев Вадим Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	47.40	f	\N	f	\N	\N
179	Токтаев Илья Олегович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.00	f	\N	f	\N	\N
180	Муталиев Ахмед Русланович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	52.50	f	\N	f	\N	\N
181	Бульдина Наждежда Юрьевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	ЦСИ	3	3	29.00	f	\N	f	\N	\N
182	Семкина Вера Васильевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	33.60	f	\N	f	\N	\N
183	Михалева Алена Борисовна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	35.60	f	\N	f	\N	\N
184	Кривушин Илья Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	35.20	f	\N	f	\N	\N
185	Квасникова Вера Михайловна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	35.70	f	\N	f	\N	\N
186	Федоров Иван Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.20	f	\N	f	\N	\N
187	Сафаров Сахиб Гаджибаба-оглу	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	3	3	34.40	f	\N	f	\N	\N
188	Саттарова Ряися Маратовна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	33.00	f	\N	f	\N	\N
189	Сергиенко Оксана Геннадьевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	45.00	f	\N	f	\N	\N
190	Быков Захар Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	29.90	f	\N	f	\N	\N
191	Ширяев Андрей Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.40	f	\N	f	\N	\N
192	Смирнов Максим Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	48.30	f	\N	f	\N	\N
193	Абукаров Марат Мурадович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	30.90	f	\N	f	\N	\N
194	Халваши Георгий Малхазович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	30.20	f	\N	f	\N	\N
195	Звезда Антон Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.30	f	\N	f	\N	\N
196	Тверяхин Вадим Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.20	f	\N	f	\N	\N
197	Кононов Степан Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.70	f	\N	f	\N	\N
198	Джапбаров Осман Тимирбулатович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.20	f	\N	f	\N	\N
199	Шмыров Вадим Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.60	f	\N	f	\N	\N
200	Сулейманов Халид Рамазанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	28.90	f	\N	f	\N	\N
201	Никитин Андрей Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.50	f	\N	f	\N	\N
202	Марченко Алексей Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	35.10	f	\N	f	\N	\N
203	Гагиев Давид Роландович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.90	f	\N	f	\N	\N
204	Науменко Сергей Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	35.70	f	\N	f	\N	\N
205	Никитин Алексей Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	35.30	f	\N	f	\N	\N
206	Маняев Иван Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.80	f	\N	f	\N	\N
207	Степаненко Андрей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.00	f	\N	f	\N	\N
208	Байков Николай Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	46.70	f	\N	f	\N	\N
209	Теплоухов Никита Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.50	f	\N	f	\N	\N
210	Мимонова Виктория Владимировна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	3	3	29.70	f	\N	f	\N	\N
211	Шпаков Анатолий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.30	f	\N	f	\N	\N
212	Назаретян Мнацакан Генрихович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	48.70	f	\N	f	\N	\N
213	Степанков Михаил Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.00	f	\N	f	\N	\N
214	Гареев Артур Радифович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	НЦУКС	3	3	31.40	f	\N	f	\N	\N
215	Ананьева Ирина Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	34.20	f	\N	f	\N	\N
216	Ланина Маргарита Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.10	f	\N	f	\N	\N
217	Селезнева Валентина Ивановна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	33.80	f	\N	f	\N	\N
218	Неметуллаева Арзу Рафиковна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	33.70	f	\N	f	\N	\N
219	Азязов Александр Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	28.30	f	\N	f	\N	\N
220	Шигапов Ришат Фаридович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.00	f	\N	f	\N	\N
221	Григорян Евгений Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.50	f	\N	f	\N	\N
222	Курносов Евгений Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.70	f	\N	f	\N	\N
223	Шумилова Лилия Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.10	f	\N	f	\N	\N
224	Хайбуллин Артем Ильсурович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.50	f	\N	f	\N	\N
225	Галко Семен Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	46.40	f	\N	f	\N	\N
226	Похиленко Евгений Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.60	f	\N	f	\N	\N
227	Якубов Мухаммед Абдусаломович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	29.80	f	\N	f	\N	\N
228	Глоба Илья Константинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.70	f	\N	f	\N	\N
229	Ишниязов Шухрат Саидович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	49.70	f	\N	f	\N	\N
230	Бекетов Никита Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	30.00	f	\N	f	\N	\N
231	Шиян Александр Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.10	f	\N	f	\N	\N
232	Абдулмеджидов Руслан Рагимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.00	f	\N	f	\N	\N
233	Коблев Мурат Мухамедович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	17.00	f	\N	f	\N	\N
234	Власенко Максим Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	49.20	f	\N	f	\N	\N
235	Горшкова Ольга Викторовна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	ДСФ	3	3	33.30	f	\N	f	\N	\N
236	Федотов Антон Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	44.20	f	\N	f	\N	\N
237	Есин Александр Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.80	f	\N	f	\N	\N
238	Бареев Радик Маликович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	53.60	f	\N	f	\N	\N
239	Матюхин Илья Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	65.40	f	\N	f	\N	\N
240	Ленский Дмитрий Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	51.00	f	\N	f	\N	\N
241	Каштанов Александр Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.50	f	\N	f	\N	\N
242	Шустров Алексей Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	3	3	48.20	f	\N	f	\N	\N
243	Забабурин Андрей Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.70	f	\N	f	\N	\N
244	Фомичев Павел Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.50	f	\N	f	\N	\N
245	Дробков Юрий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	29.70	f	\N	f	\N	\N
246	Матюхина Елена Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	47.90	f	\N	f	\N	\N
247	Терехов Александр Георгиевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	47.50	f	\N	f	\N	\N
248	Нежведилов Рамазан Сулейманович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	63.20	f	\N	f	\N	\N
249	Каврук Олег Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	60.50	f	\N	f	\N	\N
250	Веселкин Евгений Вадимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	70.90	f	\N	f	\N	\N
251	Заславский Данила Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	11.82	f	\N	f	\N	\N
252	Юрьев Денис Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	46.50	f	\N	f	\N	\N
253	Терещенко Георгий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	11.82	f	\N	f	\N	\N
254	Шишкарев Иван Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.60	f	\N	f	\N	\N
255	Тюнев Сергей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.80	f	\N	f	\N	\N
256	Липша Сергей Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.20	f	\N	f	\N	\N
257	Черешнев Виталий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.20	f	\N	f	\N	\N
258	Капранов Виталий Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.30	f	\N	f	\N	\N
259	Пушкарев Александр Валерьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.00	f	\N	f	\N	\N
260	Дудов Ахмат Муратович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.50	f	\N	f	\N	\N
261	Кудяков Никита Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	38.60	f	\N	f	\N	\N
262	Бачиев Назир Ахметович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	50.10	f	\N	f	\N	\N
263	Давыдов Роман Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	16.70	f	\N	f	\N	\N
264	Верхозин Артём Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	16.70	f	\N	f	\N	\N
265	Зайцев Евгений Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	49.40	f	\N	f	\N	\N
266	Нестеров Сергей Валерьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	65.10	f	\N	f	\N	\N
267	Марченко Иван Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	63.80	f	\N	f	\N	\N
268	Агаметов Байрамали Гаджиевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	71.30	f	\N	f	\N	\N
269	Скабелин Сергей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.80	f	\N	f	\N	\N
270	Эсетов Вадим Джамидинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.60	f	\N	f	\N	\N
271	Магомедов Магомед Эльдарович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.50	f	\N	f	\N	\N
272	Раджабов Багадур Мурадович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.10	f	\N	f	\N	\N
273	Гилаев Рафаэль Равилевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.30	f	\N	f	\N	\N
274	Мухаметкулов Иван Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.70	f	\N	f	\N	\N
275	Афанасьев Петр Олегович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	39.40	f	\N	f	\N	\N
276	Близняков Иван Константинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	95.20	f	\N	f	\N	\N
277	Колотухин Андрей Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	31.50	f	\N	f	\N	\N
278	Миронов Сергей Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	29.20	f	\N	f	\N	\N
279	Кирюшин Кирилл Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	14.60	f	\N	f	\N	\N
280	Нестерчук Денис Петрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	АП	3	3	29.00	f	\N	f	\N	\N
281	Хайдуков Руслан Геннадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	32.20	f	\N	f	\N	\N
282	Ганиев Ариф Ариф	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	49.20	f	\N	f	\N	\N
283	Локтионов Евгений Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	56.80	f	\N	f	\N	\N
284	Колокоцкий Алексей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	49.10	f	\N	f	\N	\N
285	Кулешов Даниил Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	75.00	f	\N	f	\N	\N
286	Капорин Евгений Вадимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	50.00	f	\N	f	\N	\N
287	Атаян Георгий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	31.50	f	\N	f	\N	\N
288	Нижиндаева Виктория Викторовна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДКП	3	3	33.50	f	\N	f	\N	\N
289	Новикова Ирина Олеговна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДСФ	3	3	31.50	f	\N	f	\N	\N
290	Вилданов Даниэль Данисович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	29.60	f	\N	f	\N	\N
291	Мащицкий Анатолий Олегович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДНД	3	3	31.90	f	\N	f	\N	\N
292	Галяс Юрий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	70.90	f	\N	f	\N	\N
293	Яцук Татьяна Михайловна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	31.90	f	\N	f	\N	\N
294	Гамзатов Рамиз Шахбанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	45.90	f	\N	f	\N	\N
295	Илюшина Алиса Михайловна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	АПУ	3	3	56.40	f	\N	f	\N	\N
296	Щетинин Александар Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	МТО	3	3	50.50	f	\N	f	\N	\N
297	Полохин Павел Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	48.20	f	\N	f	\N	\N
298	Рязанова Екатерина Николаевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	73.70	f	\N	f	\N	\N
299	Карпов Юрий Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	УВГСЧ	3	3	48.90	f	\N	f	\N	\N
300	Зайцев Дмитрий Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	31.00	f	\N	f	\N	\N
301	Бондарь Олег Павлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДТО	3	3	55.80	f	\N	f	\N	\N
302	Бачиев Алим Ахметович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	32.50	f	\N	f	\N	\N
303	Егоровцева Олеся Витальевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	УИС	3	3	47.10	f	\N	f	\N	\N
304	Половников Олег Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	21.70	f	\N	f	\N	\N
305	Кубанский Александр Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДГО	3	3	32.50	f	\N	f	\N	\N
306	Марченко Алексей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	41.40	f	\N	f	\N	\N
307	Карпюк Дмитрий Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	НЦУКС	3	3	75.70	f	\N	f	\N	\N
308	Бакаев Даниил Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	59.30	f	\N	f	\N	\N
309	Федосеев Алексей Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ЦА	3	3	51.90	f	\N	f	\N	\N
310	Костерев Дмитрий Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	53.20	f	\N	f	\N	\N
311	Петров Иван Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	52.70	f	\N	f	\N	\N
312	Кузьминов Сергей Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	52.50	f	\N	f	\N	\N
313	Сурин Анатолий Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	УИС	3	3	51.10	f	\N	f	\N	\N
314	Романов Виктор Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	34.10	f	\N	f	\N	\N
315	Гордеев Михаил Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	56.80	f	\N	f	\N	\N
316	Захаров Виталий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	58.20	f	\N	f	\N	\N
317	Малышкин Антон Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ЦУКС	3	3	44.40	f	\N	f	\N	\N
318	Неуймин Владислав Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДТО	3	3	40.20	f	\N	f	\N	\N
\.


--
-- Name: adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.adjustments_id_seq', 1, false);


--
-- Name: periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.periods_id_seq', 1, true);


--
-- Name: readings_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.readings_id_seq1', 317, true);


--
-- Name: tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tariffs_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 318, true);


--
-- Name: adjustments adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: periods periods_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_name_key UNIQUE (name);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: readings readings_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings
    ADD CONSTRAINT readings_pkey1 PRIMARY KEY (id, created_at);


--
-- Name: readings_2024 readings_2024_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2024
    ADD CONSTRAINT readings_2024_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2025 readings_2025_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2025
    ADD CONSTRAINT readings_2025_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2026 readings_2026_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2026
    ADD CONSTRAINT readings_2026_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2027 readings_2027_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2027
    ADD CONSTRAINT readings_2027_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2028 readings_2028_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2028
    ADD CONSTRAINT readings_2028_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2029 readings_2029_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2029
    ADD CONSTRAINT readings_2029_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2030 readings_2030_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2030
    ADD CONSTRAINT readings_2030_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2031 readings_2031_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2031
    ADD CONSTRAINT readings_2031_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2032 readings_2032_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2032
    ADD CONSTRAINT readings_2032_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2033 readings_2033_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2033
    ADD CONSTRAINT readings_2033_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2034 readings_2034_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2034
    ADD CONSTRAINT readings_2034_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2035 readings_2035_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2035
    ADD CONSTRAINT readings_2035_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_default readings_default_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_default
    ADD CONSTRAINT readings_default_pkey PRIMARY KEY (id, created_at);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tariffs tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_adj_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_adj_user_period ON public.adjustments USING btree (user_id, period_id);


--
-- Name: idx_reading_approved_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_approved_period ON ONLY public.readings USING btree (is_approved, period_id);


--
-- Name: idx_reading_user_approved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_user_approved ON ONLY public.readings USING btree (user_id, is_approved);


--
-- Name: idx_reading_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_user_period ON ONLY public.readings USING btree (user_id, period_id);


--
-- Name: idx_user_dormitory_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_dormitory_trgm ON public.users USING gin (dormitory public.gin_trgm_ops);


--
-- Name: idx_user_username_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_username_trgm ON public.users USING gin (username public.gin_trgm_ops);


--
-- Name: ix_adjustments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_adjustments_id ON public.adjustments USING btree (id);


--
-- Name: ix_periods_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_periods_id ON public.periods USING btree (id);


--
-- Name: ix_periods_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_periods_is_active ON public.periods USING btree (is_active);


--
-- Name: ix_system_settings_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_settings_key ON public.system_settings USING btree (key);


--
-- Name: ix_tariffs_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tariffs_is_active ON public.tariffs USING btree (is_active);


--
-- Name: ix_users_dormitory; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_dormitory ON public.users USING btree (dormitory);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_is_deleted; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_is_deleted ON public.users USING btree (is_deleted);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: readings_2024_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_is_approved_period_id_idx ON public.readings_2024 USING btree (is_approved, period_id);


--
-- Name: readings_2024_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_user_id_is_approved_idx ON public.readings_2024 USING btree (user_id, is_approved);


--
-- Name: readings_2024_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_user_id_period_id_idx ON public.readings_2024 USING btree (user_id, period_id);


--
-- Name: readings_2025_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_is_approved_period_id_idx ON public.readings_2025 USING btree (is_approved, period_id);


--
-- Name: readings_2025_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_user_id_is_approved_idx ON public.readings_2025 USING btree (user_id, is_approved);


--
-- Name: readings_2025_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_user_id_period_id_idx ON public.readings_2025 USING btree (user_id, period_id);


--
-- Name: readings_2026_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_is_approved_period_id_idx ON public.readings_2026 USING btree (is_approved, period_id);


--
-- Name: readings_2026_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_user_id_is_approved_idx ON public.readings_2026 USING btree (user_id, is_approved);


--
-- Name: readings_2026_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_user_id_period_id_idx ON public.readings_2026 USING btree (user_id, period_id);


--
-- Name: readings_2027_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_is_approved_period_id_idx ON public.readings_2027 USING btree (is_approved, period_id);


--
-- Name: readings_2027_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_user_id_is_approved_idx ON public.readings_2027 USING btree (user_id, is_approved);


--
-- Name: readings_2027_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_user_id_period_id_idx ON public.readings_2027 USING btree (user_id, period_id);


--
-- Name: readings_2028_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_is_approved_period_id_idx ON public.readings_2028 USING btree (is_approved, period_id);


--
-- Name: readings_2028_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_user_id_is_approved_idx ON public.readings_2028 USING btree (user_id, is_approved);


--
-- Name: readings_2028_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_user_id_period_id_idx ON public.readings_2028 USING btree (user_id, period_id);


--
-- Name: readings_2029_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_is_approved_period_id_idx ON public.readings_2029 USING btree (is_approved, period_id);


--
-- Name: readings_2029_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_user_id_is_approved_idx ON public.readings_2029 USING btree (user_id, is_approved);


--
-- Name: readings_2029_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_user_id_period_id_idx ON public.readings_2029 USING btree (user_id, period_id);


--
-- Name: readings_2030_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_is_approved_period_id_idx ON public.readings_2030 USING btree (is_approved, period_id);


--
-- Name: readings_2030_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_user_id_is_approved_idx ON public.readings_2030 USING btree (user_id, is_approved);


--
-- Name: readings_2030_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_user_id_period_id_idx ON public.readings_2030 USING btree (user_id, period_id);


--
-- Name: readings_2031_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_is_approved_period_id_idx ON public.readings_2031 USING btree (is_approved, period_id);


--
-- Name: readings_2031_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_user_id_is_approved_idx ON public.readings_2031 USING btree (user_id, is_approved);


--
-- Name: readings_2031_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_user_id_period_id_idx ON public.readings_2031 USING btree (user_id, period_id);


--
-- Name: readings_2032_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_is_approved_period_id_idx ON public.readings_2032 USING btree (is_approved, period_id);


--
-- Name: readings_2032_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_user_id_is_approved_idx ON public.readings_2032 USING btree (user_id, is_approved);


--
-- Name: readings_2032_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_user_id_period_id_idx ON public.readings_2032 USING btree (user_id, period_id);


--
-- Name: readings_2033_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_is_approved_period_id_idx ON public.readings_2033 USING btree (is_approved, period_id);


--
-- Name: readings_2033_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_user_id_is_approved_idx ON public.readings_2033 USING btree (user_id, is_approved);


--
-- Name: readings_2033_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_user_id_period_id_idx ON public.readings_2033 USING btree (user_id, period_id);


--
-- Name: readings_2034_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_is_approved_period_id_idx ON public.readings_2034 USING btree (is_approved, period_id);


--
-- Name: readings_2034_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_user_id_is_approved_idx ON public.readings_2034 USING btree (user_id, is_approved);


--
-- Name: readings_2034_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_user_id_period_id_idx ON public.readings_2034 USING btree (user_id, period_id);


--
-- Name: readings_2035_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_is_approved_period_id_idx ON public.readings_2035 USING btree (is_approved, period_id);


--
-- Name: readings_2035_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_user_id_is_approved_idx ON public.readings_2035 USING btree (user_id, is_approved);


--
-- Name: readings_2035_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_user_id_period_id_idx ON public.readings_2035 USING btree (user_id, period_id);


--
-- Name: readings_default_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_is_approved_period_id_idx ON public.readings_default USING btree (is_approved, period_id);


--
-- Name: readings_default_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_user_id_is_approved_idx ON public.readings_default USING btree (user_id, is_approved);


--
-- Name: readings_default_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_user_id_period_id_idx ON public.readings_default USING btree (user_id, period_id);


--
-- Name: readings_2024_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2024_is_approved_period_id_idx;


--
-- Name: readings_2024_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2024_pkey;


--
-- Name: readings_2024_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2024_user_id_is_approved_idx;


--
-- Name: readings_2024_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2024_user_id_period_id_idx;


--
-- Name: readings_2025_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2025_is_approved_period_id_idx;


--
-- Name: readings_2025_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2025_pkey;


--
-- Name: readings_2025_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2025_user_id_is_approved_idx;


--
-- Name: readings_2025_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2025_user_id_period_id_idx;


--
-- Name: readings_2026_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2026_is_approved_period_id_idx;


--
-- Name: readings_2026_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2026_pkey;


--
-- Name: readings_2026_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2026_user_id_is_approved_idx;


--
-- Name: readings_2026_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2026_user_id_period_id_idx;


--
-- Name: readings_2027_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2027_is_approved_period_id_idx;


--
-- Name: readings_2027_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2027_pkey;


--
-- Name: readings_2027_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2027_user_id_is_approved_idx;


--
-- Name: readings_2027_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2027_user_id_period_id_idx;


--
-- Name: readings_2028_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2028_is_approved_period_id_idx;


--
-- Name: readings_2028_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2028_pkey;


--
-- Name: readings_2028_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2028_user_id_is_approved_idx;


--
-- Name: readings_2028_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2028_user_id_period_id_idx;


--
-- Name: readings_2029_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2029_is_approved_period_id_idx;


--
-- Name: readings_2029_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2029_pkey;


--
-- Name: readings_2029_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2029_user_id_is_approved_idx;


--
-- Name: readings_2029_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2029_user_id_period_id_idx;


--
-- Name: readings_2030_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2030_is_approved_period_id_idx;


--
-- Name: readings_2030_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2030_pkey;


--
-- Name: readings_2030_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2030_user_id_is_approved_idx;


--
-- Name: readings_2030_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2030_user_id_period_id_idx;


--
-- Name: readings_2031_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2031_is_approved_period_id_idx;


--
-- Name: readings_2031_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2031_pkey;


--
-- Name: readings_2031_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2031_user_id_is_approved_idx;


--
-- Name: readings_2031_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2031_user_id_period_id_idx;


--
-- Name: readings_2032_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2032_is_approved_period_id_idx;


--
-- Name: readings_2032_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2032_pkey;


--
-- Name: readings_2032_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2032_user_id_is_approved_idx;


--
-- Name: readings_2032_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2032_user_id_period_id_idx;


--
-- Name: readings_2033_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2033_is_approved_period_id_idx;


--
-- Name: readings_2033_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2033_pkey;


--
-- Name: readings_2033_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2033_user_id_is_approved_idx;


--
-- Name: readings_2033_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2033_user_id_period_id_idx;


--
-- Name: readings_2034_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2034_is_approved_period_id_idx;


--
-- Name: readings_2034_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2034_pkey;


--
-- Name: readings_2034_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2034_user_id_is_approved_idx;


--
-- Name: readings_2034_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2034_user_id_period_id_idx;


--
-- Name: readings_2035_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2035_is_approved_period_id_idx;


--
-- Name: readings_2035_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2035_pkey;


--
-- Name: readings_2035_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2035_user_id_is_approved_idx;


--
-- Name: readings_2035_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2035_user_id_period_id_idx;


--
-- Name: readings_default_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_default_is_approved_period_id_idx;


--
-- Name: readings_default_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_default_pkey;


--
-- Name: readings_default_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_default_user_id_is_approved_idx;


--
-- Name: readings_default_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_default_user_id_period_id_idx;


--
-- Name: adjustments adjustments_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.periods(id);


--
-- Name: adjustments adjustments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: readings fk_readings_period_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.readings
    ADD CONSTRAINT fk_readings_period_id FOREIGN KEY (period_id) REFERENCES public.periods(id);


--
-- Name: readings fk_readings_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.readings
    ADD CONSTRAINT fk_readings_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: periods periods_tariff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_tariff_id_fkey FOREIGN KEY (tariff_id) REFERENCES public.tariffs(id);


--
-- Name: users users_tariff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tariff_id_fkey FOREIGN KEY (tariff_id) REFERENCES public.tariffs(id);


--
-- PostgreSQL database dump complete
--

\unrestrict mISglS51c2JlVXjVNe3r96cox5rLAqcWd4hOfj6V5p4JFXBC4VGBMVNtpvOsMyS

