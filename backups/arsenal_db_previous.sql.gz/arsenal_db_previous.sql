--
-- PostgreSQL database dump
--

\restrict LyWT5dtCV4WdJeTNdu5B6Ni7VjOUtfaBemPIgqchFxdOQudtWeRirGlOqpJP19d

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict LyWT5dtCV4WdJeTNdu5B6Ni7VjOUtfaBemPIgqchFxdOQudtWeRirGlOqpJP19d

