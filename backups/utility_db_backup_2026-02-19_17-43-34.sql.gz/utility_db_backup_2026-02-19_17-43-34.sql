--
-- PostgreSQL database dump
--

\restrict JaYL3zagAc738XjFnPhDQIFwbiKlB3riqv6h9hx7oGzhTa9LUR8fuukSsZ4i3Wa

-- Dumped from database version 15.16 (Debian 15.16-1.pgdg13+1)
-- Dumped by pg_dump version 15.16 (Debian 15.16-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict JaYL3zagAc738XjFnPhDQIFwbiKlB3riqv6h9hx7oGzhTa9LUR8fuukSsZ4i3Wa

