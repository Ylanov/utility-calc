--
-- PostgreSQL database dump
--

\restrict j5GbUbq6U6IOPiXXtCIOD12OE28DuYUK1pma3PpxlGRX7cxCzFSgmv9ohQGfOkn

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adjustments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adjustments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    period_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    description character varying NOT NULL,
    created_at timestamp without time zone,
    account_type character varying NOT NULL
);


ALTER TABLE public.adjustments OWNER TO postgres;

--
-- Name: adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adjustments_id_seq OWNER TO postgres;

--
-- Name: adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.adjustments_id_seq OWNED BY public.adjustments.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.periods (
    id integer NOT NULL,
    name character varying NOT NULL,
    is_active boolean,
    created_at timestamp without time zone,
    tariff_id integer
);


ALTER TABLE public.periods OWNER TO postgres;

--
-- Name: periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.periods_id_seq OWNER TO postgres;

--
-- Name: periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.periods_id_seq OWNED BY public.periods.id;


--
-- Name: readings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
)
PARTITION BY RANGE (created_at);


ALTER TABLE public.readings OWNER TO postgres;

--
-- Name: readings_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.readings_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.readings_id_seq1 OWNER TO postgres;

--
-- Name: readings_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.readings_id_seq1 OWNED BY public.readings.id;


--
-- Name: readings_2024; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2024 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2024 OWNER TO postgres;

--
-- Name: readings_2025; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2025 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2025 OWNER TO postgres;

--
-- Name: readings_2026; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2026 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2026 OWNER TO postgres;

--
-- Name: readings_2027; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2027 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2027 OWNER TO postgres;

--
-- Name: readings_2028; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2028 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2028 OWNER TO postgres;

--
-- Name: readings_2029; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2029 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2029 OWNER TO postgres;

--
-- Name: readings_2030; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2030 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2030 OWNER TO postgres;

--
-- Name: readings_2031; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2031 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2031 OWNER TO postgres;

--
-- Name: readings_2032; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2032 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2032 OWNER TO postgres;

--
-- Name: readings_2033; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2033 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2033 OWNER TO postgres;

--
-- Name: readings_2034; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2034 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2034 OWNER TO postgres;

--
-- Name: readings_2035; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2035 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2035 OWNER TO postgres;

--
-- Name: readings_default; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_default (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_default OWNER TO postgres;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value character varying NOT NULL,
    description character varying
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: tariffs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tariffs (
    id integer NOT NULL,
    is_active boolean,
    valid_from timestamp without time zone,
    maintenance_repair numeric(10,4),
    social_rent numeric(10,4),
    heating numeric(10,4),
    water_heating numeric(10,4),
    water_supply numeric(10,4),
    sewage numeric(10,4),
    waste_disposal numeric(10,4),
    electricity_per_sqm numeric(10,4),
    electricity_rate numeric(10,4),
    name character varying NOT NULL
);


ALTER TABLE public.tariffs OWNER TO postgres;

--
-- Name: tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tariffs_id_seq OWNER TO postgres;

--
-- Name: tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tariffs_id_seq OWNED BY public.tariffs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying NOT NULL,
    role character varying NOT NULL,
    dormitory character varying,
    workplace character varying,
    residents_count integer,
    total_room_residents integer,
    apartment_area numeric(10,2),
    is_deleted boolean,
    totp_secret character varying,
    is_initial_setup_done boolean DEFAULT false,
    telegram_id character varying,
    tariff_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: readings_2024; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2024 FOR VALUES FROM ('2024-01-01 00:00:00') TO ('2025-01-01 00:00:00');


--
-- Name: readings_2025; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2025 FOR VALUES FROM ('2025-01-01 00:00:00') TO ('2026-01-01 00:00:00');


--
-- Name: readings_2026; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2026 FOR VALUES FROM ('2026-01-01 00:00:00') TO ('2027-01-01 00:00:00');


--
-- Name: readings_2027; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2027 FOR VALUES FROM ('2027-01-01 00:00:00') TO ('2028-01-01 00:00:00');


--
-- Name: readings_2028; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2028 FOR VALUES FROM ('2028-01-01 00:00:00') TO ('2029-01-01 00:00:00');


--
-- Name: readings_2029; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2029 FOR VALUES FROM ('2029-01-01 00:00:00') TO ('2030-01-01 00:00:00');


--
-- Name: readings_2030; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2030 FOR VALUES FROM ('2030-01-01 00:00:00') TO ('2031-01-01 00:00:00');


--
-- Name: readings_2031; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2031 FOR VALUES FROM ('2031-01-01 00:00:00') TO ('2032-01-01 00:00:00');


--
-- Name: readings_2032; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2032 FOR VALUES FROM ('2032-01-01 00:00:00') TO ('2033-01-01 00:00:00');


--
-- Name: readings_2033; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2033 FOR VALUES FROM ('2033-01-01 00:00:00') TO ('2034-01-01 00:00:00');


--
-- Name: readings_2034; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2034 FOR VALUES FROM ('2034-01-01 00:00:00') TO ('2035-01-01 00:00:00');


--
-- Name: readings_2035; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2035 FOR VALUES FROM ('2035-01-01 00:00:00') TO ('2036-01-01 00:00:00');


--
-- Name: readings_default; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_default DEFAULT;


--
-- Name: adjustments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments ALTER COLUMN id SET DEFAULT nextval('public.adjustments_id_seq'::regclass);


--
-- Name: periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods ALTER COLUMN id SET DEFAULT nextval('public.periods_id_seq'::regclass);


--
-- Name: readings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ALTER COLUMN id SET DEFAULT nextval('public.readings_id_seq1'::regclass);


--
-- Name: tariffs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tariffs ALTER COLUMN id SET DEFAULT nextval('public.tariffs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: adjustments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adjustments (id, user_id, period_id, amount, description, created_at, account_type) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
dd2c767d6f06
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.periods (id, name, is_active, created_at, tariff_id) FROM stdin;
1	Начальный период	t	2026-03-05 20:51:16.417666	\N
\.


--
-- Data for Name: readings_2024; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2024 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2025; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2025 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2026; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2026 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
1	2026-03-05 21:20:41.545539	2	1	111.000	111.000	11111.000	0.00	0.00	0.00	0.00	0.000	0.000	0.000	0.000	55555.00	0.00	55555.00	0.00	0.00	55555.00	0.00	0.00	0.00	0.00	0.00	\N	f
\.


--
-- Data for Name: readings_2027; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2027 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2028; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2028 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2029; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2029 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2030; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2030 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2031; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2031 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2032; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2032 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2033; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2033 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2034; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2034 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2035; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2035 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_default; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_default (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (key, value, description) FROM stdin;
submission_start_day	20	День начала приема показаний
submission_end_day	25	День окончания приема показаний
\.


--
-- Data for Name: tariffs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tariffs (id, is_active, valid_from, maintenance_repair, social_rent, heating, water_heating, water_supply, sewage, waste_disposal, electricity_per_sqm, electricity_rate, name) FROM stdin;
1	t	2026-03-05 20:51:16.398966	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	5.0000	Базовый тариф
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, hashed_password, role, dormitory, workplace, residents_count, total_room_residents, apartment_area, is_deleted, totp_secret, is_initial_setup_done, telegram_id, tariff_id) FROM stdin;
1	admin	$argon2id$v=19$m=65536,t=2,p=2$Vgqh1HoPwThnLKXU2lurdQ$2zMuliV0Z6PkHyZFi+fRLFN6RKUuMoUzBme9F74bvuY	accountant	\N	\N	1	1	0.00	f	\N	t	\N	\N
2	Емельяненко Михаил Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	49.50	f	\N	f	\N	\N
3	Матус Антон Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.50	f	\N	f	\N	\N
4	Жданов Николай Федорович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.00	f	\N	f	\N	\N
5	Косенко Екатерина Васильевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	2	2	68.60	f	\N	f	\N	\N
6	Лушников Анатолий Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	66.40	f	\N	f	\N	\N
7	Алискеров Тимур Шихрагимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	63.50	f	\N	f	\N	\N
8	Корепанов Андрей Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.00	f	\N	f	\N	\N
9	Орлов Алексей Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	43.70	f	\N	f	\N	\N
10	Лагутин Николай Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	49.00	f	\N	f	\N	\N
11	Семенцов Алексей Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	45.80	f	\N	f	\N	\N
12	Почекунин Александр Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	48.90	f	\N	f	\N	\N
13	Бельков Юрий Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.90	f	\N	f	\N	\N
14	Осипов Павел Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	66.20	f	\N	f	\N	\N
15	Каримов Булат Ильфатович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	68.50	f	\N	f	\N	\N
16	Мальков Дмитрий Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	60.30	f	\N	f	\N	\N
17	Олейник Елена Александровна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	ЦА	1	1	63.20	f	\N	f	\N	\N
18	Карачевцев Алексей Анатольевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.90	f	\N	f	\N	\N
19	Покидин Николай Валентинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	ЦА	1	1	44.30	f	\N	f	\N	\N
20	Лучка Александр Павлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	ЦА	2	2	64.90	f	\N	f	\N	\N
21	Волков Владимир Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.80	f	\N	f	\N	\N
22	Пушкарев Александр Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.30	f	\N	f	\N	\N
23	Резунов Роман Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	3	3	47.10	f	\N	f	\N	\N
24	Керн Ольга Алексеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	49.40	f	\N	f	\N	\N
25	Пегарьков Александр Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.90	f	\N	f	\N	\N
26	Иваницкий Константин Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.70	f	\N	f	\N	\N
27	Арцаев Руслан Султанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	66.40	f	\N	f	\N	\N
28	Вагидов Руслан Мирзалиевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	66.80	f	\N	f	\N	\N
29	Панасецкий Петр Петрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.10	f	\N	f	\N	\N
30	Панкратов Иван Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	45.80	f	\N	f	\N	\N
31	Семченкова Валерия Андреевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	НЦУКС	3	3	64.30	f	\N	f	\N	\N
32	Кешоков Азамат Ахмедович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	49.10	f	\N	f	\N	\N
33	Душин Дмитрий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.90	f	\N	f	\N	\N
34	Завацкий Алексей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	45.90	f	\N	f	\N	\N
35	Семенченко Никита Олегович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	46.40	f	\N	f	\N	\N
36	Прокопенко Максим Борисович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.60	f	\N	f	\N	\N
37	Шевченко Александр Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.70	f	\N	f	\N	\N
38	Черняев Максим Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	61.90	f	\N	f	\N	\N
39	Смирнов Александр Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	63.90	f	\N	f	\N	\N
40	Мироненко Александр Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.50	f	\N	f	\N	\N
41	Андросов Сергей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.90	f	\N	f	\N	\N
42	Ильин Никита Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.80	f	\N	f	\N	\N
43	Ревин Денис Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.40	f	\N	f	\N	\N
44	Глушакова Анастасия Олеговна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.80	f	\N	f	\N	\N
45	Еремин Павел Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	45.70	f	\N	f	\N	\N
46	Резевский Виктор Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	47.20	f	\N	f	\N	\N
47	Айвазов Халил Кашалыевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.30	f	\N	f	\N	\N
48	Азимов Виталий Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.90	f	\N	f	\N	\N
49	Таранюк Алексей Валерьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	61.90	f	\N	f	\N	\N
50	Гюрджян Сергей Левонович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	64.80	f	\N	f	\N	\N
51	Платов Денис Максимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	44.50	f	\N	f	\N	\N
52	Мурадов Руслан Фикретович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	65.20	f	\N	f	\N	\N
53	Мурнаев Никита Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	48.00	f	\N	f	\N	\N
54	Дибирасулаев Тимур Магамедович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	Лидер	1	1	48.40	f	\N	f	\N	\N
55	Кузнецов Виталий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	46.30	f	\N	f	\N	\N
56	Запарин Михаил Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	47.30	f	\N	f	\N	\N
57	Кудрявцев Владимир Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.30	f	\N	f	\N	\N
58	Кулешов Максим Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	28.90	f	\N	f	\N	\N
59	Юриков Даниил Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.50	f	\N	f	\N	\N
60	Попков Максим Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.20	f	\N	f	\N	\N
61	Рыбальченко Сергей Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	42.10	f	\N	f	\N	\N
62	Атиков Илия Рафаэльевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.20	f	\N	f	\N	\N
63	Джиоев Георгий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	15.10	f	\N	f	\N	\N
64	Осипов Руслан Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	47.30	f	\N	f	\N	\N
65	Струкова Ольга Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.60	f	\N	f	\N	\N
66	Седякин Игорь Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	48.10	f	\N	f	\N	\N
67	Крючков Артем Геннадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.00	f	\N	f	\N	\N
68	Прохоренко Константин Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.10	f	\N	f	\N	\N
69	Кармов Беслан Ризуанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.70	f	\N	f	\N	\N
70	Снегирева Людмила Валерьевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	2	2	32.40	f	\N	f	\N	\N
71	Хабибулин Данила Романович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	3	3	28.70	f	\N	f	\N	\N
72	Нурмагамедов Абдулнасир Магомедович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.70	f	\N	f	\N	\N
73	Дуденко Максим Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.00	f	\N	f	\N	\N
74	Соловьев Евгений Витальевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.80	f	\N	f	\N	\N
75	Смирнов Максим Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.90	f	\N	f	\N	\N
76	Левшин Александр Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.90	f	\N	f	\N	\N
77	Закамалдин Андрей Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.60	f	\N	f	\N	\N
78	Ярощук Александр Павлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.50	f	\N	f	\N	\N
79	Беленьких Андрей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.80	f	\N	f	\N	\N
80	Чернов Сергей Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.40	f	\N	f	\N	\N
81	Чаптыков Роман Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	49.90	f	\N	f	\N	\N
82	Чистяков Николай Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	АД	3	3	29.00	f	\N	f	\N	\N
83	Шорошева Наталья Валентиновна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	2	2	31.10	f	\N	f	\N	\N
84	Муртазина Алия Мифтяхотдиновна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.40	f	\N	f	\N	\N
85	Тихонова Оксана Игоревна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	НТУ	3	3	32.70	f	\N	f	\N	\N
86	Гребенькова Ксения Юрьевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.30	f	\N	f	\N	\N
87	Сабаткоев Казбек Аланович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.50	f	\N	f	\N	\N
88	Колемагин Дмитрий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.60	f	\N	f	\N	\N
89	Фахреев Альберт Тимурович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	33.70	f	\N	f	\N	\N
90	Сорокин Александр Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.30	f	\N	f	\N	\N
91	Сорокин Сергей Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.20	f	\N	f	\N	\N
92	Хизанашвили Михаил Ясонович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.10	f	\N	f	\N	\N
93	Безродний Сергей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.20	f	\N	f	\N	\N
94	Мясников Даниил Геннадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.10	f	\N	f	\N	\N
95	Косынкин Даниил Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	33.20	f	\N	f	\N	\N
96	Данилов Дмитрий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.60	f	\N	f	\N	\N
97	Дронин Константин Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.90	f	\N	f	\N	\N
98	Анюхин Роман Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	45.80	f	\N	f	\N	\N
99	Писарев Александр Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	44.60	f	\N	f	\N	\N
100	Дегтярев Владислав Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	47.20	f	\N	f	\N	\N
101	Подловилин Давид Витальевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	3	3	27.70	f	\N	f	\N	\N
102	Катунькина Иннеса Ивановна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.50	f	\N	f	\N	\N
103	Грибач Виталий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	ЦА	1	1	31.20	f	\N	f	\N	\N
104	Пинских Юрий Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.50	f	\N	f	\N	\N
105	Бендас Вадим Родионович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.60	f	\N	f	\N	\N
106	Тюрин Александр Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.10	f	\N	f	\N	\N
107	Куликов Сергей Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.60	f	\N	f	\N	\N
108	Шуянов Иван Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.20	f	\N	f	\N	\N
109	Вастаев Валерий Сидорович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.70	f	\N	f	\N	\N
110	Лапатько Кирилл Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	32.10	f	\N	f	\N	\N
111	Кочелаев Денис Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.80	f	\N	f	\N	\N
112	Приходченков Игорь Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	31.50	f	\N	f	\N	\N
113	Кондратьева Мария Александровна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	27.10	f	\N	f	\N	\N
114	Степанков Дмитрий Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	30.20	f	\N	f	\N	\N
115	Ермолаев Игорь Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	15.10	f	\N	f	\N	\N
116	Рудь Руслан Рамазанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	15.10	f	\N	f	\N	\N
117	Смолин Кирилл Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	29.10	f	\N	f	\N	\N
118	Мальков Сергей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	3	3	14.55	f	\N	f	\N	\N
119	Тищенко Максим Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	14.55	f	\N	f	\N	\N
120	Хруберов Кирилл Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	33.10	f	\N	f	\N	\N
121	Залитдинов Шарапутдин Залитдинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	11.03	f	\N	f	\N	\N
122	Война Владислав Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	33.60	f	\N	f	\N	\N
123	Лисник Кирилл Борисович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	8.40	f	\N	f	\N	\N
124	Попелов Алексей Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	8.40	f	\N	f	\N	\N
125	Жуков Савелий Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	8.40	f	\N	f	\N	\N
126	Серый Артем Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	16.80	f	\N	f	\N	\N
127	Тарасов Валерий Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	16.80	f	\N	f	\N	\N
128	Том Богдан Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	10.66	f	\N	f	\N	\N
129	Кудинов Максим Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	10.66	f	\N	f	\N	\N
130	Арутюнян Арман Горович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	10.66	f	\N	f	\N	\N
131	Смирнов Даниил Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	14.80	f	\N	f	\N	\N
132	Чекалин Александр Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	34.00	f	\N	f	\N	\N
133	Тер-Саакян Даниил Витальевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	11.34	f	\N	f	\N	\N
134	Легконогих Александр Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.8	Лидер	1	1	11.34	f	\N	f	\N	\N
135	Югай Арсений Анатольевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.9	\N	1	1	19.64	f	\N	f	\N	\N
136	Усатая Елена Павловна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	45.00	f	\N	f	\N	\N
137	Никитина Екатерина Александровна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	36.00	f	\N	f	\N	\N
138	Агуреев Валерий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	13.60	f	\N	f	\N	\N
139	Бирюлькин Михаил Анатольевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	36.00	f	\N	f	\N	\N
140	Сивицкая Елена Олеговна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	37.00	f	\N	f	\N	\N
141	Конопихин Евгений Леонидович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	2	2	16.00	f	\N	f	\N	\N
142	Приходько Алена Игоревна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.7	Лидер	1	1	31.00	f	\N	f	\N	\N
143	Умнов Михаил Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	ОК	Лидер	1	1	46.10	f	\N	f	\N	\N
144	Меликов Санжарбек Ашуралиевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	ОК	Лидер	1	1	23.05	f	\N	f	\N	\N
145	Матисон Игорь Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	61.80	f	\N	f	\N	\N
146	Белов Иван Максимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	8.83	f	\N	f	\N	\N
147	Терехов Максим Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	8.83	f	\N	f	\N	\N
148	Рыбин Павел Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	15.50	f	\N	f	\N	\N
149	Гуков Эльдар Альбертович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	8.83	f	\N	f	\N	\N
150	Прасков Николай Валентинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	49.50	f	\N	f	\N	\N
151	Власов Станислав Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	24.75	f	\N	f	\N	\N
152	Очетов Евгений Леонтьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	50.30	f	\N	f	\N	\N
153	Шаргаев Дмитрий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	16.77	f	\N	f	\N	\N
154	Кондрашов Герман Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	16.77	f	\N	f	\N	\N
155	Гурин Дмитрий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	44.80	f	\N	f	\N	\N
156	Тихон Михаил Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	14.94	f	\N	f	\N	\N
157	Серебряков Валерий Аркадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	15.50	f	\N	f	\N	\N
158	Муравьев Павел Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	44.90	f	\N	f	\N	\N
159	Шелюков Виктор Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	14.97	f	\N	f	\N	\N
160	Мороз Артем Анатольевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	15.95	f	\N	f	\N	\N
161	Гасымов Рамиз Рассадин Оглы	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	\N	1	1	42.60	f	\N	f	\N	\N
162	Акбашев Ильфат Ильдарович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	14.20	f	\N	f	\N	\N
163	Соколов Илья Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	38.10	f	\N	f	\N	\N
164	Аникин Альберт Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	9.53	f	\N	f	\N	\N
165	Буйнов Марк Геннадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	35.20	f	\N	f	\N	\N
166	Абдулкеримов Арсен Гайдарович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	11.74	f	\N	f	\N	\N
167	Смирнов Руслан Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.18	Лидер	1	1	11.74	f	\N	f	\N	\N
168	Хрипачев Андрей Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	47.64	f	\N	f	\N	\N
169	Устимов Роман Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	50.72	f	\N	f	\N	\N
170	Оболенская Кира Олеговна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.60	f	\N	f	\N	\N
171	Никольский Дмитрий Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.70	f	\N	f	\N	\N
172	Дарий Андрей Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.00	f	\N	f	\N	\N
173	Солоденко Роман Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	46.90	f	\N	f	\N	\N
174	Баскаков Андрей Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.70	f	\N	f	\N	\N
175	Шаховский Дмитрий Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	30.50	f	\N	f	\N	\N
176	Валкович Андрей Петрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.30	f	\N	f	\N	\N
177	Безруков Михаил Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.40	f	\N	f	\N	\N
178	Калачев Вадим Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	47.40	f	\N	f	\N	\N
179	Токтаев Илья Олегович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.00	f	\N	f	\N	\N
180	Муталиев Ахмед Русланович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	52.50	f	\N	f	\N	\N
181	Бульдина Наждежда Юрьевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	ЦСИ	3	3	29.00	f	\N	f	\N	\N
182	Семкина Вера Васильевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	33.60	f	\N	f	\N	\N
183	Михалева Алена Борисовна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	35.60	f	\N	f	\N	\N
184	Кривушин Илья Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	35.20	f	\N	f	\N	\N
185	Квасникова Вера Михайловна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	35.70	f	\N	f	\N	\N
186	Федоров Иван Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.20	f	\N	f	\N	\N
187	Сафаров Сахиб Гаджибаба-оглу	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	3	3	34.40	f	\N	f	\N	\N
188	Саттарова Ряися Маратовна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	33.00	f	\N	f	\N	\N
189	Сергиенко Оксана Геннадьевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	45.00	f	\N	f	\N	\N
190	Быков Захар Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	29.90	f	\N	f	\N	\N
191	Ширяев Андрей Игоревич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.40	f	\N	f	\N	\N
192	Смирнов Максим Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	48.30	f	\N	f	\N	\N
193	Абукаров Марат Мурадович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	30.90	f	\N	f	\N	\N
194	Халваши Георгий Малхазович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	30.20	f	\N	f	\N	\N
195	Звезда Антон Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.30	f	\N	f	\N	\N
196	Тверяхин Вадим Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.20	f	\N	f	\N	\N
197	Кононов Степан Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.70	f	\N	f	\N	\N
198	Джапбаров Осман Тимирбулатович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.20	f	\N	f	\N	\N
199	Шмыров Вадим Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.60	f	\N	f	\N	\N
200	Сулейманов Халид Рамазанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	28.90	f	\N	f	\N	\N
201	Никитин Андрей Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.50	f	\N	f	\N	\N
202	Марченко Алексей Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	35.10	f	\N	f	\N	\N
203	Гагиев Давид Роландович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.90	f	\N	f	\N	\N
204	Науменко Сергей Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	35.70	f	\N	f	\N	\N
205	Никитин Алексей Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	35.30	f	\N	f	\N	\N
206	Маняев Иван Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.80	f	\N	f	\N	\N
207	Степаненко Андрей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.00	f	\N	f	\N	\N
208	Байков Николай Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	46.70	f	\N	f	\N	\N
209	Теплоухов Никита Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.50	f	\N	f	\N	\N
210	Мимонова Виктория Владимировна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	3	3	29.70	f	\N	f	\N	\N
211	Шпаков Анатолий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.30	f	\N	f	\N	\N
212	Назаретян Мнацакан Генрихович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	48.70	f	\N	f	\N	\N
213	Степанков Михаил Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.00	f	\N	f	\N	\N
214	Гареев Артур Радифович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	НЦУКС	3	3	31.40	f	\N	f	\N	\N
215	Ананьева Ирина Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	34.20	f	\N	f	\N	\N
216	Ланина Маргарита Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.10	f	\N	f	\N	\N
217	Селезнева Валентина Ивановна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	33.80	f	\N	f	\N	\N
218	Неметуллаева Арзу Рафиковна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	2	2	33.70	f	\N	f	\N	\N
219	Азязов Александр Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	28.30	f	\N	f	\N	\N
220	Шигапов Ришат Фаридович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.00	f	\N	f	\N	\N
221	Григорян Евгений Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.50	f	\N	f	\N	\N
222	Курносов Евгений Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.70	f	\N	f	\N	\N
223	Шумилова Лилия Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.10	f	\N	f	\N	\N
224	Хайбуллин Артем Ильсурович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.50	f	\N	f	\N	\N
225	Галко Семен Васильевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	46.40	f	\N	f	\N	\N
226	Похиленко Евгений Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.60	f	\N	f	\N	\N
227	Якубов Мухаммед Абдусаломович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	29.80	f	\N	f	\N	\N
228	Глоба Илья Константинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.70	f	\N	f	\N	\N
229	Ишниязов Шухрат Саидович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	49.70	f	\N	f	\N	\N
230	Бекетов Никита Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	30.00	f	\N	f	\N	\N
231	Шиян Александр Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	31.10	f	\N	f	\N	\N
232	Абдулмеджидов Руслан Рагимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.00	f	\N	f	\N	\N
233	Коблев Мурат Мухамедович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	17.00	f	\N	f	\N	\N
234	Власенко Максим Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	49.20	f	\N	f	\N	\N
235	Горшкова Ольга Викторовна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	ДСФ	3	3	33.30	f	\N	f	\N	\N
236	Федотов Антон Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	44.20	f	\N	f	\N	\N
237	Есин Александр Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	32.80	f	\N	f	\N	\N
238	Бареев Радик Маликович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	53.60	f	\N	f	\N	\N
239	Матюхин Илья Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	65.40	f	\N	f	\N	\N
240	Ленский Дмитрий Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	51.00	f	\N	f	\N	\N
241	Каштанов Александр Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.50	f	\N	f	\N	\N
242	Шустров Алексей Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	3	3	48.20	f	\N	f	\N	\N
243	Забабурин Андрей Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	33.70	f	\N	f	\N	\N
244	Фомичев Павел Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	34.50	f	\N	f	\N	\N
245	Дробков Юрий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.5	Лидер	1	1	29.70	f	\N	f	\N	\N
246	Матюхина Елена Сергеевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	47.90	f	\N	f	\N	\N
247	Терехов Александр Георгиевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	47.50	f	\N	f	\N	\N
248	Нежведилов Рамазан Сулейманович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	63.20	f	\N	f	\N	\N
249	Каврук Олег Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	60.50	f	\N	f	\N	\N
250	Веселкин Евгений Вадимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	70.90	f	\N	f	\N	\N
251	Заславский Данила Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	11.82	f	\N	f	\N	\N
252	Юрьев Денис Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	46.50	f	\N	f	\N	\N
253	Терещенко Георгий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	11.82	f	\N	f	\N	\N
254	Шишкарев Иван Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.60	f	\N	f	\N	\N
255	Тюнев Сергей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.80	f	\N	f	\N	\N
256	Липша Сергей Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.20	f	\N	f	\N	\N
257	Черешнев Виталий Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.20	f	\N	f	\N	\N
258	Капранов Виталий Вячеславович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.30	f	\N	f	\N	\N
259	Пушкарев Александр Валерьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.00	f	\N	f	\N	\N
260	Дудов Ахмат Муратович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.50	f	\N	f	\N	\N
261	Кудяков Никита Алексеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	38.60	f	\N	f	\N	\N
262	Бачиев Назир Ахметович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	50.10	f	\N	f	\N	\N
263	Давыдов Роман Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	16.70	f	\N	f	\N	\N
264	Верхозин Артём Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	16.70	f	\N	f	\N	\N
265	Зайцев Евгений Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	49.40	f	\N	f	\N	\N
266	Нестеров Сергей Валерьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	65.10	f	\N	f	\N	\N
267	Марченко Иван Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	63.80	f	\N	f	\N	\N
268	Агаметов Байрамали Гаджиевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	71.30	f	\N	f	\N	\N
269	Скабелин Сергей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.80	f	\N	f	\N	\N
270	Эсетов Вадим Джамидинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.60	f	\N	f	\N	\N
271	Магомедов Магомед Эльдарович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.50	f	\N	f	\N	\N
272	Раджабов Багадур Мурадович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.10	f	\N	f	\N	\N
273	Гилаев Рафаэль Равилевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	56.30	f	\N	f	\N	\N
274	Мухаметкулов Иван Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	55.70	f	\N	f	\N	\N
275	Афанасьев Петр Олегович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	39.40	f	\N	f	\N	\N
276	Близняков Иван Константинович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	4дв.стр.15	Лидер	1	1	95.20	f	\N	f	\N	\N
277	Колотухин Андрей Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	31.50	f	\N	f	\N	\N
278	Миронов Сергей Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	29.20	f	\N	f	\N	\N
279	Кирюшин Кирилл Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	14.60	f	\N	f	\N	\N
280	Нестерчук Денис Петрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	АП	3	3	29.00	f	\N	f	\N	\N
281	Хайдуков Руслан Геннадьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	32.20	f	\N	f	\N	\N
282	Ганиев Ариф Ариф	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	49.20	f	\N	f	\N	\N
283	Локтионов Евгений Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	56.80	f	\N	f	\N	\N
284	Колокоцкий Алексей Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	49.10	f	\N	f	\N	\N
285	Кулешов Даниил Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	75.00	f	\N	f	\N	\N
286	Капорин Евгений Вадимович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	50.00	f	\N	f	\N	\N
287	Атаян Георгий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	31.50	f	\N	f	\N	\N
288	Нижиндаева Виктория Викторовна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДКП	3	3	33.50	f	\N	f	\N	\N
289	Новикова Ирина Олеговна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДСФ	3	3	31.50	f	\N	f	\N	\N
290	Вилданов Даниэль Данисович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	29.60	f	\N	f	\N	\N
291	Мащицкий Анатолий Олегович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДНД	3	3	31.90	f	\N	f	\N	\N
292	Галяс Юрий Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	70.90	f	\N	f	\N	\N
293	Яцук Татьяна Михайловна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	31.90	f	\N	f	\N	\N
294	Гамзатов Рамиз Шахбанович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	45.90	f	\N	f	\N	\N
295	Илюшина Алиса Михайловна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	АПУ	3	3	56.40	f	\N	f	\N	\N
296	Щетинин Александар Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	МТО	3	3	50.50	f	\N	f	\N	\N
297	Полохин Павел Александрович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	48.20	f	\N	f	\N	\N
298	Рязанова Екатерина Николаевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	73.70	f	\N	f	\N	\N
299	Карпов Юрий Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	УВГСЧ	3	3	48.90	f	\N	f	\N	\N
300	Зайцев Дмитрий Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	31.00	f	\N	f	\N	\N
301	Бондарь Олег Павлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДТО	3	3	55.80	f	\N	f	\N	\N
302	Бачиев Алим Ахметович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	32.50	f	\N	f	\N	\N
303	Егоровцева Олеся Витальевна	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	УИС	3	3	47.10	f	\N	f	\N	\N
304	Половников Олег Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	21.70	f	\N	f	\N	\N
305	Кубанский Александр Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДГО	3	3	32.50	f	\N	f	\N	\N
306	Марченко Алексей Николаевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	41.40	f	\N	f	\N	\N
307	Карпюк Дмитрий Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	НЦУКС	3	3	75.70	f	\N	f	\N	\N
308	Бакаев Даниил Дмитриевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	59.30	f	\N	f	\N	\N
309	Федосеев Алексей Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ЦА	3	3	51.90	f	\N	f	\N	\N
310	Костерев Дмитрий Михайлович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	53.20	f	\N	f	\N	\N
311	Петров Иван Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	3	3	52.70	f	\N	f	\N	\N
312	Кузьминов Сергей Иванович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	52.50	f	\N	f	\N	\N
313	Сурин Анатолий Евгеньевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	УИС	3	3	51.10	f	\N	f	\N	\N
314	Романов Виктор Юрьевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	34.10	f	\N	f	\N	\N
315	Гордеев Михаил Владимирович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	56.80	f	\N	f	\N	\N
316	Захаров Виталий Сергеевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	Лидер	1	1	58.20	f	\N	f	\N	\N
317	Малышкин Антон Викторович	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ЦУКС	3	3	44.40	f	\N	f	\N	\N
318	Неуймин Владислав Андреевич	$argon2id$v=19$m=65536,t=2,p=2$mTNmrNWaE0IoJaQU4ryXsg$0JLWXG43O6JqHh3ZhAzxwE/Bekj4KgS1a6thnvoxWiQ	user	32дв.стр.90	ДТО	3	3	40.20	f	\N	f	\N	\N
\.


--
-- Name: adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.adjustments_id_seq', 1, false);


--
-- Name: periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.periods_id_seq', 1, true);


--
-- Name: readings_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.readings_id_seq1', 1, true);


--
-- Name: tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tariffs_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 318, true);


--
-- Name: adjustments adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: periods periods_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_name_key UNIQUE (name);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: readings readings_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings
    ADD CONSTRAINT readings_pkey1 PRIMARY KEY (id, created_at);


--
-- Name: readings_2024 readings_2024_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2024
    ADD CONSTRAINT readings_2024_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2025 readings_2025_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2025
    ADD CONSTRAINT readings_2025_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2026 readings_2026_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2026
    ADD CONSTRAINT readings_2026_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2027 readings_2027_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2027
    ADD CONSTRAINT readings_2027_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2028 readings_2028_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2028
    ADD CONSTRAINT readings_2028_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2029 readings_2029_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2029
    ADD CONSTRAINT readings_2029_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2030 readings_2030_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2030
    ADD CONSTRAINT readings_2030_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2031 readings_2031_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2031
    ADD CONSTRAINT readings_2031_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2032 readings_2032_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2032
    ADD CONSTRAINT readings_2032_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2033 readings_2033_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2033
    ADD CONSTRAINT readings_2033_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2034 readings_2034_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2034
    ADD CONSTRAINT readings_2034_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2035 readings_2035_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2035
    ADD CONSTRAINT readings_2035_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_default readings_default_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_default
    ADD CONSTRAINT readings_default_pkey PRIMARY KEY (id, created_at);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tariffs tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_adj_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_adj_user_period ON public.adjustments USING btree (user_id, period_id);


--
-- Name: idx_reading_approved_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_approved_period ON ONLY public.readings USING btree (is_approved, period_id);


--
-- Name: idx_reading_user_approved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_user_approved ON ONLY public.readings USING btree (user_id, is_approved);


--
-- Name: idx_reading_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_user_period ON ONLY public.readings USING btree (user_id, period_id);


--
-- Name: idx_user_dormitory_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_dormitory_trgm ON public.users USING gin (dormitory public.gin_trgm_ops);


--
-- Name: idx_user_username_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_username_trgm ON public.users USING gin (username public.gin_trgm_ops);


--
-- Name: ix_adjustments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_adjustments_id ON public.adjustments USING btree (id);


--
-- Name: ix_periods_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_periods_id ON public.periods USING btree (id);


--
-- Name: ix_periods_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_periods_is_active ON public.periods USING btree (is_active);


--
-- Name: ix_system_settings_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_system_settings_key ON public.system_settings USING btree (key);


--
-- Name: ix_tariffs_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tariffs_is_active ON public.tariffs USING btree (is_active);


--
-- Name: ix_users_dormitory; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_dormitory ON public.users USING btree (dormitory);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_is_deleted; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_is_deleted ON public.users USING btree (is_deleted);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: readings_2024_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_is_approved_period_id_idx ON public.readings_2024 USING btree (is_approved, period_id);


--
-- Name: readings_2024_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_user_id_is_approved_idx ON public.readings_2024 USING btree (user_id, is_approved);


--
-- Name: readings_2024_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_user_id_period_id_idx ON public.readings_2024 USING btree (user_id, period_id);


--
-- Name: readings_2025_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_is_approved_period_id_idx ON public.readings_2025 USING btree (is_approved, period_id);


--
-- Name: readings_2025_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_user_id_is_approved_idx ON public.readings_2025 USING btree (user_id, is_approved);


--
-- Name: readings_2025_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_user_id_period_id_idx ON public.readings_2025 USING btree (user_id, period_id);


--
-- Name: readings_2026_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_is_approved_period_id_idx ON public.readings_2026 USING btree (is_approved, period_id);


--
-- Name: readings_2026_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_user_id_is_approved_idx ON public.readings_2026 USING btree (user_id, is_approved);


--
-- Name: readings_2026_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_user_id_period_id_idx ON public.readings_2026 USING btree (user_id, period_id);


--
-- Name: readings_2027_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_is_approved_period_id_idx ON public.readings_2027 USING btree (is_approved, period_id);


--
-- Name: readings_2027_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_user_id_is_approved_idx ON public.readings_2027 USING btree (user_id, is_approved);


--
-- Name: readings_2027_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_user_id_period_id_idx ON public.readings_2027 USING btree (user_id, period_id);


--
-- Name: readings_2028_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_is_approved_period_id_idx ON public.readings_2028 USING btree (is_approved, period_id);


--
-- Name: readings_2028_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_user_id_is_approved_idx ON public.readings_2028 USING btree (user_id, is_approved);


--
-- Name: readings_2028_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_user_id_period_id_idx ON public.readings_2028 USING btree (user_id, period_id);


--
-- Name: readings_2029_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_is_approved_period_id_idx ON public.readings_2029 USING btree (is_approved, period_id);


--
-- Name: readings_2029_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_user_id_is_approved_idx ON public.readings_2029 USING btree (user_id, is_approved);


--
-- Name: readings_2029_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_user_id_period_id_idx ON public.readings_2029 USING btree (user_id, period_id);


--
-- Name: readings_2030_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_is_approved_period_id_idx ON public.readings_2030 USING btree (is_approved, period_id);


--
-- Name: readings_2030_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_user_id_is_approved_idx ON public.readings_2030 USING btree (user_id, is_approved);


--
-- Name: readings_2030_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_user_id_period_id_idx ON public.readings_2030 USING btree (user_id, period_id);


--
-- Name: readings_2031_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_is_approved_period_id_idx ON public.readings_2031 USING btree (is_approved, period_id);


--
-- Name: readings_2031_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_user_id_is_approved_idx ON public.readings_2031 USING btree (user_id, is_approved);


--
-- Name: readings_2031_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_user_id_period_id_idx ON public.readings_2031 USING btree (user_id, period_id);


--
-- Name: readings_2032_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_is_approved_period_id_idx ON public.readings_2032 USING btree (is_approved, period_id);


--
-- Name: readings_2032_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_user_id_is_approved_idx ON public.readings_2032 USING btree (user_id, is_approved);


--
-- Name: readings_2032_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_user_id_period_id_idx ON public.readings_2032 USING btree (user_id, period_id);


--
-- Name: readings_2033_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_is_approved_period_id_idx ON public.readings_2033 USING btree (is_approved, period_id);


--
-- Name: readings_2033_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_user_id_is_approved_idx ON public.readings_2033 USING btree (user_id, is_approved);


--
-- Name: readings_2033_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_user_id_period_id_idx ON public.readings_2033 USING btree (user_id, period_id);


--
-- Name: readings_2034_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_is_approved_period_id_idx ON public.readings_2034 USING btree (is_approved, period_id);


--
-- Name: readings_2034_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_user_id_is_approved_idx ON public.readings_2034 USING btree (user_id, is_approved);


--
-- Name: readings_2034_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_user_id_period_id_idx ON public.readings_2034 USING btree (user_id, period_id);


--
-- Name: readings_2035_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_is_approved_period_id_idx ON public.readings_2035 USING btree (is_approved, period_id);


--
-- Name: readings_2035_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_user_id_is_approved_idx ON public.readings_2035 USING btree (user_id, is_approved);


--
-- Name: readings_2035_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_user_id_period_id_idx ON public.readings_2035 USING btree (user_id, period_id);


--
-- Name: readings_default_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_is_approved_period_id_idx ON public.readings_default USING btree (is_approved, period_id);


--
-- Name: readings_default_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_user_id_is_approved_idx ON public.readings_default USING btree (user_id, is_approved);


--
-- Name: readings_default_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_user_id_period_id_idx ON public.readings_default USING btree (user_id, period_id);


--
-- Name: readings_2024_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2024_is_approved_period_id_idx;


--
-- Name: readings_2024_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2024_pkey;


--
-- Name: readings_2024_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2024_user_id_is_approved_idx;


--
-- Name: readings_2024_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2024_user_id_period_id_idx;


--
-- Name: readings_2025_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2025_is_approved_period_id_idx;


--
-- Name: readings_2025_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2025_pkey;


--
-- Name: readings_2025_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2025_user_id_is_approved_idx;


--
-- Name: readings_2025_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2025_user_id_period_id_idx;


--
-- Name: readings_2026_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2026_is_approved_period_id_idx;


--
-- Name: readings_2026_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2026_pkey;


--
-- Name: readings_2026_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2026_user_id_is_approved_idx;


--
-- Name: readings_2026_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2026_user_id_period_id_idx;


--
-- Name: readings_2027_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2027_is_approved_period_id_idx;


--
-- Name: readings_2027_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2027_pkey;


--
-- Name: readings_2027_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2027_user_id_is_approved_idx;


--
-- Name: readings_2027_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2027_user_id_period_id_idx;


--
-- Name: readings_2028_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2028_is_approved_period_id_idx;


--
-- Name: readings_2028_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2028_pkey;


--
-- Name: readings_2028_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2028_user_id_is_approved_idx;


--
-- Name: readings_2028_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2028_user_id_period_id_idx;


--
-- Name: readings_2029_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2029_is_approved_period_id_idx;


--
-- Name: readings_2029_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2029_pkey;


--
-- Name: readings_2029_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2029_user_id_is_approved_idx;


--
-- Name: readings_2029_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2029_user_id_period_id_idx;


--
-- Name: readings_2030_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2030_is_approved_period_id_idx;


--
-- Name: readings_2030_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2030_pkey;


--
-- Name: readings_2030_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2030_user_id_is_approved_idx;


--
-- Name: readings_2030_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2030_user_id_period_id_idx;


--
-- Name: readings_2031_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2031_is_approved_period_id_idx;


--
-- Name: readings_2031_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2031_pkey;


--
-- Name: readings_2031_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2031_user_id_is_approved_idx;


--
-- Name: readings_2031_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2031_user_id_period_id_idx;


--
-- Name: readings_2032_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2032_is_approved_period_id_idx;


--
-- Name: readings_2032_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2032_pkey;


--
-- Name: readings_2032_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2032_user_id_is_approved_idx;


--
-- Name: readings_2032_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2032_user_id_period_id_idx;


--
-- Name: readings_2033_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2033_is_approved_period_id_idx;


--
-- Name: readings_2033_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2033_pkey;


--
-- Name: readings_2033_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2033_user_id_is_approved_idx;


--
-- Name: readings_2033_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2033_user_id_period_id_idx;


--
-- Name: readings_2034_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2034_is_approved_period_id_idx;


--
-- Name: readings_2034_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2034_pkey;


--
-- Name: readings_2034_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2034_user_id_is_approved_idx;


--
-- Name: readings_2034_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2034_user_id_period_id_idx;


--
-- Name: readings_2035_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2035_is_approved_period_id_idx;


--
-- Name: readings_2035_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2035_pkey;


--
-- Name: readings_2035_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2035_user_id_is_approved_idx;


--
-- Name: readings_2035_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2035_user_id_period_id_idx;


--
-- Name: readings_default_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_default_is_approved_period_id_idx;


--
-- Name: readings_default_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_default_pkey;


--
-- Name: readings_default_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_default_user_id_is_approved_idx;


--
-- Name: readings_default_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_default_user_id_period_id_idx;


--
-- Name: adjustments adjustments_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.periods(id);


--
-- Name: adjustments adjustments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: readings fk_readings_period_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.readings
    ADD CONSTRAINT fk_readings_period_id FOREIGN KEY (period_id) REFERENCES public.periods(id);


--
-- Name: readings fk_readings_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.readings
    ADD CONSTRAINT fk_readings_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: periods periods_tariff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_tariff_id_fkey FOREIGN KEY (tariff_id) REFERENCES public.tariffs(id);


--
-- Name: users users_tariff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tariff_id_fkey FOREIGN KEY (tariff_id) REFERENCES public.tariffs(id);


--
-- PostgreSQL database dump complete
--

\unrestrict j5GbUbq6U6IOPiXXtCIOD12OE28DuYUK1pma3PpxlGRX7cxCzFSgmv9ohQGfOkn

