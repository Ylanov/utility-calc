--
-- PostgreSQL database dump
--

\restrict IeL82HnmcvQXUsN2bynUFN22UuTsUc9zTvgLEz69uvdUrnPLGKOp8aD7hfK5K13

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adjustments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adjustments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    period_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    description character varying NOT NULL,
    created_at timestamp without time zone,
    account_type character varying NOT NULL
);


ALTER TABLE public.adjustments OWNER TO postgres;

--
-- Name: adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adjustments_id_seq OWNER TO postgres;

--
-- Name: adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.adjustments_id_seq OWNED BY public.adjustments.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.periods (
    id integer NOT NULL,
    name character varying NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.periods OWNER TO postgres;

--
-- Name: periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.periods_id_seq OWNER TO postgres;

--
-- Name: periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.periods_id_seq OWNED BY public.periods.id;


--
-- Name: readings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
)
PARTITION BY RANGE (created_at);


ALTER TABLE public.readings OWNER TO postgres;

--
-- Name: readings_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.readings_id_seq1
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.readings_id_seq1 OWNER TO postgres;

--
-- Name: readings_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.readings_id_seq1 OWNED BY public.readings.id;


--
-- Name: readings_2024; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2024 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2024 OWNER TO postgres;

--
-- Name: readings_2025; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2025 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2025 OWNER TO postgres;

--
-- Name: readings_2026; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2026 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2026 OWNER TO postgres;

--
-- Name: readings_2027; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2027 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2027 OWNER TO postgres;

--
-- Name: readings_2028; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2028 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2028 OWNER TO postgres;

--
-- Name: readings_2029; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2029 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2029 OWNER TO postgres;

--
-- Name: readings_2030; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2030 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2030 OWNER TO postgres;

--
-- Name: readings_2031; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2031 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2031 OWNER TO postgres;

--
-- Name: readings_2032; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2032 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2032 OWNER TO postgres;

--
-- Name: readings_2033; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2033 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2033 OWNER TO postgres;

--
-- Name: readings_2034; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2034 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2034 OWNER TO postgres;

--
-- Name: readings_2035; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_2035 (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_2035 OWNER TO postgres;

--
-- Name: readings_default; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings_default (
    id integer DEFAULT nextval('public.readings_id_seq1'::regclass) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    debt_209 numeric(12,2) DEFAULT 0.00,
    overpayment_209 numeric(12,2) DEFAULT 0.00,
    debt_205 numeric(12,2) DEFAULT 0.00,
    overpayment_205 numeric(12,2) DEFAULT 0.00,
    hot_correction numeric(12,3) DEFAULT 0.0,
    cold_correction numeric(12,3) DEFAULT 0.0,
    electricity_correction numeric(12,3) DEFAULT 0.0,
    sewage_correction numeric(12,3) DEFAULT 0.0,
    total_209 numeric(12,2) DEFAULT 0.00,
    total_205 numeric(12,2) DEFAULT 0.00,
    total_cost numeric(12,2) DEFAULT 0.00,
    cost_hot_water numeric(12,2) DEFAULT 0.00,
    cost_cold_water numeric(12,2) DEFAULT 0.00,
    cost_electricity numeric(12,2) DEFAULT 0.00,
    cost_sewage numeric(12,2) DEFAULT 0.00,
    cost_maintenance numeric(12,2) DEFAULT 0.00,
    cost_social_rent numeric(12,2) DEFAULT 0.00,
    cost_waste numeric(12,2) DEFAULT 0.00,
    cost_fixed_part numeric(12,2) DEFAULT 0.00,
    anomaly_flags character varying,
    is_approved boolean DEFAULT false
);


ALTER TABLE public.readings_default OWNER TO postgres;

--
-- Name: tariffs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tariffs (
    id integer NOT NULL,
    is_active boolean,
    valid_from timestamp without time zone,
    maintenance_repair numeric(10,4),
    social_rent numeric(10,4),
    heating numeric(10,4),
    water_heating numeric(10,4),
    water_supply numeric(10,4),
    sewage numeric(10,4),
    waste_disposal numeric(10,4),
    electricity_per_sqm numeric(10,4),
    electricity_rate numeric(10,4)
);


ALTER TABLE public.tariffs OWNER TO postgres;

--
-- Name: tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tariffs_id_seq OWNER TO postgres;

--
-- Name: tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tariffs_id_seq OWNED BY public.tariffs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying NOT NULL,
    role character varying NOT NULL,
    dormitory character varying,
    workplace character varying,
    residents_count integer,
    total_room_residents integer,
    apartment_area numeric(10,2),
    is_deleted boolean,
    totp_secret character varying,
    is_initial_setup_done boolean DEFAULT false NOT NULL,
    telegram_id character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: readings_2024; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2024 FOR VALUES FROM ('2024-01-01 00:00:00') TO ('2025-01-01 00:00:00');


--
-- Name: readings_2025; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2025 FOR VALUES FROM ('2025-01-01 00:00:00') TO ('2026-01-01 00:00:00');


--
-- Name: readings_2026; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2026 FOR VALUES FROM ('2026-01-01 00:00:00') TO ('2027-01-01 00:00:00');


--
-- Name: readings_2027; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2027 FOR VALUES FROM ('2027-01-01 00:00:00') TO ('2028-01-01 00:00:00');


--
-- Name: readings_2028; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2028 FOR VALUES FROM ('2028-01-01 00:00:00') TO ('2029-01-01 00:00:00');


--
-- Name: readings_2029; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2029 FOR VALUES FROM ('2029-01-01 00:00:00') TO ('2030-01-01 00:00:00');


--
-- Name: readings_2030; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2030 FOR VALUES FROM ('2030-01-01 00:00:00') TO ('2031-01-01 00:00:00');


--
-- Name: readings_2031; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2031 FOR VALUES FROM ('2031-01-01 00:00:00') TO ('2032-01-01 00:00:00');


--
-- Name: readings_2032; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2032 FOR VALUES FROM ('2032-01-01 00:00:00') TO ('2033-01-01 00:00:00');


--
-- Name: readings_2033; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2033 FOR VALUES FROM ('2033-01-01 00:00:00') TO ('2034-01-01 00:00:00');


--
-- Name: readings_2034; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2034 FOR VALUES FROM ('2034-01-01 00:00:00') TO ('2035-01-01 00:00:00');


--
-- Name: readings_2035; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_2035 FOR VALUES FROM ('2035-01-01 00:00:00') TO ('2036-01-01 00:00:00');


--
-- Name: readings_default; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ATTACH PARTITION public.readings_default DEFAULT;


--
-- Name: adjustments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments ALTER COLUMN id SET DEFAULT nextval('public.adjustments_id_seq'::regclass);


--
-- Name: periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods ALTER COLUMN id SET DEFAULT nextval('public.periods_id_seq'::regclass);


--
-- Name: readings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ALTER COLUMN id SET DEFAULT nextval('public.readings_id_seq1'::regclass);


--
-- Name: tariffs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tariffs ALTER COLUMN id SET DEFAULT nextval('public.tariffs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: adjustments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adjustments (id, user_id, period_id, amount, description, created_at, account_type) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
add_telegram_id_fix
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.periods (id, name, is_active, created_at) FROM stdin;
1	Начальный период	t	2026-02-27 11:25:55.692683
\.


--
-- Data for Name: readings_2024; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2024 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2025; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2025 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2026; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2026 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2027; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2027 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2028; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2028 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2029; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2029 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2030; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2030 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2031; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2031 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2032; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2032 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2033; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2033 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2034; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2034 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_2035; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_2035 (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: readings_default; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings_default (id, created_at, user_id, period_id, hot_water, cold_water, electricity, debt_209, overpayment_209, debt_205, overpayment_205, hot_correction, cold_correction, electricity_correction, sewage_correction, total_209, total_205, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved) FROM stdin;
\.


--
-- Data for Name: tariffs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tariffs (id, is_active, valid_from, maintenance_repair, social_rent, heating, water_heating, water_supply, sewage, waste_disposal, electricity_per_sqm, electricity_rate) FROM stdin;
1	t	2026-02-27 11:25:55.696387	0.0000	0.0000	0.0000	0.0000	0.0000	100.0000	0.0000	0.0000	5.0000
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, hashed_password, role, dormitory, workplace, residents_count, total_room_residents, apartment_area, is_deleted, totp_secret, is_initial_setup_done, telegram_id) FROM stdin;
1	admin	$argon2id$v=19$m=65536,t=2,p=2$/h+jdC7lfM9ZC2GMUYoR4g$pG0KpylPRA4v4FexSvZxjwDAvh4hou51sUYsqMPXxGE	accountant	\N	\N	1	1	0.00	f	\N	f	\N
2	123	$argon2id$v=19$m=65536,t=2,p=2$L+Vc613LeW8NQSgFAMA4xw$Rp+nV2UBB6fIB/52YD3tybAc/cjo1SfRZQ0OoOg3/ds	user	1	Лидер	1	1	123.00	f	\N	t	\N
\.


--
-- Name: adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.adjustments_id_seq', 1, false);


--
-- Name: periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.periods_id_seq', 1, true);


--
-- Name: readings_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.readings_id_seq1', 1, false);


--
-- Name: tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tariffs_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: adjustments adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: periods periods_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_name_key UNIQUE (name);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: readings readings_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings
    ADD CONSTRAINT readings_pkey1 PRIMARY KEY (id, created_at);


--
-- Name: readings_2024 readings_2024_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2024
    ADD CONSTRAINT readings_2024_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2025 readings_2025_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2025
    ADD CONSTRAINT readings_2025_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2026 readings_2026_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2026
    ADD CONSTRAINT readings_2026_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2027 readings_2027_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2027
    ADD CONSTRAINT readings_2027_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2028 readings_2028_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2028
    ADD CONSTRAINT readings_2028_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2029 readings_2029_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2029
    ADD CONSTRAINT readings_2029_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2030 readings_2030_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2030
    ADD CONSTRAINT readings_2030_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2031 readings_2031_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2031
    ADD CONSTRAINT readings_2031_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2032 readings_2032_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2032
    ADD CONSTRAINT readings_2032_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2033 readings_2033_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2033
    ADD CONSTRAINT readings_2033_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2034 readings_2034_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2034
    ADD CONSTRAINT readings_2034_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_2035 readings_2035_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_2035
    ADD CONSTRAINT readings_2035_pkey PRIMARY KEY (id, created_at);


--
-- Name: readings_default readings_default_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings_default
    ADD CONSTRAINT readings_default_pkey PRIMARY KEY (id, created_at);


--
-- Name: tariffs tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_adj_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_adj_user_period ON public.adjustments USING btree (user_id, period_id);


--
-- Name: idx_reading_approved_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_approved_period ON ONLY public.readings USING btree (is_approved, period_id);


--
-- Name: idx_reading_user_approved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_user_approved ON ONLY public.readings USING btree (user_id, is_approved);


--
-- Name: idx_reading_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_user_period ON ONLY public.readings USING btree (user_id, period_id);


--
-- Name: idx_user_dormitory_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_dormitory_trgm ON public.users USING gin (dormitory public.gin_trgm_ops);


--
-- Name: idx_user_username_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_username_trgm ON public.users USING gin (username public.gin_trgm_ops);


--
-- Name: ix_adjustments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_adjustments_id ON public.adjustments USING btree (id);


--
-- Name: ix_periods_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_periods_id ON public.periods USING btree (id);


--
-- Name: ix_periods_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_periods_is_active ON public.periods USING btree (is_active);


--
-- Name: ix_tariffs_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tariffs_is_active ON public.tariffs USING btree (is_active);


--
-- Name: ix_users_dormitory; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_dormitory ON public.users USING btree (dormitory);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_is_deleted; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_is_deleted ON public.users USING btree (is_deleted);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: readings_2024_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_is_approved_period_id_idx ON public.readings_2024 USING btree (is_approved, period_id);


--
-- Name: readings_2024_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_user_id_is_approved_idx ON public.readings_2024 USING btree (user_id, is_approved);


--
-- Name: readings_2024_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2024_user_id_period_id_idx ON public.readings_2024 USING btree (user_id, period_id);


--
-- Name: readings_2025_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_is_approved_period_id_idx ON public.readings_2025 USING btree (is_approved, period_id);


--
-- Name: readings_2025_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_user_id_is_approved_idx ON public.readings_2025 USING btree (user_id, is_approved);


--
-- Name: readings_2025_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2025_user_id_period_id_idx ON public.readings_2025 USING btree (user_id, period_id);


--
-- Name: readings_2026_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_is_approved_period_id_idx ON public.readings_2026 USING btree (is_approved, period_id);


--
-- Name: readings_2026_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_user_id_is_approved_idx ON public.readings_2026 USING btree (user_id, is_approved);


--
-- Name: readings_2026_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2026_user_id_period_id_idx ON public.readings_2026 USING btree (user_id, period_id);


--
-- Name: readings_2027_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_is_approved_period_id_idx ON public.readings_2027 USING btree (is_approved, period_id);


--
-- Name: readings_2027_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_user_id_is_approved_idx ON public.readings_2027 USING btree (user_id, is_approved);


--
-- Name: readings_2027_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2027_user_id_period_id_idx ON public.readings_2027 USING btree (user_id, period_id);


--
-- Name: readings_2028_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_is_approved_period_id_idx ON public.readings_2028 USING btree (is_approved, period_id);


--
-- Name: readings_2028_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_user_id_is_approved_idx ON public.readings_2028 USING btree (user_id, is_approved);


--
-- Name: readings_2028_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2028_user_id_period_id_idx ON public.readings_2028 USING btree (user_id, period_id);


--
-- Name: readings_2029_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_is_approved_period_id_idx ON public.readings_2029 USING btree (is_approved, period_id);


--
-- Name: readings_2029_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_user_id_is_approved_idx ON public.readings_2029 USING btree (user_id, is_approved);


--
-- Name: readings_2029_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2029_user_id_period_id_idx ON public.readings_2029 USING btree (user_id, period_id);


--
-- Name: readings_2030_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_is_approved_period_id_idx ON public.readings_2030 USING btree (is_approved, period_id);


--
-- Name: readings_2030_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_user_id_is_approved_idx ON public.readings_2030 USING btree (user_id, is_approved);


--
-- Name: readings_2030_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2030_user_id_period_id_idx ON public.readings_2030 USING btree (user_id, period_id);


--
-- Name: readings_2031_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_is_approved_period_id_idx ON public.readings_2031 USING btree (is_approved, period_id);


--
-- Name: readings_2031_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_user_id_is_approved_idx ON public.readings_2031 USING btree (user_id, is_approved);


--
-- Name: readings_2031_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2031_user_id_period_id_idx ON public.readings_2031 USING btree (user_id, period_id);


--
-- Name: readings_2032_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_is_approved_period_id_idx ON public.readings_2032 USING btree (is_approved, period_id);


--
-- Name: readings_2032_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_user_id_is_approved_idx ON public.readings_2032 USING btree (user_id, is_approved);


--
-- Name: readings_2032_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2032_user_id_period_id_idx ON public.readings_2032 USING btree (user_id, period_id);


--
-- Name: readings_2033_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_is_approved_period_id_idx ON public.readings_2033 USING btree (is_approved, period_id);


--
-- Name: readings_2033_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_user_id_is_approved_idx ON public.readings_2033 USING btree (user_id, is_approved);


--
-- Name: readings_2033_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2033_user_id_period_id_idx ON public.readings_2033 USING btree (user_id, period_id);


--
-- Name: readings_2034_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_is_approved_period_id_idx ON public.readings_2034 USING btree (is_approved, period_id);


--
-- Name: readings_2034_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_user_id_is_approved_idx ON public.readings_2034 USING btree (user_id, is_approved);


--
-- Name: readings_2034_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2034_user_id_period_id_idx ON public.readings_2034 USING btree (user_id, period_id);


--
-- Name: readings_2035_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_is_approved_period_id_idx ON public.readings_2035 USING btree (is_approved, period_id);


--
-- Name: readings_2035_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_user_id_is_approved_idx ON public.readings_2035 USING btree (user_id, is_approved);


--
-- Name: readings_2035_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_2035_user_id_period_id_idx ON public.readings_2035 USING btree (user_id, period_id);


--
-- Name: readings_default_is_approved_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_is_approved_period_id_idx ON public.readings_default USING btree (is_approved, period_id);


--
-- Name: readings_default_user_id_is_approved_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_user_id_is_approved_idx ON public.readings_default USING btree (user_id, is_approved);


--
-- Name: readings_default_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX readings_default_user_id_period_id_idx ON public.readings_default USING btree (user_id, period_id);


--
-- Name: readings_2024_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2024_is_approved_period_id_idx;


--
-- Name: readings_2024_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2024_pkey;


--
-- Name: readings_2024_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2024_user_id_is_approved_idx;


--
-- Name: readings_2024_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2024_user_id_period_id_idx;


--
-- Name: readings_2025_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2025_is_approved_period_id_idx;


--
-- Name: readings_2025_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2025_pkey;


--
-- Name: readings_2025_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2025_user_id_is_approved_idx;


--
-- Name: readings_2025_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2025_user_id_period_id_idx;


--
-- Name: readings_2026_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2026_is_approved_period_id_idx;


--
-- Name: readings_2026_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2026_pkey;


--
-- Name: readings_2026_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2026_user_id_is_approved_idx;


--
-- Name: readings_2026_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2026_user_id_period_id_idx;


--
-- Name: readings_2027_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2027_is_approved_period_id_idx;


--
-- Name: readings_2027_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2027_pkey;


--
-- Name: readings_2027_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2027_user_id_is_approved_idx;


--
-- Name: readings_2027_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2027_user_id_period_id_idx;


--
-- Name: readings_2028_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2028_is_approved_period_id_idx;


--
-- Name: readings_2028_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2028_pkey;


--
-- Name: readings_2028_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2028_user_id_is_approved_idx;


--
-- Name: readings_2028_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2028_user_id_period_id_idx;


--
-- Name: readings_2029_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2029_is_approved_period_id_idx;


--
-- Name: readings_2029_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2029_pkey;


--
-- Name: readings_2029_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2029_user_id_is_approved_idx;


--
-- Name: readings_2029_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2029_user_id_period_id_idx;


--
-- Name: readings_2030_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2030_is_approved_period_id_idx;


--
-- Name: readings_2030_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2030_pkey;


--
-- Name: readings_2030_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2030_user_id_is_approved_idx;


--
-- Name: readings_2030_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2030_user_id_period_id_idx;


--
-- Name: readings_2031_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2031_is_approved_period_id_idx;


--
-- Name: readings_2031_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2031_pkey;


--
-- Name: readings_2031_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2031_user_id_is_approved_idx;


--
-- Name: readings_2031_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2031_user_id_period_id_idx;


--
-- Name: readings_2032_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2032_is_approved_period_id_idx;


--
-- Name: readings_2032_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2032_pkey;


--
-- Name: readings_2032_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2032_user_id_is_approved_idx;


--
-- Name: readings_2032_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2032_user_id_period_id_idx;


--
-- Name: readings_2033_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2033_is_approved_period_id_idx;


--
-- Name: readings_2033_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2033_pkey;


--
-- Name: readings_2033_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2033_user_id_is_approved_idx;


--
-- Name: readings_2033_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2033_user_id_period_id_idx;


--
-- Name: readings_2034_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2034_is_approved_period_id_idx;


--
-- Name: readings_2034_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2034_pkey;


--
-- Name: readings_2034_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2034_user_id_is_approved_idx;


--
-- Name: readings_2034_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2034_user_id_period_id_idx;


--
-- Name: readings_2035_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_2035_is_approved_period_id_idx;


--
-- Name: readings_2035_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_2035_pkey;


--
-- Name: readings_2035_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_2035_user_id_is_approved_idx;


--
-- Name: readings_2035_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_2035_user_id_period_id_idx;


--
-- Name: readings_default_is_approved_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_approved_period ATTACH PARTITION public.readings_default_is_approved_period_id_idx;


--
-- Name: readings_default_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.readings_pkey1 ATTACH PARTITION public.readings_default_pkey;


--
-- Name: readings_default_user_id_is_approved_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_approved ATTACH PARTITION public.readings_default_user_id_is_approved_idx;


--
-- Name: readings_default_user_id_period_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_reading_user_period ATTACH PARTITION public.readings_default_user_id_period_id_idx;


--
-- Name: adjustments adjustments_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.periods(id);


--
-- Name: adjustments adjustments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: readings fk_readings_period_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.readings
    ADD CONSTRAINT fk_readings_period_id FOREIGN KEY (period_id) REFERENCES public.periods(id);


--
-- Name: readings fk_readings_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.readings
    ADD CONSTRAINT fk_readings_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict IeL82HnmcvQXUsN2bynUFN22UuTsUc9zTvgLEz69uvdUrnPLGKOp8aD7hfK5K13

