--
-- PostgreSQL database dump
--

\restrict nyjujH9eGa6aZaMHpWgRGNUVHHeNeCJAObfod0eEObUyxKTc6BaLEn3No3vF6gS

-- Dumped from database version 15.16
-- Dumped by pg_dump version 15.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adjustments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adjustments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    period_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    description character varying NOT NULL,
    created_at timestamp without time zone,
    account_type character varying NOT NULL
);


ALTER TABLE public.adjustments OWNER TO postgres;

--
-- Name: adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adjustments_id_seq OWNER TO postgres;

--
-- Name: adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.adjustments_id_seq OWNED BY public.adjustments.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.periods (
    id integer NOT NULL,
    name character varying NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.periods OWNER TO postgres;

--
-- Name: periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.periods_id_seq OWNER TO postgres;

--
-- Name: periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.periods_id_seq OWNED BY public.periods.id;


--
-- Name: readings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.readings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    period_id integer,
    hot_water numeric(12,3),
    cold_water numeric(12,3),
    electricity numeric(12,3),
    hot_correction numeric(12,3),
    cold_correction numeric(12,3),
    electricity_correction numeric(12,3),
    sewage_correction numeric(12,3),
    total_cost numeric(12,2),
    cost_hot_water numeric(12,2),
    cost_cold_water numeric(12,2),
    cost_electricity numeric(12,2),
    cost_sewage numeric(12,2),
    cost_maintenance numeric(12,2),
    cost_social_rent numeric(12,2),
    cost_waste numeric(12,2),
    cost_fixed_part numeric(12,2),
    anomaly_flags character varying,
    is_approved boolean,
    created_at timestamp without time zone,
    debt_209 numeric(12,2),
    overpayment_209 numeric(12,2),
    debt_205 numeric(12,2),
    overpayment_205 numeric(12,2),
    total_209 numeric(12,2),
    total_205 numeric(12,2)
);


ALTER TABLE public.readings OWNER TO postgres;

--
-- Name: readings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.readings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.readings_id_seq OWNER TO postgres;

--
-- Name: readings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.readings_id_seq OWNED BY public.readings.id;


--
-- Name: tariffs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tariffs (
    id integer NOT NULL,
    is_active boolean,
    valid_from timestamp without time zone,
    maintenance_repair numeric(10,4),
    social_rent numeric(10,4),
    heating numeric(10,4),
    water_heating numeric(10,4),
    water_supply numeric(10,4),
    sewage numeric(10,4),
    waste_disposal numeric(10,4),
    electricity_per_sqm numeric(10,4),
    electricity_rate numeric(10,4)
);


ALTER TABLE public.tariffs OWNER TO postgres;

--
-- Name: tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tariffs_id_seq OWNER TO postgres;

--
-- Name: tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tariffs_id_seq OWNED BY public.tariffs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying NOT NULL,
    role character varying NOT NULL,
    dormitory character varying,
    workplace character varying,
    residents_count integer,
    total_room_residents integer,
    apartment_area numeric(10,2),
    is_deleted boolean,
    totp_secret character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: adjustments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments ALTER COLUMN id SET DEFAULT nextval('public.adjustments_id_seq'::regclass);


--
-- Name: periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods ALTER COLUMN id SET DEFAULT nextval('public.periods_id_seq'::regclass);


--
-- Name: readings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings ALTER COLUMN id SET DEFAULT nextval('public.readings_id_seq'::regclass);


--
-- Name: tariffs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tariffs ALTER COLUMN id SET DEFAULT nextval('public.tariffs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: adjustments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adjustments (id, user_id, period_id, amount, description, created_at, account_type) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
69b925d46c53
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.periods (id, name, is_active, created_at) FROM stdin;
1	Начальный период	t	2026-02-24 07:23:05.430122
\.


--
-- Data for Name: readings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.readings (id, user_id, period_id, hot_water, cold_water, electricity, hot_correction, cold_correction, electricity_correction, sewage_correction, total_cost, cost_hot_water, cost_cold_water, cost_electricity, cost_sewage, cost_maintenance, cost_social_rent, cost_waste, cost_fixed_part, anomaly_flags, is_approved, created_at, debt_209, overpayment_209, debt_205, overpayment_205, total_209, total_205) FROM stdin;
\.


--
-- Data for Name: tariffs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tariffs (id, is_active, valid_from, maintenance_repair, social_rent, heating, water_heating, water_supply, sewage, waste_disposal, electricity_per_sqm, electricity_rate) FROM stdin;
1	t	2026-02-24 07:23:05.433496	32.4100	28.0700	24.0200	450.8200	205.4400	258.4400	8.4300	0.0000	7.1600
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, hashed_password, role, dormitory, workplace, residents_count, total_room_residents, apartment_area, is_deleted, totp_secret) FROM stdin;
2	Емельяненко Михаил Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	49.50	f	\N
3	Матус Антон Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	44.50	f	\N
4	Жданов Николай Федорович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	47.00	f	\N
5	Косенко Екатерина Васильевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	2	2	68.60	f	\N
6	Лушников Анатолий Викторович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	66.40	f	\N
7	Алискеров Тимур Шихрагимович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	63.50	f	\N
8	Корепанов Андрей Васильевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	65.00	f	\N
9	Орлов Алексей Васильевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	43.70	f	\N
10	Лагутин Николай Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	49.00	f	\N
11	Семенцов Алексей Юрьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	45.80	f	\N
12	Почекунин Александр Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	48.90	f	\N
13	Бельков Юрий Иванович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	44.90	f	\N
14	Осипов Павел Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	66.20	f	\N
15	Каримов Булат Ильфатович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	68.50	f	\N
16	Мальков Дмитрий Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	60.30	f	\N
17	Олейник Елена Александровна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	ЦА	1	1	63.20	f	\N
18	Карачевцев Алексей Анатольевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	64.90	f	\N
19	Покидин Николай Валентинович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	ЦА	1	1	44.30	f	\N
20	Лучка Александр Павлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	ЦА	2	2	64.90	f	\N
21	Волков Владимир Игоревич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	47.80	f	\N
22	Пушкарев Александр Вячеславович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	47.30	f	\N
23	Резунов Роман Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	3	3	47.10	f	\N
24	Керн Ольга Алексеевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	49.40	f	\N
25	Пегарьков Александр Вячеславович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	47.90	f	\N
26	Иваницкий Константин Васильевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	64.70	f	\N
27	Арцаев Руслан Султанович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	66.40	f	\N
28	Вагидов Руслан Мирзалиевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	66.80	f	\N
29	Панасецкий Петр Петрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	64.10	f	\N
30	Панкратов Иван Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	45.80	f	\N
31	Семченкова Валерия Андреевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	НЦУКС	3	3	64.30	f	\N
32	Кешоков Азамат Ахмедович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	49.10	f	\N
33	Душин Дмитрий Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	47.90	f	\N
34	Завацкий Алексей Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	45.90	f	\N
35	Семенченко Никита Олегович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	46.40	f	\N
36	Прокопенко Максим Борисович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	65.60	f	\N
37	Шевченко Александр Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	65.70	f	\N
38	Черняев Максим Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	61.90	f	\N
39	Смирнов Александр Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	63.90	f	\N
40	Мироненко Александр Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	44.50	f	\N
41	Андросов Сергей Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	64.90	f	\N
42	Ильин Никита Юрьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	47.80	f	\N
43	Ревин Денис Викторович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	47.40	f	\N
44	Глушакова Анастасия Олеговна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	44.80	f	\N
45	Еремин Павел Васильевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	45.70	f	\N
46	Резевский Виктор Викторович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	47.20	f	\N
47	Айвазов Халил Кашалыевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	65.30	f	\N
48	Азимов Виталий Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	64.90	f	\N
49	Таранюк Алексей Валерьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	61.90	f	\N
50	Гюрджян Сергей Левонович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	64.80	f	\N
51	Платов Денис Максимович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	44.50	f	\N
52	Мурадов Руслан Фикретович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	65.20	f	\N
53	Мурнаев Никита Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	48.00	f	\N
54	Дибирасулаев Тимур Магамедович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	Лидер	1	1	48.40	f	\N
55	Кузнецов Виталий Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	46.30	f	\N
56	Запарин Михаил Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	47.30	f	\N
57	Кудрявцев Владимир Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	32.30	f	\N
58	Кулешов Максим Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	28.90	f	\N
59	Юриков Даниил Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.50	f	\N
60	Попков Максим Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.20	f	\N
61	Рыбальченко Сергей Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	42.10	f	\N
62	Атиков Илия Рафаэльевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.20	f	\N
63	Джиоев Георгий Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	15.10	f	\N
64	Осипов Руслан Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	47.30	f	\N
65	Струкова Ольга Сергеевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	45.60	f	\N
66	Седякин Игорь Иванович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	48.10	f	\N
67	Крючков Артем Геннадьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	29.00	f	\N
68	Прохоренко Константин Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.10	f	\N
69	Кармов Беслан Ризуанович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.70	f	\N
70	Снегирева Людмила Валерьевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	2	2	32.40	f	\N
71	Хабибулин Данила Романович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	3	3	28.70	f	\N
72	Нурмагамедов Абдулнасир Магомедович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.70	f	\N
73	Дуденко Максим Игоревич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	32.00	f	\N
74	Соловьев Евгений Витальевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.80	f	\N
75	Смирнов Максим Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.90	f	\N
76	Левшин Александр Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.90	f	\N
77	Закамалдин Андрей Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	45.60	f	\N
78	Ярощук Александр Павлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.50	f	\N
79	Беленьких Андрей Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	45.80	f	\N
80	Чернов Сергей Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	45.40	f	\N
81	Чаптыков Роман Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	49.90	f	\N
82	Чистяков Николай Юрьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	АД	3	3	29.00	f	\N
83	Шорошева Наталья Валентиновна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	2	2	31.10	f	\N
84	Муртазина Алия Мифтяхотдиновна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	32.40	f	\N
85	Тихонова Оксана Игоревна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	НТУ	3	3	32.70	f	\N
86	Гребенькова Ксения Юрьевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	29.30	f	\N
87	Сабаткоев Казбек Аланович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.50	f	\N
88	Колемагин Дмитрий Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.60	f	\N
89	Фахреев Альберт Тимурович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	33.70	f	\N
90	Сорокин Александр Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	32.30	f	\N
91	Сорокин Сергей Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	32.20	f	\N
92	Хизанашвили Михаил Ясонович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	32.10	f	\N
93	Безродний Сергей Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.20	f	\N
94	Мясников Даниил Геннадьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.10	f	\N
95	Косынкин Даниил Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	33.20	f	\N
96	Данилов Дмитрий Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	45.60	f	\N
97	Дронин Константин Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	29.90	f	\N
98	Анюхин Роман Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	45.80	f	\N
99	Писарев Александр Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	44.60	f	\N
100	Дегтярев Владислав Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	47.20	f	\N
101	Подловилин Давид Витальевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	3	3	27.70	f	\N
102	Катунькина Иннеса Ивановна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.50	f	\N
103	Грибач Виталий Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	ЦА	1	1	31.20	f	\N
104	Пинских Юрий Игоревич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.50	f	\N
105	Бендас Вадим Родионович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	29.60	f	\N
106	Тюрин Александр Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.10	f	\N
107	Куликов Сергей Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.60	f	\N
108	Шуянов Иван Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	32.20	f	\N
109	Вастаев Валерий Сидорович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.70	f	\N
110	Лапатько Кирилл Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	32.10	f	\N
111	Кочелаев Денис Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.80	f	\N
112	Приходченков Игорь Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	31.50	f	\N
113	Кондратьева Мария Александровна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	27.10	f	\N
114	Степанков Дмитрий Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	30.20	f	\N
115	Ермолаев Игорь Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	15.10	f	\N
116	Рудь Руслан Рамазанович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	15.10	f	\N
117	Смолин Кирилл Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	29.10	f	\N
118	Мальков Сергей Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	3	3	14.55	f	\N
119	Тищенко Максим Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	14.55	f	\N
120	Хруберов Кирилл Игоревич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	33.10	f	\N
121	Залитдинов Шарапутдин Залитдинович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	11.03	f	\N
122	Война Владислав Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	33.60	f	\N
123	Лисник Кирилл Борисович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	8.40	f	\N
124	Попелов Алексей Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	8.40	f	\N
125	Жуков Савелий Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	8.40	f	\N
126	Серый Артем Вячеславович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	16.80	f	\N
127	Тарасов Валерий Вячеславович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	16.80	f	\N
128	Том Богдан Игоревич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	10.66	f	\N
129	Кудинов Максим Юрьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	10.66	f	\N
130	Арутюнян Арман Горович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	10.66	f	\N
131	Смирнов Даниил Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	14.80	f	\N
132	Чекалин Александр Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	34.00	f	\N
133	Тер-Саакян Даниил Витальевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	11.34	f	\N
134	Легконогих Александр Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.8	Лидер	1	1	11.34	f	\N
135	Югай Арсений Анатольевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.9	\N	1	1	19.64	f	\N
136	Усатая Елена Павловна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.7	Лидер	2	2	45.00	f	\N
137	Никитина Екатерина Александровна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.7	Лидер	2	2	36.00	f	\N
138	Агуреев Валерий Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.7	Лидер	2	2	13.60	f	\N
139	Бирюлькин Михаил Анатольевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.7	Лидер	2	2	36.00	f	\N
140	Сивицкая Елена Олеговна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.7	Лидер	2	2	37.00	f	\N
141	Конопихин Евгений Леонидович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.7	Лидер	2	2	16.00	f	\N
142	Приходько Алена Игоревна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.7	Лидер	1	1	31.00	f	\N
143	Умнов Михаил Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	ОК	Лидер	1	1	46.10	f	\N
144	Меликов Санжарбек Ашуралиевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	ОК	Лидер	1	1	23.05	f	\N
145	Матисон Игорь Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	61.80	f	\N
146	Белов Иван Максимович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	8.83	f	\N
147	Терехов Максим Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	8.83	f	\N
148	Рыбин Павел Васильевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	15.50	f	\N
149	Гуков Эльдар Альбертович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	8.83	f	\N
150	Прасков Николай Валентинович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	49.50	f	\N
151	Власов Станислав Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	24.75	f	\N
152	Очетов Евгений Леонтьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	50.30	f	\N
153	Шаргаев Дмитрий Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	16.77	f	\N
154	Кондрашов Герман Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	16.77	f	\N
155	Гурин Дмитрий Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	44.80	f	\N
156	Тихон Михаил Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	14.94	f	\N
157	Серебряков Валерий Аркадьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	15.50	f	\N
158	Муравьев Павел Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	44.90	f	\N
159	Шелюков Виктор Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	14.97	f	\N
160	Мороз Артем Анатольевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	15.95	f	\N
161	Гасымов Рамиз Рассадин Оглы	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	\N	1	1	42.60	f	\N
162	Акбашев Ильфат Ильдарович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	14.20	f	\N
163	Соколов Илья Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	38.10	f	\N
164	Аникин Альберт Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	9.53	f	\N
165	Буйнов Марк Геннадьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	35.20	f	\N
166	Абдулкеримов Арсен Гайдарович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	11.74	f	\N
167	Смирнов Руслан Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.18	Лидер	1	1	11.74	f	\N
168	Хрипачев Андрей Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	47.64	f	\N
169	Устимов Роман Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	50.72	f	\N
170	Оболенская Кира Олеговна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	31.60	f	\N
171	Никольский Дмитрий Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	31.70	f	\N
172	Дарий Андрей Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	34.00	f	\N
173	Солоденко Роман Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	46.90	f	\N
174	Баскаков Андрей Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	31.70	f	\N
175	Шаховский Дмитрий Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	30.50	f	\N
176	Валкович Андрей Петрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	34.30	f	\N
177	Безруков Михаил Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.40	f	\N
178	Калачев Вадим Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	47.40	f	\N
179	Токтаев Илья Олегович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	34.00	f	\N
180	Муталиев Ахмед Русланович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	52.50	f	\N
181	Бульдина Наждежда Юрьевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	ЦСИ	3	3	29.00	f	\N
182	Семкина Вера Васильевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	33.60	f	\N
183	Михалева Алена Борисовна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	35.60	f	\N
184	Кривушин Илья Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	35.20	f	\N
185	Квасникова Вера Михайловна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	35.70	f	\N
186	Федоров Иван Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	34.20	f	\N
187	Сафаров Сахиб Гаджибаба-оглу	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	3	3	34.40	f	\N
188	Саттарова Ряися Маратовна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	33.00	f	\N
189	Сергиенко Оксана Геннадьевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	45.00	f	\N
190	Быков Захар Игоревич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	29.90	f	\N
191	Ширяев Андрей Игоревич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.40	f	\N
192	Смирнов Максим Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	48.30	f	\N
193	Абукаров Марат Мурадович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	30.90	f	\N
194	Халваши Георгий Малхазович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	30.20	f	\N
195	Звезда Антон Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.30	f	\N
196	Тверяхин Вадим Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.20	f	\N
197	Кононов Степан Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.70	f	\N
198	Джапбаров Осман Тимирбулатович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.20	f	\N
199	Шмыров Вадим Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.60	f	\N
200	Сулейманов Халид Рамазанович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	28.90	f	\N
201	Никитин Андрей Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	31.50	f	\N
202	Марченко Алексей Иванович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	35.10	f	\N
203	Гагиев Давид Роландович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.90	f	\N
204	Науменко Сергей Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	35.70	f	\N
205	Никитин Алексей Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	35.30	f	\N
206	Маняев Иван Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.80	f	\N
207	Степаненко Андрей Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.00	f	\N
208	Байков Николай Васильевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	46.70	f	\N
209	Теплоухов Никита Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.50	f	\N
210	Мимонова Виктория Владимировна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	3	3	29.70	f	\N
211	Шпаков Анатолий Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.30	f	\N
212	Назаретян Мнацакан Генрихович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	48.70	f	\N
213	Степанков Михаил Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.00	f	\N
214	Гареев Артур Радифович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	НЦУКС	3	3	31.40	f	\N
215	Ананьева Ирина Сергеевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	34.20	f	\N
216	Ланина Маргарита Сергеевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.10	f	\N
217	Селезнева Валентина Ивановна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	33.80	f	\N
218	Неметуллаева Арзу Рафиковна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	2	2	33.70	f	\N
219	Азязов Александр Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	28.30	f	\N
220	Шигапов Ришат Фаридович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.00	f	\N
221	Григорян Евгений Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	34.50	f	\N
222	Курносов Евгений Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	34.70	f	\N
223	Шумилова Лилия Сергеевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.10	f	\N
224	Хайбуллин Артем Ильсурович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.50	f	\N
225	Галко Семен Васильевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	46.40	f	\N
226	Похиленко Евгений Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.60	f	\N
227	Якубов Мухаммед Абдусаломович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	29.80	f	\N
228	Глоба Илья Константинович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.70	f	\N
229	Ишниязов Шухрат Саидович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	49.70	f	\N
230	Бекетов Никита Викторович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	30.00	f	\N
231	Шиян Александр Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	31.10	f	\N
232	Абдулмеджидов Руслан Рагимович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	34.00	f	\N
233	Коблев Мурат Мухамедович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	17.00	f	\N
234	Власенко Максим Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	49.20	f	\N
235	Горшкова Ольга Викторовна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	ДСФ	3	3	33.30	f	\N
236	Федотов Антон Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	44.20	f	\N
237	Есин Александр Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	32.80	f	\N
238	Бареев Радик Маликович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	53.60	f	\N
239	Матюхин Илья Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	65.40	f	\N
240	Ленский Дмитрий Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	51.00	f	\N
241	Каштанов Александр Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.50	f	\N
242	Шустров Алексей Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	3	3	48.20	f	\N
243	Забабурин Андрей Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	33.70	f	\N
244	Фомичев Павел Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	34.50	f	\N
245	Дробков Юрий Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.5	Лидер	1	1	29.70	f	\N
246	Матюхина Елена Сергеевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	47.90	f	\N
247	Терехов Александр Георгиевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	47.50	f	\N
248	Нежведилов Рамазан Сулейманович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	63.20	f	\N
249	Каврук Олег Иванович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	60.50	f	\N
250	Веселкин Евгений Вадимович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	70.90	f	\N
251	Заславский Данила Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	11.82	f	\N
252	Юрьев Денис Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	46.50	f	\N
253	Терещенко Георгий Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	11.82	f	\N
254	Шишкарев Иван Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	56.60	f	\N
255	Тюнев Сергей Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	55.80	f	\N
256	Липша Сергей Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	55.20	f	\N
257	Черешнев Виталий Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	55.20	f	\N
258	Капранов Виталий Вячеславович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	55.30	f	\N
259	Пушкарев Александр Валерьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	56.00	f	\N
260	Дудов Ахмат Муратович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	55.50	f	\N
261	Кудяков Никита Алексеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	38.60	f	\N
262	Бачиев Назир Ахметович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	50.10	f	\N
263	Давыдов Роман Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	16.70	f	\N
264	Верхозин Артём Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	16.70	f	\N
265	Зайцев Евгений Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	49.40	f	\N
266	Нестеров Сергей Валерьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	65.10	f	\N
267	Марченко Иван Иванович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	63.80	f	\N
268	Агаметов Байрамали Гаджиевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	71.30	f	\N
269	Скабелин Сергей Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	56.80	f	\N
270	Эсетов Вадим Джамидинович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	55.60	f	\N
271	Магомедов Магомед Эльдарович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	56.50	f	\N
272	Раджабов Багадур Мурадович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	56.10	f	\N
273	Гилаев Рафаэль Равилевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	56.30	f	\N
274	Мухаметкулов Иван Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	55.70	f	\N
275	Афанасьев Петр Олегович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	39.40	f	\N
276	Близняков Иван Константинович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	4дв.стр.15	Лидер	1	1	95.20	f	\N
277	Колотухин Андрей Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	31.50	f	\N
278	Миронов Сергей Юрьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	29.20	f	\N
279	Кирюшин Кирилл Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	14.60	f	\N
280	Нестерчук Денис Петрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	АП	3	3	29.00	f	\N
281	Хайдуков Руслан Геннадьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	32.20	f	\N
282	Ганиев Ариф Ариф	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	49.20	f	\N
283	Локтионов Евгений Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	56.80	f	\N
284	Колокоцкий Алексей Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	49.10	f	\N
285	Кулешов Даниил Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	3	3	75.00	f	\N
286	Капорин Евгений Вадимович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	50.00	f	\N
287	Атаян Георгий Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	3	3	31.50	f	\N
288	Нижиндаева Виктория Викторовна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	ДКП	3	3	33.50	f	\N
289	Новикова Ирина Олеговна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	ДСФ	3	3	31.50	f	\N
290	Вилданов Даниэль Данисович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	29.60	f	\N
291	Мащицкий Анатолий Олегович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	ДНД	3	3	31.90	f	\N
292	Галяс Юрий Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	3	3	70.90	f	\N
293	Яцук Татьяна Михайловна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	31.90	f	\N
294	Гамзатов Рамиз Шахбанович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	45.90	f	\N
295	Илюшина Алиса Михайловна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	АПУ	3	3	56.40	f	\N
296	Щетинин Александар Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	МТО	3	3	50.50	f	\N
297	Полохин Павел Александрович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	48.20	f	\N
298	Рязанова Екатерина Николаевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	73.70	f	\N
299	Карпов Юрий Иванович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	УВГСЧ	3	3	48.90	f	\N
300	Зайцев Дмитрий Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	31.00	f	\N
301	Бондарь Олег Павлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	ДТО	3	3	55.80	f	\N
302	Бачиев Алим Ахметович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	32.50	f	\N
303	Егоровцева Олеся Витальевна	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	УИС	3	3	47.10	f	\N
304	Половников Олег Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	21.70	f	\N
305	Кубанский Александр Викторович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	ДГО	3	3	32.50	f	\N
306	Марченко Алексей Николаевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	41.40	f	\N
307	Карпюк Дмитрий Викторович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	НЦУКС	3	3	75.70	f	\N
308	Бакаев Даниил Дмитриевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	3	3	59.30	f	\N
309	Федосеев Алексей Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	ЦА	3	3	51.90	f	\N
310	Костерев Дмитрий Михайлович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	53.20	f	\N
311	Петров Иван Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	3	3	52.70	f	\N
312	Кузьминов Сергей Иванович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	52.50	f	\N
313	Сурин Анатолий Евгеньевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	УИС	3	3	51.10	f	\N
314	Романов Виктор Юрьевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	34.10	f	\N
315	Гордеев Михаил Владимирович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	56.80	f	\N
316	Захаров Виталий Сергеевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	Лидер	1	1	58.20	f	\N
317	Малышкин Антон Викторович	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	ЦУКС	3	3	44.40	f	\N
318	Неуймин Владислав Андреевич	$2b$12$TDuVtnbz9EPhXTSJ2aUbZ.LMBYtKIY2MeSYmrCE/dM02AbXtGrPo2	user	32дв.стр.90	ДТО	3	3	40.20	f	\N
319	fin1	$2b$12$cGJ/YqZdUVRvgFLLEnhhuO9EZEGlqZsxL/lDIDIFie5/9WO/zGrxm	financier	1	Лидер	1	1	1.00	f	\N
1	admin	$argon2id$v=19$m=65536,t=2,p=2$tNZ6L+W8d47RuhcCYKwVIg$YQgyHZuBhe4eIbAATtmkNdfjbhhVes7B/j0hMSrnt9k	accountant	\N	\N	1	1	0.00	f	\N
\.


--
-- Name: adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.adjustments_id_seq', 1, false);


--
-- Name: periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.periods_id_seq', 1, true);


--
-- Name: readings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.readings_id_seq', 1, false);


--
-- Name: tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tariffs_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 319, true);


--
-- Name: adjustments adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: periods periods_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_name_key UNIQUE (name);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: readings readings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings
    ADD CONSTRAINT readings_pkey PRIMARY KEY (id);


--
-- Name: tariffs tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_adj_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_adj_user_period ON public.adjustments USING btree (user_id, period_id);


--
-- Name: idx_reading_approved_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_approved_period ON public.readings USING btree (is_approved, period_id);


--
-- Name: idx_reading_user_approved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_user_approved ON public.readings USING btree (user_id, is_approved);


--
-- Name: idx_reading_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reading_user_period ON public.readings USING btree (user_id, period_id);


--
-- Name: idx_user_dormitory_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_dormitory_trgm ON public.users USING gin (dormitory public.gin_trgm_ops);


--
-- Name: idx_user_username_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_username_trgm ON public.users USING gin (username public.gin_trgm_ops);


--
-- Name: ix_adjustments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_adjustments_id ON public.adjustments USING btree (id);


--
-- Name: ix_periods_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_periods_id ON public.periods USING btree (id);


--
-- Name: ix_periods_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_periods_is_active ON public.periods USING btree (is_active);


--
-- Name: ix_readings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_readings_id ON public.readings USING btree (id);


--
-- Name: ix_tariffs_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tariffs_is_active ON public.tariffs USING btree (is_active);


--
-- Name: ix_users_dormitory; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_dormitory ON public.users USING btree (dormitory);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_is_deleted; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_is_deleted ON public.users USING btree (is_deleted);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: adjustments adjustments_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.periods(id);


--
-- Name: adjustments adjustments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adjustments
    ADD CONSTRAINT adjustments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: readings readings_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings
    ADD CONSTRAINT readings_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.periods(id);


--
-- Name: readings readings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.readings
    ADD CONSTRAINT readings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict nyjujH9eGa6aZaMHpWgRGNUVHHeNeCJAObfod0eEObUyxKTc6BaLEn3No3vF6gS

