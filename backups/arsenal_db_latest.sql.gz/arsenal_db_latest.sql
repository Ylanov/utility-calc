--
-- PostgreSQL database dump
--

\restrict KRlwUbYqSzgdXPJ3p1s4egjTluoEnSkkrIAinVt9NqCR71ZgyEqKuGaByuHpM2Z

-- Dumped from database version 15.16
-- Dumped by pg_dump version 15.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounting_objects (
    id integer NOT NULL,
    parent_id integer,
    name character varying NOT NULL,
    obj_type character varying NOT NULL
);


ALTER TABLE public.accounting_objects OWNER TO postgres;

--
-- Name: accounting_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounting_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_objects_id_seq OWNER TO postgres;

--
-- Name: accounting_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounting_objects_id_seq OWNED BY public.accounting_objects.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: arsenal_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.arsenal_users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying,
    created_at timestamp without time zone,
    role character varying,
    object_id integer
);


ALTER TABLE public.arsenal_users OWNER TO postgres;

--
-- Name: arsenal_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.arsenal_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.arsenal_users_id_seq OWNER TO postgres;

--
-- Name: arsenal_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.arsenal_users_id_seq OWNED BY public.arsenal_users.id;


--
-- Name: document_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_items (
    id integer NOT NULL,
    document_id integer,
    nomenclature_id integer,
    serial_number character varying,
    quantity integer,
    weapon_id integer
);


ALTER TABLE public.document_items OWNER TO postgres;

--
-- Name: document_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.document_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_items_id_seq OWNER TO postgres;

--
-- Name: document_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.document_items_id_seq OWNED BY public.document_items.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    doc_number character varying,
    doc_date timestamp without time zone,
    operation_date timestamp without time zone,
    operation_type character varying NOT NULL,
    source_id integer,
    target_id integer,
    comment text,
    created_at timestamp without time zone,
    author_id integer
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documents_id_seq OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: nomenclature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nomenclature (
    id integer NOT NULL,
    code character varying,
    name character varying NOT NULL,
    category character varying,
    is_numbered boolean DEFAULT true NOT NULL
);


ALTER TABLE public.nomenclature OWNER TO postgres;

--
-- Name: nomenclature_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nomenclature_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nomenclature_id_seq OWNER TO postgres;

--
-- Name: nomenclature_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nomenclature_id_seq OWNED BY public.nomenclature.id;


--
-- Name: weapon_registry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weapon_registry (
    id integer NOT NULL,
    nomenclature_id integer NOT NULL,
    serial_number character varying NOT NULL,
    year_of_manufacture integer,
    current_object_id integer,
    status integer,
    created_at timestamp without time zone,
    quantity integer
);


ALTER TABLE public.weapon_registry OWNER TO postgres;

--
-- Name: weapon_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.weapon_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.weapon_registry_id_seq OWNER TO postgres;

--
-- Name: weapon_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.weapon_registry_id_seq OWNED BY public.weapon_registry.id;


--
-- Name: accounting_objects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects ALTER COLUMN id SET DEFAULT nextval('public.accounting_objects_id_seq'::regclass);


--
-- Name: arsenal_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users ALTER COLUMN id SET DEFAULT nextval('public.arsenal_users_id_seq'::regclass);


--
-- Name: document_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items ALTER COLUMN id SET DEFAULT nextval('public.document_items_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: nomenclature id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nomenclature ALTER COLUMN id SET DEFAULT nextval('public.nomenclature_id_seq'::regclass);


--
-- Name: weapon_registry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry ALTER COLUMN id SET DEFAULT nextval('public.weapon_registry_id_seq'::regclass);


--
-- Data for Name: accounting_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounting_objects (id, parent_id, name, obj_type) FROM stdin;
1	\N	2 управление	Подразделение
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
eab29734a426
\.


--
-- Data for Name: arsenal_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.arsenal_users (id, username, hashed_password, created_at, role, object_id) FROM stdin;
2	unit_1	$argon2id$v=19$m=65536,t=3,p=4$DmGMcS7F+B/j/N+b0zpnLA$vs5FOifEu0DUbhNslm5Gk6poEw2VWjf4gLsLB61f2A0	2026-02-24 13:33:30.193788	unit_head	1
1	admin	$2b$12$btyaHUjHaq.Z7LSNIO8boO16czdjVNgv2E/AiblDTsElSgSYPrdES	2026-02-24 07:23:05.729672	admin	\N
\.


--
-- Data for Name: document_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_items (id, document_id, nomenclature_id, serial_number, quantity, weapon_id) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, doc_number, doc_date, operation_date, operation_type, source_id, target_id, comment, created_at, author_id) FROM stdin;
\.


--
-- Data for Name: nomenclature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nomenclature (id, code, name, category, is_numbered) FROM stdin;
1	5п60	АК-74М	Стрелковое	t
2	123321	АК-74	Стрелковое	t
\.


--
-- Data for Name: weapon_registry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weapon_registry (id, nomenclature_id, serial_number, year_of_manufacture, current_object_id, status, created_at, quantity) FROM stdin;
\.


--
-- Name: accounting_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounting_objects_id_seq', 1, true);


--
-- Name: arsenal_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.arsenal_users_id_seq', 2, true);


--
-- Name: document_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.document_items_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: nomenclature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nomenclature_id_seq', 2, true);


--
-- Name: weapon_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.weapon_registry_id_seq', 1, false);


--
-- Name: accounting_objects accounting_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects
    ADD CONSTRAINT accounting_objects_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: arsenal_users arsenal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users
    ADD CONSTRAINT arsenal_users_pkey PRIMARY KEY (id);


--
-- Name: document_items document_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: nomenclature nomenclature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nomenclature
    ADD CONSTRAINT nomenclature_pkey PRIMARY KEY (id);


--
-- Name: weapon_registry uix_nom_serial_obj; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT uix_nom_serial_obj UNIQUE (nomenclature_id, serial_number, current_object_id);


--
-- Name: weapon_registry weapon_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_pkey PRIMARY KEY (id);


--
-- Name: ix_accounting_objects_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_accounting_objects_id ON public.accounting_objects USING btree (id);


--
-- Name: ix_arsenal_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_arsenal_users_id ON public.arsenal_users USING btree (id);


--
-- Name: ix_arsenal_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_arsenal_users_username ON public.arsenal_users USING btree (username);


--
-- Name: ix_document_items_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_document_items_id ON public.document_items USING btree (id);


--
-- Name: ix_documents_doc_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_documents_doc_number ON public.documents USING btree (doc_number);


--
-- Name: ix_documents_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_documents_id ON public.documents USING btree (id);


--
-- Name: ix_nomenclature_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_nomenclature_code ON public.nomenclature USING btree (code);


--
-- Name: ix_nomenclature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_nomenclature_id ON public.nomenclature USING btree (id);


--
-- Name: ix_weapon_registry_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_weapon_registry_id ON public.weapon_registry USING btree (id);


--
-- Name: ix_weapon_registry_serial_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_weapon_registry_serial_number ON public.weapon_registry USING btree (serial_number);


--
-- Name: accounting_objects accounting_objects_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects
    ADD CONSTRAINT accounting_objects_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.accounting_objects(id);


--
-- Name: arsenal_users arsenal_users_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users
    ADD CONSTRAINT arsenal_users_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.accounting_objects(id);


--
-- Name: document_items document_items_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: document_items document_items_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.nomenclature(id);


--
-- Name: document_items document_items_weapon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_weapon_id_fkey FOREIGN KEY (weapon_id) REFERENCES public.weapon_registry(id);


--
-- Name: documents documents_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.arsenal_users(id);


--
-- Name: documents documents_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.accounting_objects(id);


--
-- Name: documents documents_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.accounting_objects(id);


--
-- Name: weapon_registry weapon_registry_current_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_current_object_id_fkey FOREIGN KEY (current_object_id) REFERENCES public.accounting_objects(id);


--
-- Name: weapon_registry weapon_registry_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.nomenclature(id);


--
-- PostgreSQL database dump complete
--

\unrestrict KRlwUbYqSzgdXPJ3p1s4egjTluoEnSkkrIAinVt9NqCR71ZgyEqKuGaByuHpM2Z

