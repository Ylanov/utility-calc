--
-- PostgreSQL database dump
--

\restrict H3Xd3VstfQAOftt4VfOQOBuQUgipoi4OoMz71BjWCJ80QvxIKkCeLo3uzqsKo3J

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounting_objects (
    id integer NOT NULL,
    parent_id integer,
    name character varying NOT NULL,
    obj_type character varying NOT NULL,
    mol_name character varying
);


ALTER TABLE public.accounting_objects OWNER TO postgres;

--
-- Name: accounting_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounting_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_objects_id_seq OWNER TO postgres;

--
-- Name: accounting_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounting_objects_id_seq OWNED BY public.accounting_objects.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: arsenal_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.arsenal_users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying,
    created_at timestamp without time zone,
    role character varying,
    object_id integer
);


ALTER TABLE public.arsenal_users OWNER TO postgres;

--
-- Name: arsenal_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.arsenal_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.arsenal_users_id_seq OWNER TO postgres;

--
-- Name: arsenal_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.arsenal_users_id_seq OWNED BY public.arsenal_users.id;


--
-- Name: document_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_items (
    id integer NOT NULL,
    document_id integer,
    nomenclature_id integer,
    serial_number character varying,
    quantity integer,
    weapon_id integer,
    inventory_number character varying,
    price numeric(15,2)
);


ALTER TABLE public.document_items OWNER TO postgres;

--
-- Name: document_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.document_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_items_id_seq OWNER TO postgres;

--
-- Name: document_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.document_items_id_seq OWNED BY public.document_items.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    doc_number character varying,
    doc_date timestamp without time zone,
    operation_date timestamp without time zone,
    operation_type character varying NOT NULL,
    source_id integer,
    target_id integer,
    comment text,
    created_at timestamp without time zone,
    author_id integer,
    attached_file_path character varying
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documents_id_seq OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: gsm_accounting_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_accounting_objects (
    id integer NOT NULL,
    parent_id integer,
    name character varying NOT NULL,
    obj_type character varying NOT NULL
);


ALTER TABLE public.gsm_accounting_objects OWNER TO postgres;

--
-- Name: gsm_accounting_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_accounting_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_accounting_objects_id_seq OWNER TO postgres;

--
-- Name: gsm_accounting_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_accounting_objects_id_seq OWNED BY public.gsm_accounting_objects.id;


--
-- Name: gsm_document_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_document_items (
    id integer NOT NULL,
    document_id integer,
    fuel_id integer,
    nomenclature_id integer,
    batch_number character varying,
    quantity numeric(15,3)
);


ALTER TABLE public.gsm_document_items OWNER TO postgres;

--
-- Name: gsm_document_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_document_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_document_items_id_seq OWNER TO postgres;

--
-- Name: gsm_document_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_document_items_id_seq OWNED BY public.gsm_document_items.id;


--
-- Name: gsm_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_documents (
    id integer NOT NULL,
    doc_number character varying,
    doc_date timestamp without time zone,
    operation_date timestamp without time zone,
    operation_type character varying NOT NULL,
    source_id integer,
    target_id integer,
    comment text,
    created_at timestamp without time zone,
    author_id integer
);


ALTER TABLE public.gsm_documents OWNER TO postgres;

--
-- Name: gsm_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_documents_id_seq OWNER TO postgres;

--
-- Name: gsm_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_documents_id_seq OWNED BY public.gsm_documents.id;


--
-- Name: gsm_fuel_registry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_fuel_registry (
    id integer NOT NULL,
    nomenclature_id integer NOT NULL,
    batch_number character varying NOT NULL,
    density numeric(10,4),
    current_object_id integer,
    status integer,
    quantity numeric(15,3),
    created_at timestamp without time zone
);


ALTER TABLE public.gsm_fuel_registry OWNER TO postgres;

--
-- Name: gsm_fuel_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_fuel_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_fuel_registry_id_seq OWNER TO postgres;

--
-- Name: gsm_fuel_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_fuel_registry_id_seq OWNED BY public.gsm_fuel_registry.id;


--
-- Name: gsm_nomenclature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_nomenclature (
    id integer NOT NULL,
    code character varying,
    name character varying NOT NULL,
    category character varying,
    is_packaged boolean NOT NULL
);


ALTER TABLE public.gsm_nomenclature OWNER TO postgres;

--
-- Name: gsm_nomenclature_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_nomenclature_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_nomenclature_id_seq OWNER TO postgres;

--
-- Name: gsm_nomenclature_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_nomenclature_id_seq OWNED BY public.gsm_nomenclature.id;


--
-- Name: gsm_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying,
    role character varying,
    object_id integer,
    created_at timestamp without time zone
);


ALTER TABLE public.gsm_users OWNER TO postgres;

--
-- Name: gsm_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_users_id_seq OWNER TO postgres;

--
-- Name: gsm_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_users_id_seq OWNED BY public.gsm_users.id;


--
-- Name: nomenclature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nomenclature (
    id integer NOT NULL,
    code character varying,
    name character varying NOT NULL,
    category character varying,
    is_numbered boolean DEFAULT true NOT NULL,
    default_account character varying
);


ALTER TABLE public.nomenclature OWNER TO postgres;

--
-- Name: nomenclature_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nomenclature_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nomenclature_id_seq OWNER TO postgres;

--
-- Name: nomenclature_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nomenclature_id_seq OWNED BY public.nomenclature.id;


--
-- Name: weapon_registry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weapon_registry (
    id integer NOT NULL,
    nomenclature_id integer NOT NULL,
    serial_number character varying NOT NULL,
    year_of_manufacture integer,
    current_object_id integer,
    status integer,
    created_at timestamp without time zone,
    quantity integer,
    inventory_number character varying,
    price numeric(15,2),
    account_code character varying,
    kbk character varying
);


ALTER TABLE public.weapon_registry OWNER TO postgres;

--
-- Name: weapon_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.weapon_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.weapon_registry_id_seq OWNER TO postgres;

--
-- Name: weapon_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.weapon_registry_id_seq OWNED BY public.weapon_registry.id;


--
-- Name: accounting_objects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects ALTER COLUMN id SET DEFAULT nextval('public.accounting_objects_id_seq'::regclass);


--
-- Name: arsenal_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users ALTER COLUMN id SET DEFAULT nextval('public.arsenal_users_id_seq'::regclass);


--
-- Name: document_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items ALTER COLUMN id SET DEFAULT nextval('public.document_items_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: gsm_accounting_objects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_accounting_objects ALTER COLUMN id SET DEFAULT nextval('public.gsm_accounting_objects_id_seq'::regclass);


--
-- Name: gsm_document_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items ALTER COLUMN id SET DEFAULT nextval('public.gsm_document_items_id_seq'::regclass);


--
-- Name: gsm_documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents ALTER COLUMN id SET DEFAULT nextval('public.gsm_documents_id_seq'::regclass);


--
-- Name: gsm_fuel_registry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry ALTER COLUMN id SET DEFAULT nextval('public.gsm_fuel_registry_id_seq'::regclass);


--
-- Name: gsm_nomenclature id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_nomenclature ALTER COLUMN id SET DEFAULT nextval('public.gsm_nomenclature_id_seq'::regclass);


--
-- Name: gsm_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_users ALTER COLUMN id SET DEFAULT nextval('public.gsm_users_id_seq'::regclass);


--
-- Name: nomenclature id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nomenclature ALTER COLUMN id SET DEFAULT nextval('public.nomenclature_id_seq'::regclass);


--
-- Name: weapon_registry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry ALTER COLUMN id SET DEFAULT nextval('public.weapon_registry_id_seq'::regclass);


--
-- Data for Name: accounting_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounting_objects (id, parent_id, name, obj_type, mol_name) FROM stdin;
1	\N	Склад базы (обеспечения) (наградной фонд)	Склад	Матус А. А.
2	\N	Склад базы (обеспечения) (арт. вооружение)	Склад	Матус А. А.
3	\N	Матус А. А.	Склад	Управление (спасения, эвакуации населения и сопровождения грузов) (личное имущество)
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
7e8bc3dc33d2
\.


--
-- Data for Name: arsenal_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.arsenal_users (id, username, hashed_password, created_at, role, object_id) FROM stdin;
1	admin	$argon2id$v=19$m=65536,t=2,p=2$ZQwhxFirFSIk5HzvHSOEEA$2WayPnHwNE3j3TZWPphKaM1OhjwwGZN7y5VxzWQ9mIY	2026-03-01 11:43:35.197299	admin	\N
6	unit_1	$argon2id$v=19$m=65536,t=3,p=4$/j8nhJDyHuPc+x/D+B8DYA$pzT3rsx9CGe7REzck7vjASulAkNf+hNNOtbDSWXZMaI	2026-03-01 11:45:04.181045	unit_head	1
7	unit_2	$argon2id$v=19$m=65536,t=3,p=4$AqDUOqf0XkspZYyR0hrjXA$32EuLmeASCVyKJiGetEewisOENnGNbS/oRi8ahkjOk0	2026-03-01 11:45:04.268818	unit_head	2
8	unit_3	$argon2id$v=19$m=65536,t=3,p=4$FKLUeq/1/p/z3ptzLqX0Hg$esNfFQwq4IFrD6l4AcHTSQYypyMCtosp0wRLl2b5HEE	2026-03-01 11:45:05.410489	unit_head	3
\.


--
-- Data for Name: document_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_items (id, document_id, nomenclature_id, serial_number, quantity, weapon_id, inventory_number, price) FROM stdin;
1	1	278	Б/Н-1585	1	1546	\N	4800.00
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, doc_number, doc_date, operation_date, operation_type, source_id, target_id, comment, created_at, author_id, attached_file_path) FROM stdin;
1	260Z50	2026-03-01 11:46:17.111719	2026-03-01 00:00:00	Перемещение	3	2	\N	2026-03-01 11:46:17.111723	\N	\N
\.


--
-- Data for Name: gsm_accounting_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_accounting_objects (id, parent_id, name, obj_type) FROM stdin;
\.


--
-- Data for Name: gsm_document_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_document_items (id, document_id, fuel_id, nomenclature_id, batch_number, quantity) FROM stdin;
\.


--
-- Data for Name: gsm_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_documents (id, doc_number, doc_date, operation_date, operation_type, source_id, target_id, comment, created_at, author_id) FROM stdin;
\.


--
-- Data for Name: gsm_fuel_registry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_fuel_registry (id, nomenclature_id, batch_number, density, current_object_id, status, quantity, created_at) FROM stdin;
\.


--
-- Data for Name: gsm_nomenclature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_nomenclature (id, code, name, category, is_packaged) FROM stdin;
\.


--
-- Data for Name: gsm_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_users (id, username, hashed_password, role, object_id, created_at) FROM stdin;
1	admin	$argon2id$v=19$m=65536,t=3,p=4$MUbIeQ9h7B1jzFkLwdjbmw$xpxbiFKsiQQ/YayP28GzNrFdtABPlxDqlYYz1ybg8j0	admin	\N	2026-03-01 11:43:43.071014
\.


--
-- Data for Name: nomenclature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nomenclature (id, code, name, category, is_numbered, default_account) FROM stdin;
1	\N	GLOCK модель 48 кал. 9х19 пистолет спортивный	\N	t	101.34.1
2	\N	GLOCK модель17 Gen4 MOS кал.9х19с д/с.(М13,5х1)кал.9х19пистолет	\N	t	101.34.1
3	\N	SIG SAUER мод. P320 кал. 9х19 пистолет спортивный	\N	t	101.34.1
4	\N	Бинокль Б6*30	\N	t	101.34.1
5	\N	Гвоздодер	\N	f	101.34.1
6	\N	Гражд. огнестр. оружие с нарез. стволом(спорт.пист.)ПЛК,кал.9х19мм	\N	t	101.34.1
7	\N	Гражд.огнестер.оруж. с нарез.ств.(спорт.пист.)CZ SHADOW 2,кал.9х19мм, № F087262	\N	t	101.34.1
8	\N	Гражд.огнестер.оруж. с нарез.ств.(спорт.пист.)CZ SHADOW 2,кал.9х19мм, № G306432	\N	t	101.34.1
9	\N	Гражд.огнестер.оруж. с нарез.ств.(спорт.пист.)CZ SHADOW 2,кал.9х19мм, № G327370	\N	t	101.34.1
10	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А142130	\N	t	101.34.1
11	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А142132	\N	t	101.34.1
12	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А142134	\N	t	101.34.1
13	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А144923	\N	t	101.34.1
14	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А144929	\N	t	101.34.1
15	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А144932	\N	t	101.34.1
16	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А144945	\N	t	101.34.1
17	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А146456	\N	t	101.34.1
18	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А146570	\N	t	101.34.1
19	\N	Гражд.огнестр.оружие с нарез.ств(спорт.пист)Sig SauerP320М17,кал9х19,№М17А148318	\N	t	101.34.1
20	\N	Гражд.огнестр.оружие с нарез.стволом(спорт.пист.)Glock17gen5,кал.9х19мм (BZZY459	\N	t	101.34.1
21	\N	Гражд.огнестр.оружие с нарез.стволом(спорт.пист.)Glock17gen5,кал.9х19мм	\N	t	101.34.1
22	\N	Гражд.огнестр.оружие с нарез.стволом(спорт.пист.)Glock19 gen5Rail/FS	\N	t	101.34.1
23	\N	Гражд.огнестр.оружие с нарез.стволом(спорт.пист.)Glock19gen5 MOS/FS	\N	t	101.34.1
24	\N	Гражд.огнестр.оружие с нарез.стволом(спорт.пист.)Glock19x,кал.9х19мм	\N	t	101.34.1
25	\N	Гражд.огнестр.оружие с нарез.стволом(спорт.пист.)Glock43x MOS/FS	\N	t	101.34.1
26	\N	Гражд.огнестр.оружие с нарез.стволом(спорт.пист.)Glock43x Rail/FS	\N	t	101.34.1
27	\N	Кортик военно-морской в наградном исполнении (золоченный)	\N	t	101.34.1
28	\N	Курвиметр К4-А	\N	t	101.34.1
29	\N	Молоток	\N	t	101.34.1
30	\N	Набор отверток	\N	t	101.34.1
31	\N	Настольный гравировально-фрезерный станок CNC2535AL2	\N	t	101.34.1
32	\N	Нож охотничий "Витязь-Т" 014367	\N	t	101.34.1
33	\N	Ножовка по дереву	\N	t	101.34.1
34	\N	Отвертка крестовая	\N	t	101.34.1
35	\N	Отвертка плоская	\N	t	101.34.1
36	\N	Очки ночного видения "Новик-О"	\N	t	101.34.1
37	\N	Пассатижи	\N	t	101.34.1
38	\N	Пистолет спорт.самозарядный Glock 19X Coyote Rail кал.9mm Luger Para	\N	t	101.34.1
39	\N	Пистолет спортивный Colt 1911A1, кал.45ACP	\N	t	101.34.1
40	\N	Пистолет спортивный Glock 17 gen4 кал.9х19	\N	t	101.34.1
41	\N	Пистолет спортивный Glock 17 GEN5 cal 9 mm Luger Para	\N	t	101.34.1
42	\N	Пистолет спортивный Glock 19 Gen 5 MOS/FS, 9x19	\N	t	101.34.1
43	\N	Пистолет спортивный Glock 19X Coyote Rail cal 9 mm Luger Para	\N	t	101.34.1
44	\N	Пистолет спортивный Glock 43X Rail/FS cal 9 mm Luger Para	\N	t	101.34.1
45	\N	Пистолет спортивный Glock 43X Rail/FS cal 9 mm Luger Para CDNE028	\N	t	101.34.1
46	\N	Пистолет спортивный Glock 44Rail/FS cal.22Lr	\N	t	101.34.1
47	\N	Пистолет спортивный Glock 48 Rail/FS cal 9 mm Luger Para	\N	t	101.34.1
48	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 779	\N	t	101.34.1
49	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 780	\N	t	101.34.1
50	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 781	\N	t	101.34.1
51	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 782	\N	t	101.34.1
52	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 783	\N	t	101.34.1
53	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 784	\N	t	101.34.1
54	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 785	\N	t	101.34.1
55	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 786	\N	t	101.34.1
56	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 787	\N	t	101.34.1
57	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 788	\N	t	101.34.1
58	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 829	\N	t	101.34.1
140	\N	Дальномер 1Д-18	\N	t	101.38.1
59	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 830	\N	t	101.34.1
60	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 831	\N	t	101.34.1
61	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 832	\N	t	101.34.1
62	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 833	\N	t	101.34.1
63	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 834	\N	t	101.34.1
64	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 835	\N	t	101.34.1
65	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 836	\N	t	101.34.1
66	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 837	\N	t	101.34.1
67	\N	Пистолет спортивный с нарезным стволом Glock 45 FS кал. 9x19 Parabellum CDTK 838	\N	t	101.34.1
68	\N	Пистолет спортивный самозарядный Glock модели "36" калибра .45 ACP	\N	t	101.34.1
69	\N	Плоскогубцы	\N	t	101.34.1
70	\N	Пулеулавливатель для баллистических исследований ПУ-1МУ	\N	t	101.34.1
71	\N	Радиостанция Р-32 ВЕМР.434511.056	\N	t	101.34.1
72	\N	Радиостанция Р-32 ВЕМР.434511.056 (комп)	\N	t	101.34.1
73	\N	Рулетка 5х19	\N	t	101.34.1
74	\N	Топор	\N	t	101.34.1
75	\N	Удлинитель н/к 30м	\N	t	101.34.1
76	\N	Футляр к нагану "Оружейка"	\N	t	101.34.1
77	\N	Бронежилет 6 Б23-1 размер 3 КЛЖТ  305218009 ТУ	\N	t	101.36.1
78	\N	Бронежилет общевойсковой диффер. 6 Б23-1	\N	t	101.36.1
79	\N	Кейс ударопрочный	\N	t	101.36.1
80	\N	Кэшбокс Sentry 1100	\N	t	101.36.1
81	\N	ОШУ-20 шкаф	\N	t	101.36.1
82	\N	Сейф оружейный односекционный для хранения боеприпасов к стрекл. оруж.	\N	t	101.36.1
83	\N	Сейф оружейный ШО-20АК	\N	t	101.36.1
84	\N	Стеллаж МК224	\N	t	101.36.1
85	\N	Стеллаж МК324	\N	t	101.36.1
86	\N	Тумба мобильная 432х452х610, с тремя ящиками «Система-М»	\N	t	101.36.1
87	\N	Футляр для изделия ПМ	\N	t	101.36.1
88	\N	Футляр под наградное оружие	\N	t	101.36.1
89	\N	Футляр под пистолет П-96	\N	t	101.36.1
90	\N	Шкаф архивный ШХА-900	\N	t	101.36.1
91	\N	Шкаф БП-2	\N	t	101.36.1
92	\N	Шкаф картотечный ШК-4-2Т	\N	t	101.36.1
93	\N	Шкаф металич. ШК-650	\N	t	101.36.1
94	\N	Шкаф металический оружейный ОШ-77 ПМ	\N	t	101.36.1
95	\N	Шкаф оружейный	\N	t	101.36.1
96	\N	Ящик метал. с ручкой 20х30х40	\N	t	101.36.1
97	\N	26 мм сигнальный пистолет СП-81	\N	t	101.38.1
98	\N	5,45 мм автомат АК-12	\N	t	101.38.1
99	\N	5,45 мм автомат АК-74М	\N	t	101.38.1
100	\N	5,45 мм автомат АКС-74 У	\N	t	101.38.1
101	\N	5,45 мм автомат АКС-74У	\N	t	101.38.1
102	\N	5,45 мм пист. самоз. м/г(ПСМ), инд.6П23,хим. ник. со стал. рук., в о/ф	\N	t	101.38.1
103	\N	5,45 мм пист. самоз. м/г(ПСМ), инд.6П23,хим.ник.со стал.рук.,в ор.фут.	\N	t	101.38.1
104	\N	5,45 мм пист. самозаряд. м/г (ПСМ), инд.6П23 со стал. рук., в о/ф	\N	t	101.38.1
105	\N	5,45 мм пист. самозаряд. м/г(ПСМ), инд.6П23 со стал. рук., в о/ф	\N	t	101.38.1
106	\N	5,45 мм пист. самозаряд. м/т (ПСМ), инд.6П23 со стал. рук., в о/ф	\N	t	101.38.1
107	\N	5,45 мм пистолет ПСМ	\N	t	101.38.1
108	\N	5,45 пистолет ПСМ в наградном исполнении (никел-й в орех. фут.)	\N	t	101.38.1
109	\N	7,62 мм пистолет ТТ	\N	t	101.38.1
110	\N	7,62 мм пистолет ТТ обр. 1933г.	\N	t	101.38.1
111	\N	7,62 мм револьвер "Наган"	\N	t	101.38.1
112	\N	7,62 мм револьвер Наган	\N	t	101.38.1
113	\N	7,62 мм револьвер обр. 1895г. "НАГАН"	\N	t	101.38.1
114	\N	9 мм пистолет АПБ	\N	t	101.38.1
115	\N	9 мм пистолет ГШ-18	\N	t	101.38.1
116	\N	9 мм пистолет ПМ	\N	t	101.38.1
117	\N	9 мм пистолет ПМ в наградном исполнении	\N	t	101.38.1
118	\N	9 мм пистолет ПММ	\N	t	101.38.1
119	\N	9-мм пистолет П-96М	\N	t	101.38.1
120	\N	9-мм пистолет П-96М наградной	\N	t	101.38.1
121	\N	9,0-мм пистолет Глок-26 (Glock-26)	\N	t	101.38.1
122	\N	9мм пистолет ПМ	\N	t	101.38.1
123	\N	Автомат АКС-74у 5,45 мм (544033)	\N	t	101.38.1
124	\N	Автомат АКС-74у 5,45 мм	\N	t	101.38.1
125	\N	Автомат АКС-74у 5,45мм	\N	t	101.38.1
126	\N	Бинокль 7*35	\N	t	101.38.1
127	\N	Бинокль Б 12х1	\N	t	101.38.1
128	\N	Бинокль Б 8х30	\N	t	101.38.1
129	\N	Бинокль Б10х50	\N	t	101.38.1
130	\N	Бинокль Б12-1	\N	t	101.38.1
131	\N	Бинокль Б7х35	\N	t	101.38.1
132	\N	Бинокль БИ 8х30	\N	t	101.38.1
133	\N	Бинокль носной "Байгыш-9"	\N	t	101.38.1
134	\N	Бинокль ночной "Байгыш-6У"	\N	t	101.38.1
135	\N	БП -2 Шкаф	\N	t	101.38.1
136	\N	Бронежилет "БЖСН-Ангар М"	\N	t	101.38.1
137	\N	Бронежилет "Визит-2М"	\N	t	101.38.1
138	\N	Бронежилет "Визит"	\N	t	101.38.1
139	\N	Бронешлем	\N	t	101.38.1
141	\N	Зрительная труба ЗРТ-457	\N	t	101.38.1
142	\N	Изд. АСВАТОЗ "Катран"	\N	t	101.38.1
143	\N	Изд. АСВАТОЗ "Катран"и	\N	t	101.38.1
144	\N	Изделие "Бондаж"	\N	t	101.38.1
145	\N	Изделие "Вердикт"	\N	t	101.38.1
146	\N	Изделие "Вызов"	\N	t	101.38.1
147	\N	Изделие "Грок"	\N	t	101.38.1
148	\N	Изделие "Папка"	\N	t	101.38.1
149	\N	Изделие "Удар"	\N	t	101.38.1
150	\N	Изделие 1ПН-94  (БН-3)	\N	t	101.38.1
151	\N	Карабин охотничий Вепрь 12 Молот 12/76	\N	t	101.38.1
152	\N	Каска "Витязь С"	\N	t	101.38.1
153	\N	Кейс мужской	\N	t	101.38.1
154	\N	Кортик "Генеральский" - С (в футляре)	\N	t	101.38.1
155	\N	Кэшбокс SR-8833Т(BIUE)	\N	t	101.38.1
156	\N	Лук охотничий	\N	t	101.38.1
157	\N	Массо-габаритный макет автомата Калашникова ММГ АК-74М	\N	t	101.38.1
158	\N	Металлодетектор "Сфинкс" ВМ-611	\N	t	101.38.1
159	\N	Нож цельнометаллический (Таежный-С) в наград. испол.	\N	t	101.38.1
160	\N	Нож цельнометаллический в наградном исполнении в футляре	\N	t	101.38.1
161	\N	Ночные очки "Байгыш-20А"	\N	t	101.38.1
162	\N	Огнетушитель углекислотный ОУ-3	\N	t	101.38.1
163	\N	Одеяло бронированное "ВъюкОЛ"	\N	t	101.38.1
164	\N	Оптика 4-х кратная к "Панцер-2"	\N	t	101.38.1
165	\N	Оптический прицел 4х32	\N	t	101.38.1
166	\N	Оптический прицел ПО 4х32	\N	t	101.38.1
167	\N	Оптический прицел ПО 4х43	\N	t	101.38.1
168	\N	Оптический прицел ПОСП 8х42	\N	t	101.38.1
169	\N	Портупея белая	\N	t	101.38.1
170	\N	Прицел "Гриф-2В"	\N	t	101.38.1
171	\N	Прицел 1ПН-93-1	\N	t	101.38.1
172	\N	Прицел НСПУ (1ПН-34)	\N	t	101.38.1
173	\N	Прицел НСПУ-3 (1ПН-51)	\N	t	101.38.1
174	\N	Прицел НСПУ-М (1ПН-58)	\N	t	101.38.1
175	\N	Прицел ПН-4К	\N	t	101.38.1
176	\N	Псевдобинокуляр "Байгыш-7С"	\N	t	101.38.1
177	\N	Пулеулавливатель 6а класса "Притон-М"	\N	t	101.38.1
178	\N	Револьвер РСА ТКБ 0216	\N	t	101.38.1
179	\N	Ружье одноствольное МР 153 12/76	\N	t	101.38.1
180	\N	Ружье одноствольное МР-153 12/76	\N	t	101.38.1
181	\N	Ружье одноствольное МР-153 12/89	\N	t	101.38.1
182	\N	Ружье одноствольное МР-155 12/76	\N	t	101.38.1
183	\N	Сейф для пистолетов	\N	t	101.38.1
184	\N	Сигнальный пистолет G17-S, черный, кал. 5,5 мм/10 ТК	\N	t	101.38.1
185	\N	Травматический пистолет ИЖ-799Т "Макарыч"	\N	t	101.38.1
186	\N	Футляр "Гусар"	\N	t	101.38.1
187	\N	Футляр для пистолета ПМ (наградного) "Баракуда"	\N	t	101.38.1
188	\N	Футляр для револьвера	\N	t	101.38.1
189	\N	Шлем защитный СКАТ-С1	\N	t	101.38.1
190	\N	Шлем полимерный	\N	t	101.38.1
191	\N	Шлем полимерный с забралом	\N	t	101.38.1
192	\N	Шлем стальной	\N	t	101.38.1
193	\N	Шлем стальной с забралом	\N	t	101.38.1
194	\N	Штык-нож к АКС-74 (6х5) свободного наличия	\N	t	101.38.1
195	\N	Штык-нож к АКС-74 к автоматам	\N	t	101.38.1
196	\N	Лампа светодиодная тип 1	\N	f	105.34.1
197	\N	Бронежилет "Спецназ МЧС"	\N	f	105.35.1
198	\N	Бронежилет "Спецназ" исполнение СТ-В (Бр5)	\N	f	105.35.1
199	\N	Защитный шлем "Тор"	\N	f	105.35.1
200	\N	Защитный шлем "Тор" КЛЖТ.305232.024-03	\N	f	105.35.1
201	\N	Защитный шлем "Тор" КЛЖТ.305232.024-04	\N	f	105.35.1
202	\N	Защитный шлем "Тор" КЛЖТ.305232.024-05	\N	f	105.35.1
203	\N	Очки защитные "Кондор"	\N	f	105.35.1
204	\N	Очки защитные "Стрелок"	\N	f	105.35.1
205	\N	Чехол на бронешлем СКАТ-С1	\N	f	105.35.1
206	\N	Чехол на бронешлем СШ-60	\N	f	105.35.1
207	\N	5,45 мм автоматный патрон с пулей Т	\N	f	105.36.1
208	\N	5,45 мм патрон пистолетный МПЦ	\N	f	105.36.1
209	\N	5,45 мм патрон с обыкновенной пулей и стальной гильзой, 5,45 ПС гс (7Н6), 1 кат.	\N	f	105.36.1
210	\N	5,45 мм патроны Т	\N	f	105.36.1
211	\N	7.62 мм патроны П	\N	f	105.36.1
212	\N	7.62 мм пистолетный патрон	\N	f	105.36.1
213	\N	7.62 мм револьверный патрон	\N	f	105.36.1
214	\N	7.62 мм револьверный патрон со свинцовым сердечником 7,62 Р гл (Н-122), 1 кат	\N	f	105.36.1
215	\N	9 мм патрон П	\N	f	105.36.1
216	\N	9 мм патрон пистолетный спортивный Makarov, партия РМ 12	\N	f	105.36.1
217	\N	9 мм патроны П	\N	f	105.36.1
218	\N	9 мм пистолетный патрон с пулей со стальным сердечником	\N	f	105.36.1
219	\N	9-мм пистолетный патрон с пулей повышенной пробиваемости	\N	f	105.36.1
220	\N	Боек ИЖ-79	\N	f	105.36.1
221	\N	Взрывпакеты	\N	f	105.36.1
222	\N	Винт рукоятки ИЖ-79	\N	f	105.36.1
223	\N	Кабура штатная ПМ	\N	f	105.36.1
224	\N	Кобура "Наган" поясная закрытая штатная	\N	f	105.36.1
225	\N	Кобура ГШ-18 поясная	\N	f	105.36.1
226	\N	Кобура кожанная поясная к пистолету Макарова	\N	f	105.36.1
227	\N	Кобура поясная кожаная	\N	f	105.36.1
228	\N	Кобура поясная П-96 " Скат" закрытая с чехлом	\N	f	105.36.1
229	\N	Кобура поясная ПМ "Скат" закрытая с чехлом	\N	f	105.36.1
230	\N	Кобура поясная ТТ формованная короткая	\N	f	105.36.1
231	\N	Кобура ТТ штатная в комплетная с тренчиком	\N	f	105.36.1
232	\N	Колодка КР 16х9	\N	f	105.36.1
233	\N	Колодка под 30 патронов 5,45х39-мм	\N	f	105.36.1
234	\N	Колодка резиновая КР 30х5,45 к АК	\N	f	105.36.1
235	\N	Колодки резиновые КР 16*9	\N	f	105.36.1
236	\N	Курок ИЖ-79	\N	f	105.36.1
237	\N	Магазин ПМ	\N	f	105.36.1
238	\N	НСП оранжевого дыма	\N	f	105.36.1
239	\N	Охотничий патрон .45AUTO Win 230Gr FMJ	\N	f	105.36.1
240	\N	Патрон 5,45 мм МПЦ	\N	f	105.36.1
241	\N	Патрон 5,45 мм Т	\N	f	105.36.1
242	\N	Патрон 7,62 мм Р	\N	f	105.36.1
243	\N	Патрон 9х19	\N	f	105.36.1
244	\N	Патрон дробовой охотничий кал.12/76	\N	f	105.36.1
245	\N	Патрон холостой модернизированный 5,45 мм, инд. 7Х3М	\N	f	105.36.1
246	\N	Патроны 9х19 Luger (9х19) FMJ	\N	f	105.36.1
247	\N	Патроны к газовому оружию с резинов. пулей	\N	f	105.36.1
248	\N	Патроны охотничьи дробовые 12 кал.	\N	f	105.36.1
249	\N	Перевязь	\N	f	105.36.1
250	\N	Подвес штык-ножа	\N	f	105.36.1
251	\N	Подставка для ПЯ	\N	f	105.36.1
252	\N	Подсумок под зап. маг. ГШ-18	\N	f	105.36.1
253	\N	Подсумок под зап. маг. ПМ	\N	f	105.36.1
254	\N	Предохранитель ИЖ-79	\N	f	105.36.1
255	\N	Пружина боевая  ИЖ-79	\N	f	105.36.1
256	\N	Ремень автоматный	\N	f	105.36.1
257	\N	Ремешок страховочный к ПМ	\N	f	105.36.1
258	\N	Сабля "Гвардейская" с символикой МЧС России	\N	f	105.36.1
259	\N	Спусковой крючок ИЖ-79	\N	f	105.36.1
260	\N	Тренчик для пистолета витой	\N	f	105.36.1
261	\N	Учебная граната УРГ	\N	f	105.36.1
262	\N	Фонарь Космос 8126	\N	f	105.36.1
263	\N	Футляр для 9 мм пистолета Glock (Глок) 17	\N	f	105.36.1
264	\N	Футляр для 9 мм пистолета Glock (Глок) 26	\N	f	105.36.1
265	\N	Футляр для кортика ВМК	\N	f	105.36.1
266	\N	Футляр для пистолета	\N	f	105.36.1
267	\N	Футляр к пистолету Glock-26	\N	f	105.36.1
268	\N	Футляр к пистолету SIG SAUER мод. 1911 STX кал. 45 ACP	\N	f	105.36.1
269	\N	Футляр к пистолету Беретта-92 фс	\N	f	105.36.1
270	\N	Ценные подарки	\N	f	105.36.1
271	\N	Чехол под 1 обойму закрытый	\N	f	105.36.1
272	\N	Шашка "Ермак" драгунская рядовая,казачья офицерская	\N	f	105.36.1
273	\N	Шашка Казачья с символикой МЧС России	\N	f	105.36.1
274	\N	Шомпол (протирка) пистолетный к ПМ	\N	f	105.36.1
275	\N	Ящик металлический	\N	f	105.36.1
276	\N	Огнетушитель ОП- 8(з)АВС	\N	t	21.34.1
277	\N	Огнетушитель углекислотный ОУ-5	\N	t	21.34.1
278	\N	Противогаз фильтрующий общевойсковой ПМК-3	\N	t	21.34.1
279	\N	Фонарь аккум.	\N	t	21.34.1
280	\N	Сейф АКС	\N	t	21.36.1
281	\N	Система.Стол Ольха	\N	t	21.36.1
282	\N	Стол рабочий ЕЕ31	\N	t	21.36.1
283	\N	Шкаф ШАМ-11-400	\N	t	21.36.1
284	\N	7,62 пистолет НАГАН	\N	t	21.38.1
285	\N	7,62 пистолет ТТ	\N	t	21.38.1
286	\N	9 мм пистолет АПС	\N	t	21.38.1
287	\N	9 мм пистолет ПМ (в наградном исполнении)	\N	t	21.38.1
288	\N	9 мм пистолет Ярыгина	\N	t	21.38.1
289	\N	Дрель электрическая "МЭС-420"	\N	t	21.38.1
290	\N	Жалюзи горизонтальные металлические	\N	t	21.38.1
291	\N	Лазерный целеуказатель к ПМ	\N	t	21.38.1
292	\N	Пистолет ПСМ 5,45 мм	\N	t	21.38.1
293	\N	Сейф АЕ	\N	t	21.38.1
294	\N	Сейф АК-74	\N	t	21.38.1
295	\N	Сейф для ПМ	\N	t	21.38.1
296	\N	Сейф ПКМ	\N	t	21.38.1
297	\N	9 мм пистолет Ярыгина, индекс 6П35 (в художественном оформлении), хим. никель	\N	t	07.2.1
298	\N	9,0-мм пистолет Беретта-92 ФС (Beretta-92 FS) в наградном исполнении	\N	t	07.2.1
299	\N	9мм пистолет Glock (Глок) 17 в наградном исполнении	\N	t	07.2.1
300	\N	9мм спортивный пистолет Glock (Глок) 26	\N	t	07.2.1
301	\N	Кортик генеральский в наградном исполнении	\N	t	07.2.1
302	\N	Сабля драгунская в наградном исполнении в футляре	\N	t	07.2.1
303	\N	Футляр для наградного оружия	\N	t	07.2.1
304	\N	Футляр для пистолетов Глок-17	\N	t	07.2.1
305	\N	Футляр для пистолетов Глок-26	\N	t	07.2.1
306	\N	Футляр под пистолет "Макарова"	\N	t	07.2.1
307	\N	Футляр под пистолет	\N	t	07.2.1
\.


--
-- Data for Name: weapon_registry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weapon_registry (id, nomenclature_id, serial_number, year_of_manufacture, current_object_id, status, created_at, quantity, inventory_number, price, account_code, kbk) FROM stdin;
1	1	BSVA891	\N	1	1	2026-03-01 11:45:04.854484	1	1101341304594	130000.00	101.34.1	03090000000000000
2	2	BKAH376\\A1802E	\N	1	1	2026-03-01 11:45:04.854489	1	1101341304374	180000.00	101.34.1	03090000000000000
3	3	58B269882	\N	1	1	2026-03-01 11:45:04.854491	1	1101341304385	170000.00	101.34.1	03090000000000000
4	4	Б/Н-4	\N	2	1	2026-03-01 11:45:04.854492	1	\N	550.00	101.34.1	03090000000000000
5	5	Партия 1	\N	2	1	2026-03-01 11:45:04.854493	2	\N	99.00	101.34.1	03090000000000000
6	6	2418299870	\N	1	1	2026-03-01 11:45:04.854495	1	1101341305318	70000.00	101.34.1	03090000000000000
7	6	2418299872	\N	1	1	2026-03-01 11:45:04.854496	1	1101341305320	70000.00	101.34.1	03090000000000000
8	6	2418299873	\N	1	1	2026-03-01 11:45:04.854497	1	1101341305321	70000.00	101.34.1	03090000000000000
9	6	2418299874	\N	1	1	2026-03-01 11:45:04.854498	1	1101341305322	70000.00	101.34.1	03090000000000000
10	6	2418299875	\N	1	1	2026-03-01 11:45:04.8545	1	1101341305323	70000.00	101.34.1	03090000000000000
11	6	2418299876	\N	1	1	2026-03-01 11:45:04.854501	1	1101341305324	70000.00	101.34.1	03090000000000000
12	6	2418299877	\N	1	1	2026-03-01 11:45:04.854502	1	1101341305325	70000.00	101.34.1	03090000000000000
13	6	2418299878	\N	1	1	2026-03-01 11:45:04.854503	1	1101341305326	70000.00	101.34.1	03090000000000000
14	6	2418299879	\N	1	1	2026-03-01 11:45:04.854504	1	1101341305327	70000.00	101.34.1	03090000000000000
15	6	2418299980	\N	1	1	2026-03-01 11:45:04.854505	1	1101341305328	70000.00	101.34.1	03090000000000000
16	6	2418299981	\N	1	1	2026-03-01 11:45:04.854507	1	1101341305329	70000.00	101.34.1	03090000000000000
17	6	2418299982	\N	1	1	2026-03-01 11:45:04.854508	1	1101341305330	70000.00	101.34.1	03090000000000000
18	6	2418299983	\N	1	1	2026-03-01 11:45:04.854509	1	1101341305331	70000.00	101.34.1	03090000000000000
19	6	2418299984	\N	1	1	2026-03-01 11:45:04.85451	1	1101341305332	70000.00	101.34.1	03090000000000000
20	6	2418299985	\N	1	1	2026-03-01 11:45:04.854511	1	1101341305333	70000.00	101.34.1	03090000000000000
21	6	2418299986	\N	1	1	2026-03-01 11:45:04.854512	1	1101341305334	70000.00	101.34.1	03090000000000000
22	6	2418299987	\N	1	1	2026-03-01 11:45:04.854513	1	1101341305335	70000.00	101.34.1	03090000000000000
23	6	2418299988	\N	1	1	2026-03-01 11:45:04.854515	1	1101341305336	70000.00	101.34.1	03090000000000000
24	6	2418299989	\N	1	1	2026-03-01 11:45:04.854516	1	1101341305337	70000.00	101.34.1	03090000000000000
25	6	2418299990	\N	1	1	2026-03-01 11:45:04.854517	1	1101341305338	70000.00	101.34.1	03090000000000000
26	6	2418299991	\N	1	1	2026-03-01 11:45:04.854518	1	1101341305339	70000.00	101.34.1	03090000000000000
27	6	2418299992	\N	1	1	2026-03-01 11:45:04.854519	1	1101341305340	70000.00	101.34.1	03090000000000000
28	6	2418299993	\N	1	1	2026-03-01 11:45:04.85452	1	1101341305341	70000.00	101.34.1	03090000000000000
29	6	2418299994	\N	1	1	2026-03-01 11:45:04.854522	1	1101341305342	70000.00	101.34.1	03090000000000000
30	6	2418299995	\N	1	1	2026-03-01 11:45:04.854523	1	1101341305343	70000.00	101.34.1	03090000000000000
31	6	2418299996	\N	1	1	2026-03-01 11:45:04.854524	1	1101341305344	70000.00	101.34.1	03090000000000000
32	6	2418299997	\N	1	1	2026-03-01 11:45:04.854525	1	1101341305345	70000.00	101.34.1	03090000000000000
33	6	2418299998	\N	1	1	2026-03-01 11:45:04.854526	1	1101341305346	70000.00	101.34.1	03090000000000000
34	6	2418299999	\N	1	1	2026-03-01 11:45:04.854527	1	1101341305347	70000.00	101.34.1	03090000000000000
35	6	2218202097	\N	1	1	2026-03-01 11:45:04.854528	1	1101341305285	75196.10	101.34.1	03090000000000000
36	6	2418299871	\N	1	1	2026-03-01 11:45:04.854529	1	1101341305319	70000.00	101.34.1	03090000000000000
37	6	2418299907	\N	1	1	2026-03-01 11:45:04.854531	1	1101341305211	70000.00	101.34.1	03090000000000000
38	6	2418299908	\N	1	1	2026-03-01 11:45:04.854532	1	1101341305212	70000.00	101.34.1	03090000000000000
39	6	2418299909	\N	1	1	2026-03-01 11:45:04.854533	1	1101341305213	70000.00	101.34.1	03090000000000000
40	6	2418299910	\N	1	1	2026-03-01 11:45:04.854534	1	1101341305214	70000.00	101.34.1	03090000000000000
41	6	2418299911	\N	1	1	2026-03-01 11:45:04.854535	1	1101341305215	70000.00	101.34.1	03090000000000000
42	6	2418299912	\N	1	1	2026-03-01 11:45:04.854536	1	1101341305216	70000.00	101.34.1	03090000000000000
43	6	2418299913	\N	2	1	2026-03-01 11:45:04.854537	1	1101341305217	70000.00	101.34.1	03090000000000000
44	6	2418299914	\N	1	1	2026-03-01 11:45:04.854539	1	1101341305218	70000.00	101.34.1	03090000000000000
45	6	2418299915	\N	1	1	2026-03-01 11:45:04.85454	1	1101341305219	70000.00	101.34.1	03090000000000000
46	6	2418299916	\N	1	1	2026-03-01 11:45:04.854541	1	1101341305220	70000.00	101.34.1	03090000000000000
47	6	2418299917	\N	1	1	2026-03-01 11:45:04.854542	1	1101341305221	70000.00	101.34.1	03090000000000000
48	6	2418299918	\N	1	1	2026-03-01 11:45:04.854543	1	1101341305222	70000.00	101.34.1	03090000000000000
49	6	2418299919	\N	1	1	2026-03-01 11:45:04.854544	1	1101341305223	70000.00	101.34.1	03090000000000000
50	6	2418299920	\N	1	1	2026-03-01 11:45:04.854546	1	1101341305224	70000.00	101.34.1	03090000000000000
51	6	2418299921	\N	1	1	2026-03-01 11:45:04.854547	1	1101341305225	70000.00	101.34.1	03090000000000000
52	6	2418299922	\N	1	1	2026-03-01 11:45:04.854548	1	1101341305226	70000.00	101.34.1	03090000000000000
53	6	2418299923	\N	1	1	2026-03-01 11:45:04.854549	1	1101341305227	70000.00	101.34.1	03090000000000000
54	6	2418299924	\N	1	1	2026-03-01 11:45:04.85455	1	1101341305228	70000.00	101.34.1	03090000000000000
55	6	2418299925	\N	1	1	2026-03-01 11:45:04.854551	1	1101341305229	70000.00	101.34.1	03090000000000000
56	6	2418299926	\N	1	1	2026-03-01 11:45:04.854552	1	1101341305230	70000.00	101.34.1	03090000000000000
57	6	2418299927	\N	1	1	2026-03-01 11:45:04.854554	1	1101341305231	70000.00	101.34.1	03090000000000000
58	6	2418299928	\N	1	1	2026-03-01 11:45:04.854555	1	1101341305232	70000.00	101.34.1	03090000000000000
59	6	2418299929	\N	2	1	2026-03-01 11:45:04.854556	1	1101341305233	70000.00	101.34.1	03090000000000000
60	6	2418299930	\N	2	1	2026-03-01 11:45:04.854557	1	1101341305234	70000.00	101.34.1	03090000000000000
61	6	2418299931	\N	2	1	2026-03-01 11:45:04.854558	1	1101341305235	70000.00	101.34.1	03090000000000000
62	6	2418299932	\N	1	1	2026-03-01 11:45:04.854559	1	1101341305236	70000.00	101.34.1	03090000000000000
63	6	2418299933	\N	1	1	2026-03-01 11:45:04.85456	1	1101341305237	70000.00	101.34.1	03090000000000000
64	6	2418299934	\N	1	1	2026-03-01 11:45:04.854562	1	1101341305238	70000.00	101.34.1	03090000000000000
65	6	2418299935	\N	1	1	2026-03-01 11:45:04.854563	1	1101341305239	70000.00	101.34.1	03090000000000000
66	6	2418299936	\N	1	1	2026-03-01 11:45:04.854564	1	1101341305240	70000.00	101.34.1	03090000000000000
67	6	2418299937	\N	1	1	2026-03-01 11:45:04.854565	1	1101341305241	70000.00	101.34.1	03090000000000000
68	6	2418299938	\N	1	1	2026-03-01 11:45:04.854566	1	1101341305242	70000.00	101.34.1	03090000000000000
69	6	2418299939	\N	1	1	2026-03-01 11:45:04.854567	1	1101341305243	70000.00	101.34.1	03090000000000000
70	6	2418299940	\N	1	1	2026-03-01 11:45:04.854568	1	1101341305244	70000.00	101.34.1	03090000000000000
71	6	2418299941	\N	1	1	2026-03-01 11:45:04.854569	1	1101341305245	70000.00	101.34.1	03090000000000000
72	6	2418299942	\N	1	1	2026-03-01 11:45:04.854571	1	1101341305246	70000.00	101.34.1	03090000000000000
73	6	2418299943	\N	1	1	2026-03-01 11:45:04.854572	1	1101341305247	70000.00	101.34.1	03090000000000000
74	6	2418299944	\N	2	1	2026-03-01 11:45:04.854573	1	1101341305248	70000.00	101.34.1	03090000000000000
75	6	2418299945	\N	1	1	2026-03-01 11:45:04.854574	1	1101341305249	70000.00	101.34.1	03090000000000000
76	6	2418299946	\N	1	1	2026-03-01 11:45:04.854575	1	1101341305250	70000.00	101.34.1	03090000000000000
77	6	2418299947	\N	1	1	2026-03-01 11:45:04.854576	1	1101341305251	70000.00	101.34.1	03090000000000000
78	6	2418299948	\N	1	1	2026-03-01 11:45:04.854577	1	1101341305252	70000.00	101.34.1	03090000000000000
79	6	2418299949	\N	1	1	2026-03-01 11:45:04.854579	1	1101341305253	70000.00	101.34.1	03090000000000000
80	6	2418299950	\N	2	1	2026-03-01 11:45:04.85458	1	1101341305254	70000.00	101.34.1	03090000000000000
81	6	2418299951	\N	1	1	2026-03-01 11:45:04.854581	1	1101341305255	70000.00	101.34.1	03090000000000000
82	6	2418299952	\N	1	1	2026-03-01 11:45:04.854582	1	1101341305256	70000.00	101.34.1	03090000000000000
83	6	2418299953	\N	2	1	2026-03-01 11:45:04.854583	1	1101341305257	70000.00	101.34.1	03090000000000000
84	6	2418299954	\N	2	1	2026-03-01 11:45:04.854584	1	1101341305258	70000.00	101.34.1	03090000000000000
85	6	2418299955	\N	1	1	2026-03-01 11:45:04.854586	1	1101341305259	70000.00	101.34.1	03090000000000000
86	6	2418299956	\N	1	1	2026-03-01 11:45:04.854587	1	1101341305260	70000.00	101.34.1	03090000000000000
87	6	2418299957	\N	1	1	2026-03-01 11:45:04.854588	1	1101341305261	70000.00	101.34.1	03090000000000000
88	6	2418299958	\N	1	1	2026-03-01 11:45:04.854589	1	1101341305262	70000.00	101.34.1	03090000000000000
89	6	2418299959	\N	1	1	2026-03-01 11:45:04.85459	1	1101341305263	70000.00	101.34.1	03090000000000000
90	6	2418299960	\N	1	1	2026-03-01 11:45:04.854591	1	1101341305264	70000.00	101.34.1	03090000000000000
91	6	2418299961	\N	1	1	2026-03-01 11:45:04.854593	1	1101341305265	70000.00	101.34.1	03090000000000000
92	6	2418299962	\N	2	1	2026-03-01 11:45:04.854594	1	1101341305266	70000.00	101.34.1	03090000000000000
93	6	2418299963	\N	1	1	2026-03-01 11:45:04.854595	1	1101341305267	70000.00	101.34.1	03090000000000000
94	6	2418299964	\N	2	1	2026-03-01 11:45:04.854596	1	1101341305268	70000.00	101.34.1	03090000000000000
95	6	2418299965	\N	1	1	2026-03-01 11:45:04.854597	1	1101341305269	70000.00	101.34.1	03090000000000000
96	6	2418299966	\N	1	1	2026-03-01 11:45:04.854598	1	1101341305270	70000.00	101.34.1	03090000000000000
97	6	2418299967	\N	1	1	2026-03-01 11:45:04.854599	1	1101341305271	70000.00	101.34.1	03090000000000000
98	6	2418299968	\N	1	1	2026-03-01 11:45:04.8546	1	1101341305272	70000.00	101.34.1	03090000000000000
99	6	2418299969	\N	1	1	2026-03-01 11:45:04.854602	1	1101341305273	70000.00	101.34.1	03090000000000000
100	6	2418299970	\N	1	1	2026-03-01 11:45:04.854603	1	1101341305274	70000.00	101.34.1	03090000000000000
101	6	2418299971	\N	1	1	2026-03-01 11:45:04.854604	1	1101341305275	70000.00	101.34.1	03090000000000000
102	6	2418299972	\N	1	1	2026-03-01 11:45:04.854605	1	1101341305276	70000.00	101.34.1	03090000000000000
103	6	2418299973	\N	1	1	2026-03-01 11:45:04.854606	1	1101341305277	70000.00	101.34.1	03090000000000000
104	6	2418299974	\N	1	1	2026-03-01 11:45:04.854607	1	1101341305278	70000.00	101.34.1	03090000000000000
105	6	2418299975	\N	1	1	2026-03-01 11:45:04.854608	1	1101341305279	70000.00	101.34.1	03090000000000000
106	7	Б/Н-106	\N	1	1	2026-03-01 11:45:04.85461	1	\N	1500.00	101.34.1	03090000000000000
107	8	Инв.1101341305498	\N	1	1	2026-03-01 11:45:04.854611	1	1101341305498	195000.00	101.34.1	03090000000000000
108	9	Инв.1101341305499	\N	1	1	2026-03-01 11:45:04.854612	1	1101341305499	195000.00	101.34.1	03090000000000000
109	10	Инв.1101341305624	\N	1	1	2026-03-01 11:45:04.854613	1	1101341305624	170000.00	101.34.1	03090000000000000
110	11	Инв.1101341305623	\N	1	1	2026-03-01 11:45:04.854614	1	1101341305623	170000.00	101.34.1	03090000000000000
111	12	Инв.1101341305631	\N	1	1	2026-03-01 11:45:04.854615	1	1101341305631	170000.00	101.34.1	03090000000000000
112	13	Инв.1101341305630	\N	1	1	2026-03-01 11:45:04.854616	1	1101341305630	170000.00	101.34.1	03090000000000000
113	14	Инв.1101341305626	\N	1	1	2026-03-01 11:45:04.854617	1	1101341305626	170000.00	101.34.1	03090000000000000
114	15	Инв.1101341305627	\N	1	1	2026-03-01 11:45:04.854619	1	1101341305627	170000.00	101.34.1	03090000000000000
115	16	Инв.1101341305628	\N	1	1	2026-03-01 11:45:04.85462	1	1101341305628	170000.00	101.34.1	03090000000000000
116	17	Инв.1101341305629	\N	1	1	2026-03-01 11:45:04.854621	1	1101341305629	170000.00	101.34.1	03090000000000000
117	18	Инв.1101341305625	\N	1	1	2026-03-01 11:45:04.854622	1	1101341305625	170000.00	101.34.1	03090000000000000
118	19	Инв.1101341305622	\N	1	1	2026-03-01 11:45:04.854623	1	1101341305622	170000.00	101.34.1	03090000000000000
119	20	Инв.1101341305351	\N	1	1	2026-03-01 11:45:04.854624	1	1101341305351	57800.00	101.34.1	03090000000000000
120	21	BZZP384	\N	1	1	2026-03-01 11:45:04.854625	1	1101341305287	72000.00	101.34.1	03090000000000000
121	21	BZZY458	\N	1	1	2026-03-01 11:45:04.854626	1	1101341305350	57800.00	101.34.1	03090000000000000
122	21	BZZY460	\N	1	1	2026-03-01 11:45:04.854628	1	1101341305352	57800.00	101.34.1	03090000000000000
123	21	BZZY461	\N	1	1	2026-03-01 11:45:04.854629	1	1101341305353	57800.00	101.34.1	03090000000000000
124	21	BZZY462	\N	1	1	2026-03-01 11:45:04.85463	1	1101341305354	57800.00	101.34.1	03090000000000000
125	21	BZZY483	\N	1	1	2026-03-01 11:45:04.854631	1	1101341305355	57800.00	101.34.1	03090000000000000
126	21	BZZY484	\N	1	1	2026-03-01 11:45:04.854632	1	1101341305356	57800.00	101.34.1	03090000000000000
127	21	BZZY485	\N	1	1	2026-03-01 11:45:04.854633	1	1101341305357	57800.00	101.34.1	03090000000000000
128	21	BZZY486	\N	1	1	2026-03-01 11:45:04.854634	1	1101341305358	57800.00	101.34.1	03090000000000000
129	22	CDBW428	\N	1	1	2026-03-01 11:45:04.854636	1	1101341305416	110000.00	101.34.1	03090000000000000
130	22	CDBW429	\N	1	1	2026-03-01 11:45:04.854637	1	1101341305417	110000.00	101.34.1	03090000000000000
131	22	CDBW430	\N	1	1	2026-03-01 11:45:04.854638	1	1101341305418	110000.00	101.34.1	03090000000000000
132	22	CDBW431	\N	1	1	2026-03-01 11:45:04.854639	1	1101341305419	110000.00	101.34.1	03090000000000000
133	22	CDBW432	\N	1	1	2026-03-01 11:45:04.85464	1	1101341305420	110000.00	101.34.1	03090000000000000
134	22	CDBW433	\N	1	1	2026-03-01 11:45:04.854642	1	1101341305421	110000.00	101.34.1	03090000000000000
135	22	CDBW435	\N	1	1	2026-03-01 11:45:04.854643	1	1101341305422	110000.00	101.34.1	03090000000000000
136	23	CDND605	\N	1	1	2026-03-01 11:45:04.854644	1	1101341305387	110000.00	101.34.1	03090000000000000
137	23	CDND607	\N	1	1	2026-03-01 11:45:04.854645	1	1101341305388	110000.00	101.34.1	03090000000000000
138	23	CDND608	\N	1	1	2026-03-01 11:45:04.854646	1	1101341305389	110000.00	101.34.1	03090000000000000
139	23	CDND610	\N	1	1	2026-03-01 11:45:04.854647	1	1101341305390	110000.00	101.34.1	03090000000000000
140	23	CDND611	\N	1	1	2026-03-01 11:45:04.854648	1	1101341305391	110000.00	101.34.1	03090000000000000
141	23	CDND612	\N	1	1	2026-03-01 11:45:04.85465	1	1101341305392	110000.00	101.34.1	03090000000000000
142	23	CDND613	\N	1	1	2026-03-01 11:45:04.854651	1	1101341305393	110000.00	101.34.1	03090000000000000
143	23	CDND615	\N	1	1	2026-03-01 11:45:04.854652	1	1101341305394	110000.00	101.34.1	03090000000000000
144	23	CDND616	\N	1	1	2026-03-01 11:45:04.854653	1	1101341305395	110000.00	101.34.1	03090000000000000
145	23	CDND617	\N	1	1	2026-03-01 11:45:04.854654	1	1101341305396	110000.00	101.34.1	03090000000000000
146	23	CDND618	\N	1	1	2026-03-01 11:45:04.854655	1	1101341305397	110000.00	101.34.1	03090000000000000
147	23	CDND619	\N	1	1	2026-03-01 11:45:04.854657	1	1101341305398	110000.00	101.34.1	03090000000000000
148	23	CDND620	\N	1	1	2026-03-01 11:45:04.854658	1	1101341305399	110000.00	101.34.1	03090000000000000
149	23	CDND621	\N	1	1	2026-03-01 11:45:04.854659	1	1101341305400	110000.00	101.34.1	03090000000000000
150	23	CDND622	\N	1	1	2026-03-01 11:45:04.85466	1	1101341305401	110000.00	101.34.1	03090000000000000
151	23	CDND623	\N	1	1	2026-03-01 11:45:04.854661	1	1101341305402	110000.00	101.34.1	03090000000000000
152	23	CDND624	\N	1	1	2026-03-01 11:45:04.854662	1	1101341305403	110000.00	101.34.1	03090000000000000
153	23	CDND625	\N	1	1	2026-03-01 11:45:04.854663	1	1101341305404	110000.00	101.34.1	03090000000000000
154	23	CDND627	\N	1	1	2026-03-01 11:45:04.854664	1	1101341305405	110000.00	101.34.1	03090000000000000
155	23	CDND628	\N	1	1	2026-03-01 11:45:04.854666	1	1101341305406	110000.00	101.34.1	03090000000000000
156	23	CDND629	\N	1	1	2026-03-01 11:45:04.854667	1	1101341305407	110000.00	101.34.1	03090000000000000
157	23	CDND632	\N	1	1	2026-03-01 11:45:04.854668	1	1101341305408	110000.00	101.34.1	03090000000000000
158	23	CDND633	\N	1	1	2026-03-01 11:45:04.854669	1	1101341305409	110000.00	101.34.1	03090000000000000
159	23	CDND634	\N	1	1	2026-03-01 11:45:04.85467	1	1101341305410	110000.00	101.34.1	03090000000000000
160	23	CDND636	\N	1	1	2026-03-01 11:45:04.854671	1	1101341305411	110000.00	101.34.1	03090000000000000
161	23	CDND637	\N	1	1	2026-03-01 11:45:04.854673	1	1101341305412	110000.00	101.34.1	03090000000000000
162	23	CDND638	\N	1	1	2026-03-01 11:45:04.854674	1	1101341305413	110000.00	101.34.1	03090000000000000
163	23	CEHF556	\N	1	1	2026-03-01 11:45:04.854675	1	1101341305362	92595.05	101.34.1	03090000000000000
164	23	CEHF557	\N	1	1	2026-03-01 11:45:04.854676	1	1101341305363	92595.05	101.34.1	03090000000000000
165	23	CEHF558	\N	1	1	2026-03-01 11:45:04.854677	1	1101341305364	92595.05	101.34.1	03090000000000000
166	23	CEHF559	\N	1	1	2026-03-01 11:45:04.854678	1	1101341305365	92595.05	101.34.1	03090000000000000
167	23	CEHF560	\N	1	1	2026-03-01 11:45:04.854679	1	1101341305366	92595.05	101.34.1	03090000000000000
168	23	CEHF561	\N	1	1	2026-03-01 11:45:04.854681	1	1101341305367	92595.05	101.34.1	03090000000000000
169	23	CEHF562	\N	1	1	2026-03-01 11:45:04.854682	1	1101341305368	92595.05	101.34.1	03090000000000000
170	24	CDSY735	\N	1	1	2026-03-01 11:45:04.854683	1	1101341305369	86847.53	101.34.1	03090000000000000
171	24	CDSY736	\N	1	1	2026-03-01 11:45:04.854684	1	1101341305370	86847.53	101.34.1	03090000000000000
172	24	CDSY737	\N	1	1	2026-03-01 11:45:04.854686	1	1101341305371	86847.53	101.34.1	03090000000000000
173	24	CDSY738	\N	1	1	2026-03-01 11:45:04.854687	1	1101341305372	86847.53	101.34.1	03090000000000000
174	24	CDSY739	\N	1	1	2026-03-01 11:45:04.854688	1	1101341305373	86847.53	101.34.1	03090000000000000
175	24	CDSY740	\N	1	1	2026-03-01 11:45:04.854689	1	1101341305374	86847.53	101.34.1	03090000000000000
176	25	CCFZ413	\N	1	1	2026-03-01 11:45:04.85469	1	1101341305427	110000.00	101.34.1	03090000000000000
177	25	CCFZ415	\N	1	1	2026-03-01 11:45:04.854692	1	1101341305428	110000.00	101.34.1	03090000000000000
178	25	CCFZ417	\N	1	1	2026-03-01 11:45:04.854693	1	1101341305430	110000.00	101.34.1	03090000000000000
179	25	CCFZ418	\N	1	1	2026-03-01 11:45:04.854694	1	1101341305431	110000.00	101.34.1	03090000000000000
180	25	CCFZ419	\N	1	1	2026-03-01 11:45:04.854695	1	1101341305432	110000.00	101.34.1	03090000000000000
181	25	CCFZ420	\N	1	1	2026-03-01 11:45:04.854696	1	1101341305433	110000.00	101.34.1	03090000000000000
182	25	CCFZ423	\N	1	1	2026-03-01 11:45:04.854697	1	1101341305434	110000.00	101.34.1	03090000000000000
183	25	CCFZ427	\N	1	1	2026-03-01 11:45:04.854698	1	1101341305435	110000.00	101.34.1	03090000000000000
184	26	CBMM937	\N	1	1	2026-03-01 11:45:04.8547	1	1101341305375	70596.38	101.34.1	03090000000000000
185	26	CBMM938	\N	1	1	2026-03-01 11:45:04.854701	1	1101341305376	70596.38	101.34.1	03090000000000000
186	26	CBMM939	\N	1	1	2026-03-01 11:45:04.854702	1	1101341305377	70596.38	101.34.1	03090000000000000
187	26	CDNE160	\N	1	1	2026-03-01 11:45:04.854703	1	1101341305380	70596.38	101.34.1	03090000000000000
188	26	CDNE161	\N	1	1	2026-03-01 11:45:04.854704	1	1101341305381	70596.38	101.34.1	03090000000000000
1600	116	АБ 5353	\N	2	1	2026-03-01 11:45:05.643995	1	\N	3770.00	21.38.1	\N
189	26	CDNE163	\N	1	1	2026-03-01 11:45:04.854705	1	1101341305383	142891.05	101.34.1	03090000000000000
190	26	CDNE164	\N	1	1	2026-03-01 11:45:04.854706	1	1101341305384	142891.05	101.34.1	03090000000000000
191	27	КМ 0057	\N	1	1	2026-03-01 11:45:04.854708	1	1101341300977	22000.00	101.34.1	03090000000000000
192	28	Б/Н-192	\N	2	1	2026-03-01 11:45:04.854709	1	\N	395.00	101.34.1	03090000000000000
193	29	Б/Н-193	\N	2	1	2026-03-01 11:45:04.85471	1	\N	179.00	101.34.1	03090000000000000
194	30	Инв.1101040700338	\N	2	1	2026-03-01 11:45:04.854711	1	1101040700338	200.00	101.34.1	03090000000000000
195	31	в комплекте	\N	2	1	2026-03-01 11:45:04.854712	1	1101341303464	97500.00	101.34.1	03090000000000000
196	32	Б/Н-196	\N	2	1	2026-03-01 11:45:04.854713	1	\N	5130.00	101.34.1	03090000000000000
197	33	Б/Н-197	\N	2	1	2026-03-01 11:45:04.854714	1	\N	350.00	101.34.1	03090000000000000
198	34	Б/Н-198	\N	2	1	2026-03-01 11:45:04.854716	1	\N	75.00	101.34.1	03090000000000000
199	35	Б/Н-199	\N	2	1	2026-03-01 11:45:04.854717	1	\N	75.00	101.34.1	03090000000000000
200	36	Инв.1101341305689	\N	2	1	2026-03-01 11:45:04.854718	1	1101341305689	791160.00	101.34.1	03090000000000000
201	36	Инв.1101341305688	\N	2	1	2026-03-01 11:45:04.854719	1	1101341305688	791160.00	101.34.1	03090000000000000
202	36	Инв.1101341305687	\N	2	1	2026-03-01 11:45:04.85472	1	1101341305687	791160.00	101.34.1	03090000000000000
203	36	Инв.1101341305686	\N	2	1	2026-03-01 11:45:04.854721	1	1101341305686	791160.00	101.34.1	03090000000000000
204	37	Инв.1101040700337	\N	2	1	2026-03-01 11:45:04.854722	1	1101040700337	200.00	101.34.1	03090000000000000
205	38	BUXE398	\N	1	1	2026-03-01 11:45:04.854724	1	1101341304561	273996.00	101.34.1	03090000000000000
206	39	AOA61435	\N	1	1	2026-03-01 11:45:04.854725	1	1101341304829	10000.00	101.34.1	03090000000000000
207	40	BKGZ827	\N	1	1	2026-03-01 11:45:04.854726	1	1101341304824	20000.00	101.34.1	03090000000000000
208	41	BYZR605	\N	1	1	2026-03-01 11:45:04.854727	1	1101341304905	20000.00	101.34.1	03090000000000000
209	42	Инв.1101341305505	\N	1	1	2026-03-01 11:45:04.854728	1	1101341305505	20000.00	101.34.1	03090000000000000
210	42	Инв.1101341305509	\N	1	1	2026-03-01 11:45:04.854729	1	1101341305509	20000.00	101.34.1	03090000000000000
211	42	Инв.1101341305506	\N	1	1	2026-03-01 11:45:04.85473	1	1101341305506	20000.00	101.34.1	03090000000000000
212	42	Инв.1101341305507	\N	1	1	2026-03-01 11:45:04.854731	1	1101341305507	20000.00	101.34.1	03090000000000000
213	42	Инв.1101341305508	\N	1	1	2026-03-01 11:45:04.854733	1	1101341305508	20000.00	101.34.1	03090000000000000
214	43	BVRW255	\N	1	1	2026-03-01 11:45:04.854734	1	1101341305182	20000.00	101.34.1	03090000000000000
215	44	Инв.1101341305503	\N	1	1	2026-03-01 11:45:04.854735	1	1101341305503	20000.00	101.34.1	03090000000000000
216	45	Инв.1101341305504	\N	1	1	2026-03-01 11:45:04.854736	1	1101341305504	20000.00	101.34.1	03090000000000000
217	46	Инв.1101341305740	\N	1	1	2026-03-01 11:45:04.854737	1	1101341305740	15000.00	101.34.1	03090000000000000
218	47	CCSN546	\N	1	1	2026-03-01 11:45:04.854738	1	1101341305203	20000.00	101.34.1	03090000000000000
219	47	CCSN547	\N	1	1	2026-03-01 11:45:04.854739	1	1101341305204	20000.00	101.34.1	03090000000000000
220	47	CCSN550	\N	1	1	2026-03-01 11:45:04.85474	1	1101341305205	20000.00	101.34.1	03090000000000000
221	48	Инв.1101341305696	\N	1	1	2026-03-01 11:45:04.854742	1	1101341305696	15000.00	101.34.1	03090000000000000
222	49	Инв.1101341305697	\N	1	1	2026-03-01 11:45:04.854743	1	1101341305697	15000.00	101.34.1	03090000000000000
223	50	Инв.1101341305698	\N	1	1	2026-03-01 11:45:04.854744	1	1101341305698	15000.00	101.34.1	03090000000000000
224	51	Инв.1101341305699	\N	1	1	2026-03-01 11:45:04.854745	1	1101341305699	15000.00	101.34.1	03090000000000000
225	52	Инв.1101341305700	\N	1	1	2026-03-01 11:45:04.854747	1	1101341305700	15000.00	101.34.1	03090000000000000
226	53	Инв.1101341305701	\N	1	1	2026-03-01 11:45:04.854748	1	1101341305701	15000.00	101.34.1	03090000000000000
227	54	Инв.1101341305702	\N	1	1	2026-03-01 11:45:04.85475	1	1101341305702	15000.00	101.34.1	03090000000000000
228	55	Инв.1101341305703	\N	1	1	2026-03-01 11:45:04.854751	1	1101341305703	15000.00	101.34.1	03090000000000000
229	56	Инв.1101341305704	\N	1	1	2026-03-01 11:45:04.854752	1	1101341305704	15000.00	101.34.1	03090000000000000
230	57	Инв.1101341305705	\N	1	1	2026-03-01 11:45:04.854753	1	1101341305705	15000.00	101.34.1	03090000000000000
231	58	Инв.1101341305706	\N	1	1	2026-03-01 11:45:04.854754	1	1101341305706	15000.00	101.34.1	03090000000000000
232	59	Инв.1101341305707	\N	1	1	2026-03-01 11:45:04.854755	1	1101341305707	15000.00	101.34.1	03090000000000000
233	60	Инв.1101341305708	\N	1	1	2026-03-01 11:45:04.854757	1	1101341305708	15000.00	101.34.1	03090000000000000
234	61	Инв.1101341305709	\N	1	1	2026-03-01 11:45:04.854758	1	1101341305709	15000.00	101.34.1	03090000000000000
235	62	Инв.1101341305710	\N	1	1	2026-03-01 11:45:04.854759	1	1101341305710	15000.00	101.34.1	03090000000000000
236	63	Инв.1101341305711	\N	1	1	2026-03-01 11:45:04.85476	1	1101341305711	15000.00	101.34.1	03090000000000000
237	64	Инв.1101341305712	\N	1	1	2026-03-01 11:45:04.854761	1	1101341305712	15000.00	101.34.1	03090000000000000
238	65	Инв.1101341305713	\N	1	1	2026-03-01 11:45:04.854762	1	1101341305713	15000.00	101.34.1	03090000000000000
239	66	Инв.1101341305714	\N	1	1	2026-03-01 11:45:04.854764	1	1101341305714	15000.00	101.34.1	03090000000000000
240	67	Инв.1101341305715	\N	1	1	2026-03-01 11:45:04.854765	1	1101341305715	15000.00	101.34.1	03090000000000000
241	68	BBHA264	\N	1	1	2026-03-01 11:45:04.854766	1	1101341304563	321024.00	101.34.1	03090000000000000
242	69	Б/Н-242	\N	2	1	2026-03-01 11:45:04.854767	1	\N	199.00	101.34.1	03090000000000000
243	70	Инв.1101041000024	\N	2	1	2026-03-01 11:45:04.854768	1	1101041000024	71067.70	101.34.1	03090000000000000
244	71	005759	\N	2	1	2026-03-01 11:45:04.854769	1	1101341304923	26155.50	101.34.1	03090000000000000
245	72	004627	\N	2	1	2026-03-01 11:45:04.85477	1	1101341304967	26239.06	101.34.1	03100000000000000
246	72	004631	\N	2	1	2026-03-01 11:45:04.854772	1	1101341304972	26239.06	101.34.1	03100000000000000
247	72	004635	\N	2	1	2026-03-01 11:45:04.854773	1	1101341304970	26239.06	101.34.1	03100000000000000
248	72	004636	\N	2	1	2026-03-01 11:45:04.854775	1	1101341304965	26239.06	101.34.1	03100000000000000
249	72	004639	\N	2	1	2026-03-01 11:45:04.854776	1	1101341304968	26239.06	101.34.1	03100000000000000
250	72	004641	\N	2	1	2026-03-01 11:45:04.854777	1	1101341304971	26239.06	101.34.1	03100000000000000
251	72	004643	\N	2	1	2026-03-01 11:45:04.854778	1	1101341304966	26239.06	101.34.1	03100000000000000
252	72	004647	\N	2	1	2026-03-01 11:45:04.85478	1	1101341304969	26239.06	101.34.1	03100000000000000
253	72	004661	\N	2	1	2026-03-01 11:45:04.854781	1	1101341304964	26239.06	101.34.1	03100000000000000
254	73	Б/Н-254	\N	2	1	2026-03-01 11:45:04.854782	1	\N	49.00	101.34.1	03090000000000000
255	74	Б/Н-255	\N	2	1	2026-03-01 11:45:04.854783	1	\N	179.00	101.34.1	03090000000000000
256	75	Б/Н-256	\N	2	1	2026-03-01 11:45:04.854784	1	\N	699.00	101.34.1	03090000000000000
257	76	Инв.1101040000069	\N	1	1	2026-03-01 11:45:04.854785	1	1101040000069	6000.00	101.34.1	03090000000000000
258	76	Инв.1101040000104	\N	1	1	2026-03-01 11:45:04.854786	1	1101040000104	6000.00	101.34.1	03090000000000000
259	76	Инв.1101040000103	\N	1	1	2026-03-01 11:45:04.854788	1	1101040000103	6000.00	101.34.1	03090000000000000
260	76	Инв.1101040000107	\N	1	1	2026-03-01 11:45:04.854789	1	1101040000107	6000.00	101.34.1	03090000000000000
261	76	Инв.1101040000061	\N	1	1	2026-03-01 11:45:04.85479	1	1101040000061	6000.00	101.34.1	03090000000000000
262	76	Инв.1101040000105	\N	1	1	2026-03-01 11:45:04.854791	1	1101040000105	6000.00	101.34.1	03090000000000000
263	77	Инв.1101061000054	\N	2	1	2026-03-01 11:45:04.854792	1	1101061000054	26350.00	101.36.1	03090000000000000
264	77	Инв.1101061000048	\N	2	1	2026-03-01 11:45:04.854793	1	1101061000048	26350.00	101.36.1	03090000000000000
265	78	Инв.1101361000145	\N	2	1	2026-03-01 11:45:04.854809	1	1101361000145	30845.20	101.36.1	03090000000000000
266	79	Инв.1101361004394	\N	2	1	2026-03-01 11:45:04.854812	1	1101361004394	59435.32	101.36.1	03090000000000000
267	80	Инв.1101361001453	\N	2	1	2026-03-01 11:45:04.854813	1	1101361001453	6700.00	101.36.1	03090000000000000
268	81	Инв.1101361000847	\N	2	1	2026-03-01 11:45:04.854814	1	1101361000847	43000.00	101.36.1	03090000000000000
269	82	ШО-ПБ1	\N	2	1	2026-03-01 11:45:04.854815	2	1101361001476	33262.87	101.36.1	03090000000000000
270	83	Инв.1101361004377	\N	2	1	2026-03-01 11:45:04.854817	1	1101361004377	45279.84	101.36.1	03090000000000000
271	83	Инв.1101361004373	\N	2	1	2026-03-01 11:45:04.854818	1	1101361004373	45286.76	101.36.1	03090000000000000
272	84	Инв.1101091200017	\N	2	1	2026-03-01 11:45:04.854819	1	1101091200017	5556.00	101.36.1	03090000000000000
273	85	Инв.1101091200020	\N	2	1	2026-03-01 11:45:04.85482	1	1101091200020	6628.00	101.36.1	03090000000000000
274	85	Инв.1101091200019	\N	2	1	2026-03-01 11:45:04.854821	1	1101091200019	6628.00	101.36.1	03090000000000000
275	86	Инв.1101361001281	\N	2	1	2026-03-01 11:45:04.854822	1	1101361001281	4366.00	101.36.1	03090000000000000
276	87	Инв.1101361000242	\N	1	1	2026-03-01 11:45:04.854824	1	1101361000242	5400.00	101.36.1	03090000000000000
277	87	Инв.1101361000243	\N	1	1	2026-03-01 11:45:04.854825	1	1101361000243	5400.00	101.36.1	03090000000000000
278	88	пистолет	\N	1	1	2026-03-01 11:45:04.854826	21	1101361001011	3200.00	101.36.1	03090000000000000
279	88	пистолет	\N	2	1	2026-03-01 11:45:04.854827	1	1101361001078	3200.00	101.36.1	03090000000000000
280	89	Инв.1101061000089	\N	1	1	2026-03-01 11:45:04.854828	1	1101061000089	3450.00	101.36.1	03090000000000000
281	90	Инв.1101360000007	\N	2	1	2026-03-01 11:45:04.85483	1	1101360000007	5939.00	101.36.1	03090000000000000
282	91	Б/Н-303	\N	2	1	2026-03-01 11:45:04.854831	1	\N	1900.00	101.36.1	03090000000000000
283	92	Инв.1101360000006	\N	2	1	2026-03-01 11:45:04.854832	1	1101360000006	13020.00	101.36.1	03090000000000000
284	93	Инв.1101061000027	\N	2	1	2026-03-01 11:45:04.854833	1	1101061000027	3154.56	101.36.1	03090000000000000
285	94	высотой 2000 мм	\N	2	1	2026-03-01 11:45:04.854834	1	1101361000984	28000.00	101.36.1	03090000000000000
286	95	Инв.1101060704245	\N	2	1	2026-03-01 11:45:04.854835	1	1101060704245	4030.00	101.36.1	03090000000000000
287	96	Инв.1101061000026	\N	2	1	2026-03-01 11:45:04.854837	1	1101061000026	3850.00	101.36.1	03090000000000000
288	97	АВ419	\N	2	1	2026-03-01 11:45:04.854838	1	1101091000352	737.00	101.38.1	03090000000000000
289	97	АВ461.	\N	2	1	2026-03-01 11:45:04.854839	1	1101091000353	737.00	101.38.1	03090000000000000
290	97	АВ479	\N	2	1	2026-03-01 11:45:04.85484	1	1101091000354	737.00	101.38.1	03090000000000000
291	98	241233047	\N	2	1	2026-03-01 11:45:04.854841	1	1101381003355	99987.00	101.38.1	03090000000000000
292	98	241233880	\N	2	1	2026-03-01 11:45:04.854842	1	1101381003354	99987.00	101.38.1	03090000000000000
293	98	241234212	\N	2	1	2026-03-01 11:45:04.854843	1	1101381003359	99987.00	101.38.1	03090000000000000
294	98	241234399	\N	2	1	2026-03-01 11:45:04.854845	1	1101381003335	99987.00	101.38.1	03090000000000000
295	98	241234472	\N	2	1	2026-03-01 11:45:04.854846	1	1101381003361	99987.00	101.38.1	03090000000000000
296	98	241234566	\N	2	1	2026-03-01 11:45:04.854847	1	1101381003334	99987.00	101.38.1	03090000000000000
297	99	8390129	\N	2	1	2026-03-01 11:45:04.854848	1	1101091000408	16652.00	101.38.1	03090000000000000
298	99	8398699	\N	2	1	2026-03-01 11:45:04.854849	1	1101091000449	16652.00	101.38.1	03090000000000000
299	99	8399826	\N	2	1	2026-03-01 11:45:04.85485	1	1101091000398	16652.00	101.38.1	03090000000000000
300	99	8402454	\N	2	1	2026-03-01 11:45:04.854851	1	1101091000376	16652.00	101.38.1	03090000000000000
301	99	8404244	\N	2	1	2026-03-01 11:45:04.854853	1	1101091000383	16652.00	101.38.1	03090000000000000
302	99	8408644	\N	2	1	2026-03-01 11:45:04.854854	1	1101091000433	16652.00	101.38.1	03090000000000000
303	99	8411314	\N	2	1	2026-03-01 11:45:04.854855	1	1101091000382	16652.00	101.38.1	03090000000000000
304	99	8411632	\N	2	1	2026-03-01 11:45:04.854856	1	1101091000373	16652.00	101.38.1	03090000000000000
305	99	8411635	\N	2	1	2026-03-01 11:45:04.854857	1	1101091000402	16652.00	101.38.1	03090000000000000
306	99	8411687	\N	2	1	2026-03-01 11:45:04.854859	1	1101091000381	16652.00	101.38.1	03090000000000000
307	99	8411944	\N	2	1	2026-03-01 11:45:04.85486	1	1101091000404	16652.00	101.38.1	03090000000000000
308	99	8412271	\N	2	1	2026-03-01 11:45:04.854861	1	1101091000375	16652.00	101.38.1	03090000000000000
309	99	8412377	\N	2	1	2026-03-01 11:45:04.854862	1	1101091000444	16652.00	101.38.1	03090000000000000
310	99	8412631	\N	2	1	2026-03-01 11:45:04.854863	1	1101091000392	16652.00	101.38.1	03090000000000000
1601	116	БЕ 8000	\N	2	1	2026-03-01 11:45:05.643997	1	\N	3770.00	21.38.1	\N
311	99	8412670	\N	2	1	2026-03-01 11:45:04.854864	1	1101091000409	16652.00	101.38.1	03090000000000000
312	99	8412854	\N	2	1	2026-03-01 11:45:04.854865	1	1101091000378	16652.00	101.38.1	03090000000000000
313	99	8412980	\N	2	1	2026-03-01 11:45:04.854867	1	1101091000450	16652.00	101.38.1	03090000000000000
314	99	8414326	\N	2	1	2026-03-01 11:45:04.854868	1	1101091000415	16652.00	101.38.1	03090000000000000
315	99	8414495	\N	2	1	2026-03-01 11:45:04.854869	1	1101091000406	16652.00	101.38.1	03090000000000000
316	99	8414556	\N	2	1	2026-03-01 11:45:04.85487	1	1101091000397	16652.00	101.38.1	03090000000000000
317	99	8414844	\N	2	1	2026-03-01 11:45:04.854871	1	1101091000446	16652.00	101.38.1	03090000000000000
318	99	8415048	\N	2	1	2026-03-01 11:45:04.854872	1	1101091000374	16652.00	101.38.1	03090000000000000
319	99	8415062	\N	2	1	2026-03-01 11:45:04.854874	1	1101091000424	16652.00	101.38.1	03090000000000000
320	99	8415330	\N	2	1	2026-03-01 11:45:04.854875	1	1101091000380	16652.00	101.38.1	03090000000000000
321	99	8415512	\N	2	1	2026-03-01 11:45:04.854876	1	1101091000372	16652.00	101.38.1	03090000000000000
322	99	8415570	\N	2	1	2026-03-01 11:45:04.854877	1	1101091000387	16652.00	101.38.1	03090000000000000
323	99	8415593	\N	2	1	2026-03-01 11:45:04.854878	1	1101091000451	16652.00	101.38.1	03090000000000000
324	99	8415668	\N	2	1	2026-03-01 11:45:04.854879	1	1101091000385	16652.00	101.38.1	03090000000000000
325	99	8415790	\N	2	1	2026-03-01 11:45:04.85488	1	1101091000427	16652.00	101.38.1	03090000000000000
326	99	8415914	\N	2	1	2026-03-01 11:45:04.854881	1	1101091000436	16652.00	101.38.1	03090000000000000
327	99	8416027	\N	2	1	2026-03-01 11:45:04.854883	1	1101091000437	16652.00	101.38.1	03090000000000000
328	99	8416231	\N	2	1	2026-03-01 11:45:04.854884	1	1101091000400	16652.00	101.38.1	03090000000000000
329	99	8416531	\N	2	1	2026-03-01 11:45:04.854885	1	1101091000399	16652.00	101.38.1	03090000000000000
330	99	8416549	\N	2	1	2026-03-01 11:45:04.854886	1	1101091000390	16652.00	101.38.1	03090000000000000
331	99	8416722	\N	2	1	2026-03-01 11:45:04.854887	1	1101091000396	16652.00	101.38.1	03090000000000000
332	99	8416732	\N	2	1	2026-03-01 11:45:04.854888	1	1101091000432	16652.00	101.38.1	03090000000000000
333	99	8416855	\N	2	1	2026-03-01 11:45:04.854889	1	1101091000447	16652.00	101.38.1	03090000000000000
334	99	8416881	\N	2	1	2026-03-01 11:45:04.85489	1	1101091000459	2276.00	101.38.1	03090000000000000
335	99	8416890	\N	2	1	2026-03-01 11:45:04.854892	1	1101091000403	16652.00	101.38.1	03090000000000000
336	99	8416999	\N	2	1	2026-03-01 11:45:04.854893	1	1101091000455	16652.00	101.38.1	03090000000000000
337	99	8417085	\N	2	1	2026-03-01 11:45:04.854894	1	1101091000389	16652.00	101.38.1	03090000000000000
338	99	8417157	\N	2	1	2026-03-01 11:45:04.854895	1	1101091000421	16652.00	101.38.1	03090000000000000
339	99	8417261	\N	2	1	2026-03-01 11:45:04.854896	1	1101091000393	16652.00	101.38.1	03090000000000000
340	99	8417383	\N	2	1	2026-03-01 11:45:04.854897	1	1101091000454	16652.00	101.38.1	03090000000000000
341	99	8417399	\N	2	1	2026-03-01 11:45:04.854898	1	1101091000386	16652.00	101.38.1	03090000000000000
342	100	915796	\N	2	1	2026-03-01 11:45:04.854899	1	1101091000254	2655.00	101.38.1	03090000000000000
343	100	916637	\N	2	1	2026-03-01 11:45:04.854901	1	1101091000253	2655.00	101.38.1	03090000000000000
344	100	916652	\N	2	1	2026-03-01 11:45:04.854902	1	1101091000251	2655.00	101.38.1	03090000000000000
345	100	917347	\N	2	1	2026-03-01 11:45:04.854903	1	1101091000249	2655.00	101.38.1	03090000000000000
346	100	918154	\N	2	1	2026-03-01 11:45:04.854904	1	1101091000250	2655.00	101.38.1	03090000000000000
347	100	918239	\N	2	1	2026-03-01 11:45:04.854905	1	1101091000252	2655.00	101.38.1	03090000000000000
348	101	437278	\N	2	1	2026-03-01 11:45:04.854906	1	1101091000526	2655.00	101.38.1	03090000000000000
349	101	439700	\N	2	1	2026-03-01 11:45:04.854907	1	1101091000467	2655.00	101.38.1	03090000000000000
350	101	520468	\N	2	1	2026-03-01 11:45:04.854908	1	1101091000464	2655.00	101.38.1	03090000000000000
351	101	522366	\N	2	1	2026-03-01 11:45:04.85491	1	1101091000492	2655.00	101.38.1	03090000000000000
352	101	524100	\N	2	1	2026-03-01 11:45:04.854911	1	1101091000500	2655.00	101.38.1	03090000000000000
353	101	690097	\N	2	1	2026-03-01 11:45:04.854912	1	1101091000477	2655.00	101.38.1	03090000000000000
354	101	690166	\N	2	1	2026-03-01 11:45:04.854913	1	1101091000465	2655.00	101.38.1	03090000000000000
355	101	690297	\N	2	1	2026-03-01 11:45:04.854914	1	1101091000472	2655.00	101.38.1	03090000000000000
356	101	692668	\N	2	1	2026-03-01 11:45:04.854915	1	1101091000475	2655.00	101.38.1	03090000000000000
357	101	693573	\N	2	1	2026-03-01 11:45:04.854916	1	1101091000476	2655.00	101.38.1	03090000000000000
358	101	693594	\N	2	1	2026-03-01 11:45:04.854918	1	1101091000468	2655.00	101.38.1	03090000000000000
359	101	693720	\N	2	1	2026-03-01 11:45:04.854919	1	1101091000474	2655.00	101.38.1	03090000000000000
360	101	693783	\N	2	1	2026-03-01 11:45:04.85492	1	1101091000466	2655.00	101.38.1	03090000000000000
361	101	693843	\N	2	1	2026-03-01 11:45:04.854921	1	1101091000511	2655.00	101.38.1	03090000000000000
362	101	693950	\N	2	1	2026-03-01 11:45:04.854922	1	1101091000473	2655.00	101.38.1	03090000000000000
363	101	694391	\N	2	1	2026-03-01 11:45:04.854923	1	1101091000470	2655.00	101.38.1	03090000000000000
364	101	694529	\N	2	1	2026-03-01 11:45:04.854924	1	1101091000520	2655.00	101.38.1	03090000000000000
365	101	918026	\N	2	1	2026-03-01 11:45:04.854925	1	1101091000471	2655.00	101.38.1	03090000000000000
366	101	919564	\N	2	1	2026-03-01 11:45:04.854926	1	1101091000509	2655.00	101.38.1	03090000000000000
367	101	919599	\N	2	1	2026-03-01 11:45:04.854927	1	1101091000469	2655.00	101.38.1	03090000000000000
368	102	11С0256	\N	1	1	2026-03-01 11:45:04.854929	1	1101381002626	35540.68	101.38.1	03090000000000000
369	103	11С0255	\N	1	1	2026-03-01 11:45:04.85493	1	1101381002629	35540.67	101.38.1	03090000000000000
370	104	11С0250	\N	1	1	2026-03-01 11:45:04.854931	1	1101381002632	29393.36	101.38.1	03090000000000000
371	104	11С0251	\N	1	1	2026-03-01 11:45:04.854932	1	1101381002633	29393.36	101.38.1	03090000000000000
372	105	11С0244	\N	1	1	2026-03-01 11:45:04.854933	1	1101381002635	29393.36	101.38.1	03090000000000000
373	106	11С0254	\N	1	1	2026-03-01 11:45:04.854934	1	1101381002634	29393.36	101.38.1	03090000000000000
374	107	ЕВ 0054	\N	1	1	2026-03-01 11:45:04.854935	1	1101091000265	5250.00	101.38.1	03090000000000000
375	107	ЕВ 0066	\N	1	1	2026-03-01 11:45:04.854936	1	1101091000264	5250.00	101.38.1	03090000000000000
376	107	ЕВ 0079	\N	1	1	2026-03-01 11:45:04.854937	1	1101091000256	5250.00	101.38.1	03090000000000000
377	107	ЕВ 0097	\N	1	1	2026-03-01 11:45:04.854939	1	1101091000262	5250.00	101.38.1	03090000000000000
378	107	ЕВ 0247	\N	1	1	2026-03-01 11:45:04.85494	1	1101091000258	5250.00	101.38.1	03090000000000000
379	107	ЕВ 0252	\N	1	1	2026-03-01 11:45:04.854941	1	1101091000266	5250.00	101.38.1	03090000000000000
380	107	ЕВ 0312	\N	1	1	2026-03-01 11:45:04.854942	1	1101091000267	5250.00	101.38.1	03090000000000000
381	107	КА 1374	\N	1	1	2026-03-01 11:45:04.854943	1	1101091000255	5250.00	101.38.1	03090000000000000
382	107	КА 1480	\N	1	1	2026-03-01 11:45:04.854944	1	1101091000261	5250.00	101.38.1	03090000000000000
383	107	КА 1483	\N	1	1	2026-03-01 11:45:04.854945	1	1101091000260	5250.00	101.38.1	03090000000000000
384	107	КА 1487	\N	1	1	2026-03-01 11:45:04.854947	1	1101091000259	5250.00	101.38.1	03090000000000000
385	107	КА 1641	\N	1	1	2026-03-01 11:45:04.854948	1	1101091000257	5250.00	101.38.1	03090000000000000
386	107	МГ2305Р	\N	1	1	2026-03-01 11:45:04.854949	1	1101091000531	5250.00	101.38.1	03090000000000000
387	107	МГ2497Р	\N	1	1	2026-03-01 11:45:04.85495	1	1101091000530	5250.00	101.38.1	03090000000000000
388	108	07С0120	\N	1	1	2026-03-01 11:45:04.854951	1	1101091000159	22225.30	101.38.1	03090000000000000
389	108	07С0121	\N	1	1	2026-03-01 11:45:04.854952	1	1101091000160	22225.30	101.38.1	03090000000000000
390	109	АФ1960	\N	1	1	2026-03-01 11:45:04.854954	1	1101091002420	657.00	101.38.1	03090000000000000
391	109	АФ2184	\N	1	1	2026-03-01 11:45:04.854955	1	1101091002417	657.00	101.38.1	03090000000000000
392	109	ЕЖ404	\N	1	1	2026-03-01 11:45:04.854956	1	1101091002418	657.00	101.38.1	03090000000000000
393	109	ИА575	\N	1	1	2026-03-01 11:45:04.854957	1	1101091002419	657.00	101.38.1	03090000000000000
394	109	ИР415	\N	1	1	2026-03-01 11:45:04.854958	1	1101091002422	657.00	101.38.1	03090000000000000
395	110	ГА 470	\N	1	1	2026-03-01 11:45:04.854959	1	1101381002617	2589.79	101.38.1	03090000000000000
396	110	ИС 649	\N	1	1	2026-03-01 11:45:04.85496	1	1101381002618	2589.79	101.38.1	03090000000000000
397	110	ФЧ 2577	\N	1	1	2026-03-01 11:45:04.854962	1	1101381002619	2589.78	101.38.1	03090000000000000
398	110	ШТ 4756	\N	1	1	2026-03-01 11:45:04.854963	1	1101381002620	2589.78	101.38.1	03090000000000000
399	111	2752	\N	1	1	2026-03-01 11:45:04.854964	1	1101091002427	1088.00	101.38.1	03090000000000000
400	111	37919	\N	1	1	2026-03-01 11:45:04.854965	1	1101091002429	1088.00	101.38.1	03090000000000000
401	111	ЕР238	\N	1	1	2026-03-01 11:45:04.854966	1	1101091002428	1088.00	101.38.1	03090000000000000
402	112	348	\N	1	1	2026-03-01 11:45:04.854967	1	1101381002844	1088.00	101.38.1	03090000000000000
403	112	4428	\N	1	1	2026-03-01 11:45:04.854968	1	1101381002837	1088.00	101.38.1	03090000000000000
404	112	51828	\N	1	1	2026-03-01 11:45:04.854969	1	1101381002841	1088.00	101.38.1	03090000000000000
405	112	ДВ 7057	\N	1	1	2026-03-01 11:45:04.854971	1	1101381002847	1088.00	101.38.1	03090000000000000
406	112	ДГ 624	\N	1	1	2026-03-01 11:45:04.854972	1	1101381002834	1088.00	101.38.1	03090000000000000
407	112	ДД 137	\N	1	1	2026-03-01 11:45:04.854973	1	1101381002835	1088.00	101.38.1	03090000000000000
408	112	ЖЧ 664	\N	1	1	2026-03-01 11:45:04.854974	1	1101381002828	1088.00	101.38.1	03090000000000000
409	112	КХ 347	\N	1	1	2026-03-01 11:45:04.854975	1	1101381002839	1088.00	101.38.1	03090000000000000
410	112	РН 273	\N	1	1	2026-03-01 11:45:04.854976	1	1101381002836	1088.00	101.38.1	03090000000000000
411	112	УЗ 404	\N	1	1	2026-03-01 11:45:04.854977	1	1101381002840	1088.00	101.38.1	03090000000000000
412	112	УН 451	\N	1	1	2026-03-01 11:45:04.854978	1	1101381002843	1088.00	101.38.1	03090000000000000
413	112	ХО 916	\N	1	1	2026-03-01 11:45:04.854979	1	1101381002845	1088.00	101.38.1	03090000000000000
414	112	ЧФ 742	\N	1	1	2026-03-01 11:45:04.854981	1	1101381002829	1088.00	101.38.1	03090000000000000
415	113	70067	\N	1	1	2026-03-01 11:45:04.854982	1	1101091002441	1667.00	101.38.1	03090000000000000
416	113	89319	\N	1	1	2026-03-01 11:45:04.854983	1	1101091002440	1667.00	101.38.1	03090000000000000
417	113	ил 915	\N	1	1	2026-03-01 11:45:04.854984	1	1101091002439	1667.00	101.38.1	03090000000000000
418	114	НЯ 748	\N	2	1	2026-03-01 11:45:04.854985	1	1101091000303	6000.00	101.38.1	03090000000000000
419	115	010315	\N	1	1	2026-03-01 11:45:04.854986	1	1101091000717	11995.80	101.38.1	03090000000000000
420	115	010370	\N	1	1	2026-03-01 11:45:04.854987	1	1101091000735	11995.80	101.38.1	03090000000000000
421	115	010452	\N	1	1	2026-03-01 11:45:04.854988	1	1101091000736	11995.80	101.38.1	03090000000000000
422	115	020234	\N	1	1	2026-03-01 11:45:04.85499	1	1101091000729	11995.80	101.38.1	03090000000000000
423	115	020358	\N	1	1	2026-03-01 11:45:04.854991	1	1101091000731	11995.80	101.38.1	03090000000000000
424	115	020377	\N	1	1	2026-03-01 11:45:04.854992	1	1101091000722	11995.80	101.38.1	03090000000000000
425	115	020382	\N	2	1	2026-03-01 11:45:04.854993	1	1101381003281	11995.80	101.38.1	03090000000000000
426	115	020415	\N	1	1	2026-03-01 11:45:04.854994	1	1101091000723	11995.80	101.38.1	03090000000000000
427	115	020597	\N	1	1	2026-03-01 11:45:04.854995	1	1101091000725	11995.80	101.38.1	03090000000000000
428	115	020638	\N	1	1	2026-03-01 11:45:04.854996	1	1101091000726	11995.80	101.38.1	03090000000000000
429	115	020644	\N	2	1	2026-03-01 11:45:04.854998	1	1101381003280	11995.80	101.38.1	03090000000000000
430	116	АБ2779	\N	2	1	2026-03-01 11:45:04.854999	1	1101091000923	1117.90	101.38.1	03090000000000000
431	116	АП0276	\N	1	1	2026-03-01 11:45:04.855	1	1101091000912	1117.90	101.38.1	03090000000000000
432	116	БВ2642	\N	2	1	2026-03-01 11:45:04.855001	1	1101091000833	1117.90	101.38.1	03090000000000000
433	116	БВ3268	\N	2	1	2026-03-01 11:45:04.855002	1	1101091000749	1117.90	101.38.1	03090000000000000
434	116	БВ3491	\N	2	1	2026-03-01 11:45:04.855003	1	1101091000860	1117.90	101.38.1	03090000000000000
435	116	БВ4494	\N	2	1	2026-03-01 11:45:04.855004	1	1101091000859	1117.90	101.38.1	03090000000000000
436	116	БВ5105	\N	2	1	2026-03-01 11:45:04.855006	1	1101091000844	1117.90	101.38.1	03090000000000000
437	116	БВ7540	\N	2	1	2026-03-01 11:45:04.855007	1	1101091000757	1117.90	101.38.1	03090000000000000
438	116	БВ7630	\N	2	1	2026-03-01 11:45:04.855008	1	1101091000822	1117.90	101.38.1	03090000000000000
439	116	БГ1346	\N	2	1	2026-03-01 11:45:04.855009	1	\N	1163.02	101.38.1	03090000000000000
440	116	БГ3504	\N	2	1	2026-03-01 11:45:04.85501	1	1101091000775	1117.90	101.38.1	03090000000000000
441	116	ВЕ4974	\N	2	1	2026-03-01 11:45:04.855011	1	1101091000895	1117.90	101.38.1	03090000000000000
442	116	ВЕ5272	\N	2	1	2026-03-01 11:45:04.855012	1	\N	1163.02	101.38.1	03090000000000000
443	116	ВЕ6393	\N	2	1	2026-03-01 11:45:04.855014	1	1101091000176	1115.00	101.38.1	03090000000000000
444	116	ВЕ6709	\N	2	1	2026-03-01 11:45:04.855015	1	1101091000909	1117.90	101.38.1	03090000000000000
445	116	ВЕ6713	\N	2	1	2026-03-01 11:45:04.855016	1	1101091000904	1117.90	101.38.1	03090000000000000
446	116	ВИ4939	\N	2	1	2026-03-01 11:45:04.855017	1	\N	1163.02	101.38.1	03090000000000000
447	116	ВИ6087	\N	2	1	2026-03-01 11:45:04.855018	1	1101091000785	1117.90	101.38.1	03090000000000000
448	116	ВИ6251	\N	2	1	2026-03-01 11:45:04.855019	1	\N	1163.02	101.38.1	03090000000000000
449	116	ВИ6605	\N	2	1	2026-03-01 11:45:04.85502	1	1101091000188	1115.00	101.38.1	03090000000000000
450	116	ВИ7205	\N	2	1	2026-03-01 11:45:04.855021	1	1101091000758	1117.90	101.38.1	03090000000000000
451	116	ВИ7785	\N	2	1	2026-03-01 11:45:04.855023	1	1101091000910	1117.90	101.38.1	03090000000000000
452	116	ВЛ4918	\N	2	1	2026-03-01 11:45:04.855024	1	1101091000780	1117.90	101.38.1	03090000000000000
453	116	ВМ2589	\N	2	1	2026-03-01 11:45:04.855025	1	1101091000846	1117.90	101.38.1	03090000000000000
454	116	ВР1571Р	\N	2	1	2026-03-01 11:45:04.855026	1	1101091000767	1117.90	101.38.1	03090000000000000
455	116	ГИ 8803	\N	2	1	2026-03-01 11:45:04.855027	1	1101091000281	1118.00	101.38.1	03090000000000000
456	116	ГМ1920Л	\N	2	1	2026-03-01 11:45:04.855028	1	1101091000766	1117.90	101.38.1	03090000000000000
457	116	ГН2410	\N	2	1	2026-03-01 11:45:04.855029	1	1101091000837	1117.90	101.38.1	03090000000000000
458	116	ГО2677	\N	2	1	2026-03-01 11:45:04.85503	1	1101091000983	1117.90	101.38.1	03090000000000000
459	116	ГО4848	\N	2	1	2026-03-01 11:45:04.855032	1	1101091000828	1117.90	101.38.1	03090000000000000
460	116	ГХ1369	\N	2	1	2026-03-01 11:45:04.855033	1	1101091000938	1117.90	101.38.1	03090000000000000
461	116	ГХ2619	\N	2	1	2026-03-01 11:45:04.855034	1	1101091000788	1117.90	101.38.1	03090000000000000
462	116	ЕШ7092	\N	2	1	2026-03-01 11:45:04.855035	1	1101091000868	1117.90	101.38.1	03090000000000000
463	116	ИЛ992	\N	2	1	2026-03-01 11:45:04.855036	1	1101091000782	1117.90	101.38.1	03090000000000000
464	116	ИП6359	\N	2	1	2026-03-01 11:45:04.855037	1	1101091000989	1118.00	101.38.1	03090000000000000
465	116	КИ4006	\N	2	1	2026-03-01 11:45:04.855038	1	1101091000211	1118.00	101.38.1	03090000000000000
466	116	КИ4872	\N	2	1	2026-03-01 11:45:04.85504	1	1101091000192	1115.00	101.38.1	03090000000000000
467	116	КИ5844	\N	2	1	2026-03-01 11:45:04.855041	1	1101091000213	1118.00	101.38.1	03090000000000000
468	116	КС1513	\N	1	1	2026-03-01 11:45:04.855042	1	1101091000897	1117.90	101.38.1	03090000000000000
469	116	КС6146	\N	2	1	2026-03-01 11:45:04.855043	1	1101091000913	1117.90	101.38.1	03090000000000000
470	116	КС7358	\N	2	1	2026-03-01 11:45:04.855044	1	1101091000890	1117.90	101.38.1	03090000000000000
471	116	КС7449	\N	2	1	2026-03-01 11:45:04.855045	1	1101091000914	1117.90	101.38.1	03090000000000000
472	116	КС7482	\N	2	1	2026-03-01 11:45:04.855046	1	\N	1163.02	101.38.1	03090000000000000
473	116	КС7692	\N	2	1	2026-03-01 11:45:04.855047	1	1101091000189	1115.00	101.38.1	03090000000000000
474	116	ЛВ2089	\N	2	1	2026-03-01 11:45:04.855049	1	1101091000928	1117.90	101.38.1	03090000000000000
475	116	ЛК521	\N	2	1	2026-03-01 11:45:04.85505	1	1101091000956	1117.90	101.38.1	03090000000000000
476	116	МВ1947	\N	2	1	2026-03-01 11:45:04.855051	1	1101091000926	1117.90	101.38.1	03090000000000000
477	116	МВ1998	\N	2	1	2026-03-01 11:45:04.855052	1	1101091000930	1117.90	101.38.1	03090000000000000
478	116	МВ2107	\N	2	1	2026-03-01 11:45:04.855053	1	1101091000789	1117.90	101.38.1	03090000000000000
479	116	МВ2329	\N	2	1	2026-03-01 11:45:04.855054	1	1101091000916	1117.90	101.38.1	03090000000000000
480	116	МВ3377	\N	2	1	2026-03-01 11:45:04.855055	1	1101091000925	1117.90	101.38.1	03090000000000000
481	116	МЕ8211	\N	2	1	2026-03-01 11:45:04.855056	1	1101091000851	1117.90	101.38.1	03090000000000000
482	116	НА8525	\N	2	1	2026-03-01 11:45:04.855058	1	1101091000748	1117.90	101.38.1	03090000000000000
483	116	НГ0711	\N	2	1	2026-03-01 11:45:04.855059	1	1101091000835	1117.90	101.38.1	03090000000000000
484	116	НЕ494	\N	2	1	2026-03-01 11:45:04.85506	1	1101091000861	1117.90	101.38.1	03090000000000000
485	116	НО1377	\N	2	1	2026-03-01 11:45:04.855061	1	1101091000190	1115.00	101.38.1	03090000000000000
486	116	НУ 0092	\N	2	1	2026-03-01 11:45:04.855062	1	1101091000274	1118.00	101.38.1	03090000000000000
487	116	НУ 1456	\N	2	1	2026-03-01 11:45:04.855063	1	1101091000288	1118.00	101.38.1	03090000000000000
488	116	НУ 2084	\N	2	1	2026-03-01 11:45:04.855064	1	1101091000284	1118.00	101.38.1	03090000000000000
489	116	НУ 2529	\N	2	1	2026-03-01 11:45:04.855065	1	1101091000283	1118.00	101.38.1	03090000000000000
490	116	НУ 3171	\N	2	1	2026-03-01 11:45:04.855066	1	1101091000287	1118.00	101.38.1	03090000000000000
491	116	НУ 3584	\N	2	1	2026-03-01 11:45:04.855068	1	1101091000285	1118.00	101.38.1	03090000000000000
492	116	НУ0715	\N	2	1	2026-03-01 11:45:04.855069	1	1101091000855	1117.90	101.38.1	03090000000000000
493	116	НУ0815	\N	2	1	2026-03-01 11:45:04.85507	1	1101091000871	1117.90	101.38.1	03090000000000000
494	116	НУ1065	\N	2	1	2026-03-01 11:45:04.855071	1	1101091000872	1117.90	101.38.1	03090000000000000
495	116	НУ1187	\N	2	1	2026-03-01 11:45:04.855072	1	1101091000984	1118.00	101.38.1	03090000000000000
496	116	НУ1644	\N	2	1	2026-03-01 11:45:04.855074	1	1101091000875	1117.90	101.38.1	03090000000000000
497	116	НУ2116	\N	2	1	2026-03-01 11:45:04.855075	1	1101091000818	1117.90	101.38.1	03090000000000000
498	116	НУ2117	\N	2	1	2026-03-01 11:45:04.855076	1	1101091000853	1117.90	101.38.1	03090000000000000
499	116	НУ2129	\N	2	1	2026-03-01 11:45:04.855077	1	1101091000874	1117.90	101.38.1	03090000000000000
500	116	НУ2553	\N	2	1	2026-03-01 11:45:04.855078	1	1101091000825	1117.90	101.38.1	03090000000000000
501	116	НУ2781	\N	2	1	2026-03-01 11:45:04.855079	1	1101091000817	1117.90	101.38.1	03090000000000000
502	116	НУ3982	\N	2	1	2026-03-01 11:45:04.85508	1	1101091000978	1117.93	101.38.1	03090000000000000
503	116	НУ4932	\N	2	1	2026-03-01 11:45:04.855082	1	1101091000856	1117.90	101.38.1	03090000000000000
504	116	НУ6566	\N	2	1	2026-03-01 11:45:04.855083	1	1101091000981	1117.90	101.38.1	03090000000000000
505	116	ОБ0340	\N	2	1	2026-03-01 11:45:04.855084	1	1101091000836	1117.90	101.38.1	03090000000000000
506	116	ОМ7921	\N	2	1	2026-03-01 11:45:04.855085	1	1101091000838	1117.90	101.38.1	03090000000000000
507	116	ОН694	\N	2	1	2026-03-01 11:45:04.855086	1	1101091000980	1117.90	101.38.1	03090000000000000
508	116	ПС2105	\N	2	1	2026-03-01 11:45:04.855087	1	1101091000876	1117.90	101.38.1	03090000000000000
509	116	ПУ0379	\N	2	1	2026-03-01 11:45:04.855088	1	1101091000879	1117.90	101.38.1	03090000000000000
510	116	ПУ7487	\N	2	1	2026-03-01 11:45:04.855089	1	1101091000974	1117.90	101.38.1	03090000000000000
511	116	ПУ8288	\N	2	1	2026-03-01 11:45:04.85509	1	1101091000990	1118.00	101.38.1	03090000000000000
512	116	ПШ3139	\N	2	1	2026-03-01 11:45:04.855092	1	1101091000858	1117.90	101.38.1	03090000000000000
513	116	ПШ3640	\N	2	1	2026-03-01 11:45:04.855093	1	1101091000841	1117.90	101.38.1	03090000000000000
514	116	ПШ4111	\N	2	1	2026-03-01 11:45:04.855094	1	1101091000847	1117.90	101.38.1	03090000000000000
515	116	ПШ6331	\N	2	1	2026-03-01 11:45:04.855095	1	1101091000848	1117.90	101.38.1	03090000000000000
516	116	ПШ6514	\N	2	1	2026-03-01 11:45:04.855096	1	1101091000857	1117.90	101.38.1	03090000000000000
517	116	ПШ7227	\N	2	1	2026-03-01 11:45:04.855097	1	1101091000985	1118.00	101.38.1	03090000000000000
518	116	РВ2392	\N	2	1	2026-03-01 11:45:04.855098	1	1101091000973	1117.90	101.38.1	03090000000000000
519	116	РВ7579	\N	2	1	2026-03-01 11:45:04.855099	1	1101091000786	1117.90	101.38.1	03090000000000000
520	116	СЕ 3469	\N	1	1	2026-03-01 11:45:04.855101	1	1101381002706	1118.00	101.38.1	03090000000000000
521	116	СН 3169	\N	2	1	2026-03-01 11:45:04.855102	1	1101091000275	1118.00	101.38.1	03090000000000000
522	116	СН 3195	\N	2	1	2026-03-01 11:45:04.855103	1	1101091000291	1118.00	101.38.1	03090000000000000
523	116	СН 6049	\N	1	1	2026-03-01 11:45:04.855104	1	1101091000278	1118.00	101.38.1	03090000000000000
524	116	СН8407	\N	2	1	2026-03-01 11:45:04.855105	1	1101091000744	1117.90	101.38.1	03090000000000000
525	116	СР 0818	\N	1	1	2026-03-01 11:45:04.855106	1	1101381002659	1118.00	101.38.1	03090000000000000
526	116	СР 2366	\N	2	1	2026-03-01 11:45:04.855107	1	1101381002672	1118.00	101.38.1	03090000000000000
527	116	СР 2427	\N	2	1	2026-03-01 11:45:04.855108	1	1101381002673	1118.00	101.38.1	03090000000000000
528	116	СР 2501	\N	2	1	2026-03-01 11:45:04.85511	1	1101381002674	1118.00	101.38.1	03090000000000000
529	116	СР 2720	\N	2	1	2026-03-01 11:45:04.855111	1	1101381002676	1118.00	101.38.1	03090000000000000
530	116	СР 3444	\N	2	1	2026-03-01 11:45:04.855112	1	1101381002675	1118.00	101.38.1	03090000000000000
531	116	СТ 2978	\N	1	1	2026-03-01 11:45:04.855113	1	1101091000280	1118.00	101.38.1	03090000000000000
532	116	СТ1055	\N	2	1	2026-03-01 11:45:04.855114	1	1101091000824	1117.90	101.38.1	03090000000000000
533	116	СТ1145	\N	2	1	2026-03-01 11:45:04.855115	1	1101091000867	1117.90	101.38.1	03090000000000000
534	116	СТ5896	\N	2	1	2026-03-01 11:45:04.855116	1	1101091000842	1117.90	101.38.1	03090000000000000
535	116	ТХ 0031	\N	1	1	2026-03-01 11:45:04.855117	1	1101381002694	1118.00	101.38.1	03090000000000000
536	116	ТХ4958	\N	2	1	2026-03-01 11:45:04.855119	1	1101091000921	1117.90	101.38.1	03090000000000000
537	116	ТХ6879	\N	2	1	2026-03-01 11:45:04.85512	1	1101091000922	1117.90	101.38.1	03090000000000000
538	116	УЛ 8890	\N	2	1	2026-03-01 11:45:04.855121	1	1101381003140	5262.80	101.38.1	03090000000000000
539	116	УЛ4176	\N	2	1	2026-03-01 11:45:04.855122	1	1101091000951	1117.90	101.38.1	03090000000000000
540	116	УЛ6790	\N	1	1	2026-03-01 11:45:04.855123	1	1101091000936	1117.90	101.38.1	03090000000000000
541	116	УЛ7329	\N	2	1	2026-03-01 11:45:04.855124	1	1101091000934	1117.90	101.38.1	03090000000000000
542	116	УЛ8311	\N	2	1	2026-03-01 11:45:04.855125	1	1101091000940	1117.90	101.38.1	03090000000000000
543	116	УЛ8596	\N	2	1	2026-03-01 11:45:04.855127	1	1101091000946	1117.90	101.38.1	03090000000000000
544	116	УЛ9011	\N	2	1	2026-03-01 11:45:04.855128	1	1101091000950	1117.90	101.38.1	03090000000000000
545	116	УП4383	\N	2	1	2026-03-01 11:45:04.855129	1	\N	1163.02	101.38.1	03090000000000000
546	116	УП4576	\N	2	1	2026-03-01 11:45:04.85513	1	1101091000887	1117.90	101.38.1	03090000000000000
547	116	УП4936	\N	2	1	2026-03-01 11:45:04.855131	1	1101091000191	1115.00	101.38.1	03090000000000000
548	116	УП5789	\N	2	1	2026-03-01 11:45:04.855132	1	1101091000903	1117.90	101.38.1	03090000000000000
549	116	УП6792	\N	1	1	2026-03-01 11:45:04.855133	1	1101091000174	1115.00	101.38.1	03090000000000000
550	116	УП7752	\N	2	1	2026-03-01 11:45:04.855135	1	\N	1163.02	101.38.1	03090000000000000
551	117	ВО6021	\N	1	1	2026-03-01 11:45:04.855136	1	1101091000993	7451.92	101.38.1	03090000000000000
552	117	КО4436	\N	1	1	2026-03-01 11:45:04.855137	1	1101091000992	7451.92	101.38.1	03090000000000000
553	117	КО4437	\N	1	1	2026-03-01 11:45:04.855138	1	1101091000991	7451.92	101.38.1	03090000000000000
554	117	ТХ4438	\N	1	1	2026-03-01 11:45:04.855139	1	1101091000994	7451.93	101.38.1	03090000000000000
555	118	ГМ3159	\N	2	1	2026-03-01 11:45:04.85514	1	1101091001020	8000.00	101.38.1	03090000000000000
556	118	ГМ3166	\N	2	1	2026-03-01 11:45:04.855141	1	1101091001005	8000.00	101.38.1	03090000000000000
557	118	ГМ3173	\N	2	1	2026-03-01 11:45:04.855143	1	1101091001000	8000.00	101.38.1	03090000000000000
558	118	ГМ3200	\N	2	1	2026-03-01 11:45:04.855144	1	1101091001007	8000.00	101.38.1	03090000000000000
559	118	ГМ6463	\N	2	1	2026-03-01 11:45:04.855145	1	1101091000996	8000.00	101.38.1	03090000000000000
560	118	ГМ7108	\N	2	1	2026-03-01 11:45:04.855146	1	1101091001028	8000.00	101.38.1	03090000000000000
561	118	ГМ7116	\N	2	1	2026-03-01 11:45:04.855147	1	1101091001023	8000.00	101.38.1	03090000000000000
562	118	ГМ7130	\N	2	1	2026-03-01 11:45:04.855148	1	1101091000997	8000.00	101.38.1	03090000000000000
563	118	ГМ7149	\N	2	1	2026-03-01 11:45:04.855149	1	1101091001037	8000.00	101.38.1	03090000000000000
564	118	ГМ7170	\N	2	1	2026-03-01 11:45:04.855151	1	1101091001043	8000.00	101.38.1	03090000000000000
565	118	ГМ7180	\N	2	1	2026-03-01 11:45:04.855152	1	1101091001018	8000.00	101.38.1	03090000000000000
566	118	ГМ7181	\N	2	1	2026-03-01 11:45:04.855153	1	1101091001039	8000.00	101.38.1	03090000000000000
567	118	ГМ7206	\N	2	1	2026-03-01 11:45:04.855154	1	1101091001033	8000.00	101.38.1	03090000000000000
568	118	ГМ7212	\N	2	1	2026-03-01 11:45:04.855155	1	1101091001029	8000.00	101.38.1	03090000000000000
569	118	ИН0137	\N	2	1	2026-03-01 11:45:04.855156	1	1101091001032	8000.00	101.38.1	03090000000000000
570	118	ИН0143	\N	2	1	2026-03-01 11:45:04.855157	1	1101091001013	8000.00	101.38.1	03090000000000000
571	118	ИН0181	\N	2	1	2026-03-01 11:45:04.855158	1	1101091001027	8000.00	101.38.1	03090000000000000
572	118	ИН0185	\N	2	1	2026-03-01 11:45:04.85516	1	1101091001010	8000.00	101.38.1	03090000000000000
573	118	ИН0225	\N	2	1	2026-03-01 11:45:04.855161	1	1101091001024	8000.00	101.38.1	03090000000000000
574	118	ИН0228	\N	2	1	2026-03-01 11:45:04.855162	1	1101091001035	8000.00	101.38.1	03090000000000000
575	118	ИН0231	\N	2	1	2026-03-01 11:45:04.855163	1	1101091001015	8000.00	101.38.1	03090000000000000
576	118	ИН0233	\N	2	1	2026-03-01 11:45:04.855164	1	1101091001006	8000.00	101.38.1	03090000000000000
577	118	ИН0797	\N	2	1	2026-03-01 11:45:04.855165	1	1101091000999	8000.00	101.38.1	03090000000000000
578	119	020013	\N	1	1	2026-03-01 11:45:04.855166	1	1101091000134	14158.00	101.38.1	03090000000000000
579	119	020028	\N	1	1	2026-03-01 11:45:04.855168	1	1101091000136	14158.00	101.38.1	03090000000000000
580	119	020142	\N	1	1	2026-03-01 11:45:04.855169	1	1101091000135	14158.00	101.38.1	03090000000000000
581	119	020144	\N	1	1	2026-03-01 11:45:04.85517	1	1101091000129	14158.00	101.38.1	03090000000000000
582	119	020268	\N	1	1	2026-03-01 11:45:04.855171	1	1101091000130	14158.00	101.38.1	03090000000000000
583	119	030113	\N	1	1	2026-03-01 11:45:04.855172	1	1101091000131	14158.00	101.38.1	03090000000000000
584	119	030263	\N	1	1	2026-03-01 11:45:04.855173	1	1101091000132	14158.00	101.38.1	03090000000000000
585	120	020186	\N	1	1	2026-03-01 11:45:04.855174	1	1101091000128	26000.00	101.38.1	03090000000000000
586	121	ZKT147	\N	1	1	2026-03-01 11:45:04.855175	1	1101381003100	160886.20	101.38.1	03090000000000000
587	121	ZKT154	\N	1	1	2026-03-01 11:45:04.855177	1	1101381003093	160886.20	101.38.1	03090000000000000
588	121	ZKT199	\N	1	1	2026-03-01 11:45:04.855178	1	1101381003099	160886.20	101.38.1	03090000000000000
589	121	ZKT206	\N	1	1	2026-03-01 11:45:04.855179	1	1101381003089	160886.20	101.38.1	03090000000000000
590	121	ZKT208	\N	1	1	2026-03-01 11:45:04.85518	1	1101381003094	160886.20	101.38.1	03090000000000000
591	121	ZKT209	\N	1	1	2026-03-01 11:45:04.855181	1	1101381003091	160886.20	101.38.1	03090000000000000
592	122	ИР 5011	\N	2	1	2026-03-01 11:45:04.855182	1	1101381002599	1163.02	101.38.1	03090000000000000
593	123	код.03133	\N	2	1	2026-03-01 11:45:04.855184	1	\N	2761.00	101.38.1	03090000000000000
594	124	545170	\N	2	1	2026-03-01 11:45:04.855185	1	\N	2761.00	101.38.1	03090000000000000
595	124	545753	\N	2	1	2026-03-01 11:45:04.855186	1	\N	2761.00	101.38.1	03090000000000000
596	125	108022	\N	2	1	2026-03-01 11:45:04.855187	1	1101381003086	2761.00	101.38.1	03090000000000000
597	126	ДС01110	\N	2	1	2026-03-01 11:45:04.855188	1	1101091000329	1919.52	101.38.1	03090000000000000
598	126	ПС009463	\N	2	1	2026-03-01 11:45:04.855189	1	1101091000328	1919.52	101.38.1	03090000000000000
599	126	УС000425	\N	2	1	2026-03-01 11:45:04.855191	1	1101091000325	1919.52	101.38.1	03090000000000000
600	126	УС000752	\N	2	1	2026-03-01 11:45:04.855192	1	1101091000326	1919.52	101.38.1	03090000000000000
601	126	УС000753	\N	2	1	2026-03-01 11:45:04.855193	1	1101091000327	1919.52	101.38.1	03090000000000000
602	127	НС17465	\N	2	1	2026-03-01 11:45:04.855194	1	1101091000198	1491.00	101.38.1	03090000000000000
603	128	В008329	\N	2	1	2026-03-01 11:45:04.855195	1	1101090000298	1008.00	101.38.1	03090000000000000
604	129	СС01621	\N	2	1	2026-03-01 11:45:04.855196	1	1101091001049	1800.00	101.38.1	03090000000000000
605	129	СС01649	\N	2	1	2026-03-01 11:45:04.855197	1	1101091001050	1800.00	101.38.1	03090000000000000
606	129	СС02471	\N	2	1	2026-03-01 11:45:04.855199	1	1101091001047	1800.00	101.38.1	03090000000000000
607	129	СС03174	\N	2	1	2026-03-01 11:45:04.8552	1	1101091001048	1800.00	101.38.1	03090000000000000
608	130	НС19147	\N	2	1	2026-03-01 11:45:04.855201	1	1101091001055	1491.00	101.38.1	03090000000000000
609	130	НС19226	\N	2	1	2026-03-01 11:45:04.855202	1	1101091001054	1491.00	101.38.1	03090000000000000
610	131	ЕС056009	\N	2	1	2026-03-01 11:45:04.855203	1	1101091001072	1333.00	101.38.1	03090000000000000
611	131	УС000007	\N	2	1	2026-03-01 11:45:04.855204	1	1101091001071	1333.00	101.38.1	03090000000000000
612	131	УС000773	\N	2	1	2026-03-01 11:45:04.855206	1	1101091001068	1333.00	101.38.1	03090000000000000
613	131	УС000779	\N	2	1	2026-03-01 11:45:04.855207	1	1101091001069	1333.00	101.38.1	03090000000000000
614	131	УС000787	\N	2	1	2026-03-01 11:45:04.855208	1	1101091001067	1333.00	101.38.1	03090000000000000
615	131	УС000817	\N	2	1	2026-03-01 11:45:04.855209	1	1101091001070	1333.00	101.38.1	03090000000000000
616	131	ХС0013	\N	2	1	2026-03-01 11:45:04.85521	1	1101091001060	1333.00	101.38.1	03090000000000000
617	131	ХС008884,	\N	2	1	2026-03-01 11:45:04.855211	1	1101091001063	1333.00	101.38.1	03090000000000000
618	131	ХС009895	\N	2	1	2026-03-01 11:45:04.855212	1	1101091001064	1333.00	101.38.1	03090000000000000
619	131	ХС010615	\N	2	1	2026-03-01 11:45:04.855214	1	1101091001066	1333.00	101.38.1	03090000000000000
620	131	ХС010621	\N	2	1	2026-03-01 11:45:04.855215	1	1101091001065	1333.00	101.38.1	03090000000000000
621	131	ХС0163	\N	2	1	2026-03-01 11:45:04.855216	1	1101091001062	1333.00	101.38.1	03090000000000000
622	131	ХС0219	\N	2	1	2026-03-01 11:45:04.855217	1	1101091001061	1333.00	101.38.1	03090000000000000
623	131	ХС0385	\N	2	1	2026-03-01 11:45:04.855218	1	1101091001059	1333.00	101.38.1	03090000000000000
624	132	6300232	\N	2	1	2026-03-01 11:45:04.855219	1	1101091001079	1008.00	101.38.1	03090000000000000
625	132	6300502	\N	2	1	2026-03-01 11:45:04.85522	1	1101091001081	1008.00	101.38.1	03090000000000000
626	132	ТО68240	\N	2	1	2026-03-01 11:45:04.855222	1	1101091001082	1008.00	101.38.1	03090000000000000
627	132	ТО68270	\N	2	1	2026-03-01 11:45:04.855223	1	1101091001073	1008.00	101.38.1	03090000000000000
628	132	ТО68500	\N	2	1	2026-03-01 11:45:04.855224	1	1101091001074	1008.00	101.38.1	03090000000000000
629	132	ТО69599	\N	2	1	2026-03-01 11:45:04.855225	1	1101091001076	1008.00	101.38.1	03090000000000000
630	132	ТО70390	\N	2	1	2026-03-01 11:45:04.855226	1	1101091001077	1008.00	101.38.1	03090000000000000
631	132	ТО70539	\N	2	1	2026-03-01 11:45:04.855228	1	1101091001075	1008.00	101.38.1	03090000000000000
632	132	ТО70565	\N	2	1	2026-03-01 11:45:04.855229	1	1101091001080	1008.00	101.38.1	03090000000000000
633	133	940038	\N	2	1	2026-03-01 11:45:04.85523	1	1101091000087	3487.00	101.38.1	03090000000000000
634	134	950111	\N	2	1	2026-03-01 11:45:04.855231	1	1101091000086	7506.00	101.38.1	03090000000000000
635	135	Инв.1101091000311	\N	2	1	2026-03-01 11:45:04.855232	1	1101091000311	1510.00	101.38.1	03090000000000000
636	136	Инв.1101091001098	\N	2	1	2026-03-01 11:45:04.855233	1	1101091001098	13100.00	101.38.1	03090000000000000
637	136	Инв.1101091001121	\N	2	1	2026-03-01 11:45:04.855235	1	1101091001121	13100.00	101.38.1	03090000000000000
638	136	Инв.1101091001116	\N	2	1	2026-03-01 11:45:04.855236	1	1101091001116	13100.00	101.38.1	03090000000000000
639	136	Инв.1101091001102	\N	2	1	2026-03-01 11:45:04.855237	1	1101091001102	13100.00	101.38.1	03090000000000000
640	136	Инв.1101091001091	\N	2	1	2026-03-01 11:45:04.855238	1	1101091001091	13100.00	101.38.1	03090000000000000
641	136	Инв.1101091001103	\N	2	1	2026-03-01 11:45:04.855239	1	1101091001103	13100.00	101.38.1	03090000000000000
642	136	Инв.1101091001099	\N	2	1	2026-03-01 11:45:04.85524	1	1101091001099	13100.00	101.38.1	03090000000000000
643	136	Инв.1101091001086	\N	2	1	2026-03-01 11:45:04.855242	1	1101091001086	13100.00	101.38.1	03090000000000000
644	136	Инв.1101091001084	\N	2	1	2026-03-01 11:45:04.855243	1	1101091001084	13100.00	101.38.1	03090000000000000
645	136	Инв.1101091001090	\N	2	1	2026-03-01 11:45:04.855244	1	1101091001090	13100.00	101.38.1	03090000000000000
646	136	Инв.1101091001109	\N	2	1	2026-03-01 11:45:04.855245	1	1101091001109	13100.00	101.38.1	03090000000000000
647	136	Инв.1101091001105	\N	2	1	2026-03-01 11:45:04.855246	1	1101091001105	13100.00	101.38.1	03090000000000000
648	136	Инв.1101091001083	\N	2	1	2026-03-01 11:45:04.855247	1	1101091001083	13100.00	101.38.1	03090000000000000
649	136	Инв.1101091001120	\N	2	1	2026-03-01 11:45:04.855248	1	1101091001120	13100.00	101.38.1	03090000000000000
650	136	Инв.1101091001094	\N	2	1	2026-03-01 11:45:04.85525	1	1101091001094	13100.00	101.38.1	03090000000000000
651	136	Инв.1101091001119	\N	2	1	2026-03-01 11:45:04.855251	1	1101091001119	13100.00	101.38.1	03090000000000000
652	136	Инв.1101091001088	\N	2	1	2026-03-01 11:45:04.855252	1	1101091001088	13100.00	101.38.1	03090000000000000
653	136	Инв.1101091001089	\N	2	1	2026-03-01 11:45:04.855253	1	1101091001089	13100.00	101.38.1	03090000000000000
654	136	Инв.1101091001087	\N	2	1	2026-03-01 11:45:04.855254	1	1101091001087	13100.00	101.38.1	03090000000000000
655	136	Инв.1101091001095	\N	2	1	2026-03-01 11:45:04.855255	1	1101091001095	13100.00	101.38.1	03090000000000000
656	136	Инв.1101091001101	\N	2	1	2026-03-01 11:45:04.855256	1	1101091001101	13100.00	101.38.1	03090000000000000
657	136	Инв.1101091001104	\N	2	1	2026-03-01 11:45:04.855258	1	1101091001104	13100.00	101.38.1	03090000000000000
658	136	Инв.1101091001096	\N	2	1	2026-03-01 11:45:04.855259	1	1101091001096	13100.00	101.38.1	03090000000000000
659	136	Инв.1101091001107	\N	2	1	2026-03-01 11:45:04.85526	1	1101091001107	13100.00	101.38.1	03090000000000000
660	136	Инв.1101091001118	\N	2	1	2026-03-01 11:45:04.855261	1	1101091001118	13100.00	101.38.1	03090000000000000
661	136	Инв.1101091001085	\N	2	1	2026-03-01 11:45:04.855262	1	1101091001085	13100.00	101.38.1	03090000000000000
662	136	Инв.1101091001097	\N	2	1	2026-03-01 11:45:04.855264	1	1101091001097	13100.00	101.38.1	03090000000000000
663	136	Инв.1101091001100	\N	2	1	2026-03-01 11:45:04.855265	1	1101091001100	13100.00	101.38.1	03090000000000000
664	136	Инв.1101091001108	\N	2	1	2026-03-01 11:45:04.855266	1	1101091001108	13100.00	101.38.1	03090000000000000
665	136	Инв.1101091001106	\N	2	1	2026-03-01 11:45:04.855267	1	1101091001106	13100.00	101.38.1	03090000000000000
666	136	Инв.1101091001117	\N	2	1	2026-03-01 11:45:04.855268	1	1101091001117	13100.00	101.38.1	03090000000000000
667	136	Инв.1101091001160	\N	2	1	2026-03-01 11:45:04.855269	1	1101091001160	13100.00	101.38.1	03090000000000000
668	136	Инв.1101091001093	\N	2	1	2026-03-01 11:45:04.855271	1	1101091001093	13100.00	101.38.1	03090000000000000
669	136	Инв.1101091001092	\N	2	1	2026-03-01 11:45:04.855272	1	1101091001092	13100.00	101.38.1	03090000000000000
670	137	Инв.1101091001214	\N	2	1	2026-03-01 11:45:04.855273	1	1101091001214	12260.00	101.38.1	03090000000000000
671	137	Инв.1101091001187	\N	2	1	2026-03-01 11:45:04.855274	1	1101091001187	12260.00	101.38.1	03090000000000000
672	137	Инв.1101091001215	\N	2	1	2026-03-01 11:45:04.855275	1	1101091001215	12260.00	101.38.1	03090000000000000
673	137	Инв.1101091001211	\N	2	1	2026-03-01 11:45:04.855276	1	1101091001211	12260.00	101.38.1	03090000000000000
674	137	Инв.1101091001212	\N	2	1	2026-03-01 11:45:04.855277	1	1101091001212	12260.00	101.38.1	03090000000000000
675	137	Инв.1101091001195	\N	2	1	2026-03-01 11:45:04.855279	1	1101091001195	12260.00	101.38.1	03090000000000000
676	138	01	\N	2	1	2026-03-01 11:45:04.85528	1	1101091001161	10590.00	101.38.1	03090000000000000
677	138	02	\N	2	1	2026-03-01 11:45:04.855281	1	1101091001162	10590.00	101.38.1	03090000000000000
678	138	03	\N	2	1	2026-03-01 11:45:04.855282	1	1101091001163	10590.00	101.38.1	03090000000000000
679	138	04	\N	2	1	2026-03-01 11:45:04.855283	1	1101091001164	10590.00	101.38.1	03090000000000000
680	139	Инв.1101090600144	\N	2	1	2026-03-01 11:45:04.855284	1	1101090600144	6726.00	101.38.1	03090000000000000
681	140	Т1007	\N	2	1	2026-03-01 11:45:04.855285	1	1101091001232	4142.00	101.38.1	03090000000000000
682	140	Т1017	\N	2	1	2026-03-01 11:45:04.855287	1	1101091001230	4142.00	101.38.1	03090000000000000
683	140	Т9005	\N	2	1	2026-03-01 11:45:04.855288	1	1101091001231	4142.00	101.38.1	03090000000000000
684	141	9412044	\N	2	1	2026-03-01 11:45:04.855289	1	1101091001234	7453.00	101.38.1	03090000000000000
685	141	950248	\N	2	1	2026-03-01 11:45:04.85529	1	1101091001233	7453.00	101.38.1	03090000000000000
686	142	00033	\N	2	1	2026-03-01 11:45:04.855291	1	1101091001256	2499.00	101.38.1	03090000000000000
687	142	00095	\N	2	1	2026-03-01 11:45:04.855292	1	1101091001263	2499.00	101.38.1	03090000000000000
688	142	00153	\N	2	1	2026-03-01 11:45:04.855293	1	1101091001352	2499.00	101.38.1	03090000000000000
689	142	00155	\N	2	1	2026-03-01 11:45:04.855295	1	1101091001344	2499.00	101.38.1	03090000000000000
690	142	00156	\N	2	1	2026-03-01 11:45:04.855296	1	1101091001347	2499.00	101.38.1	03090000000000000
691	142	00157	\N	2	1	2026-03-01 11:45:04.855297	1	1101091001351	2499.00	101.38.1	03090000000000000
692	142	00158	\N	2	1	2026-03-01 11:45:04.855298	1	1101091001361	2499.00	101.38.1	03090000000000000
693	142	00159	\N	2	1	2026-03-01 11:45:04.855299	1	1101091001346	2499.00	101.38.1	03090000000000000
694	142	00165	\N	2	1	2026-03-01 11:45:04.8553	1	1101091001340	2499.00	101.38.1	03090000000000000
695	142	00166	\N	2	1	2026-03-01 11:45:04.855301	1	1101091001380	2499.00	101.38.1	03090000000000000
696	142	00167	\N	2	1	2026-03-01 11:45:04.855302	1	1101091001288	2499.00	101.38.1	03090000000000000
697	142	00170	\N	2	1	2026-03-01 11:45:04.855304	1	1101091001365	2499.00	101.38.1	03090000000000000
698	142	00171	\N	2	1	2026-03-01 11:45:04.855305	1	1101091001331	2499.00	101.38.1	03090000000000000
699	142	00172	\N	2	1	2026-03-01 11:45:04.855306	1	1101091001330	2499.00	101.38.1	03090000000000000
700	142	00173	\N	2	1	2026-03-01 11:45:04.855307	1	1101091001328	2499.00	101.38.1	03090000000000000
701	142	00174	\N	2	1	2026-03-01 11:45:04.855308	1	1101091001269	2499.00	101.38.1	03090000000000000
702	142	00176	\N	2	1	2026-03-01 11:45:04.85531	1	1101091001270	2499.00	101.38.1	03090000000000000
703	142	00177	\N	2	1	2026-03-01 11:45:04.855311	1	1101091001273	2499.00	101.38.1	03090000000000000
704	142	00178	\N	2	1	2026-03-01 11:45:04.855312	1	1101091001267	2499.00	101.38.1	03090000000000000
705	142	00179	\N	2	1	2026-03-01 11:45:04.855313	1	1101091001265	2499.00	101.38.1	03090000000000000
706	142	00180	\N	2	1	2026-03-01 11:45:04.855314	1	1101091001258	2499.00	101.38.1	03090000000000000
707	142	00181	\N	2	1	2026-03-01 11:45:04.855316	1	1101091001369	2499.00	101.38.1	03090000000000000
708	142	00182	\N	2	1	2026-03-01 11:45:04.855317	1	1101091001366	2499.00	101.38.1	03090000000000000
709	142	00184	\N	2	1	2026-03-01 11:45:04.855318	1	1101091001271	2499.00	101.38.1	03090000000000000
710	142	00185	\N	2	1	2026-03-01 11:45:04.855319	1	1101091001236	2499.00	101.38.1	03090000000000000
711	142	00188	\N	2	1	2026-03-01 11:45:04.85532	1	1101091001359	2499.00	101.38.1	03090000000000000
712	142	00192	\N	2	1	2026-03-01 11:45:04.855321	1	1101091001242	2499.00	101.38.1	03090000000000000
713	142	00194	\N	2	1	2026-03-01 11:45:04.855323	1	1101091001283	2499.00	101.38.1	03090000000000000
714	142	00195	\N	2	1	2026-03-01 11:45:04.855324	1	1101091001282	2499.00	101.38.1	03090000000000000
715	142	00197	\N	2	1	2026-03-01 11:45:04.855325	1	1101091001243	2499.00	101.38.1	03090000000000000
716	142	00198	\N	2	1	2026-03-01 11:45:04.855327	1	1101091001298	2499.00	101.38.1	03090000000000000
717	142	00199	\N	2	1	2026-03-01 11:45:04.855328	1	1101091001319	2499.00	101.38.1	03090000000000000
718	142	00200	\N	2	1	2026-03-01 11:45:04.855329	1	1101091001301	2499.00	101.38.1	03090000000000000
719	142	00201	\N	2	1	2026-03-01 11:45:04.85533	1	1101091001377	2499.00	101.38.1	03090000000000000
720	142	00202	\N	2	1	2026-03-01 11:45:04.855331	1	1101091001382	2499.00	101.38.1	03090000000000000
721	142	00203	\N	2	1	2026-03-01 11:45:04.855332	1	1101091001348	2499.00	101.38.1	03090000000000000
722	142	00204	\N	2	1	2026-03-01 11:45:04.855333	1	1101091001367	2499.00	101.38.1	03090000000000000
723	142	00205	\N	2	1	2026-03-01 11:45:04.855335	1	1101091001305	2499.00	101.38.1	03090000000000000
724	142	00206	\N	2	1	2026-03-01 11:45:04.855336	1	1101091001303	2499.00	101.38.1	03090000000000000
725	142	00207	\N	2	1	2026-03-01 11:45:04.855337	1	1101091001302	2499.00	101.38.1	03090000000000000
726	142	00208	\N	2	1	2026-03-01 11:45:04.855338	1	1101091001307	2499.00	101.38.1	03090000000000000
727	142	00209	\N	2	1	2026-03-01 11:45:04.855339	1	1101091001297	2499.00	101.38.1	03090000000000000
728	142	00210	\N	2	1	2026-03-01 11:45:04.85534	1	1101091001295	2499.00	101.38.1	03090000000000000
729	142	00211	\N	2	1	2026-03-01 11:45:04.855342	1	1101091001318	2499.00	101.38.1	03090000000000000
730	142	00213	\N	2	1	2026-03-01 11:45:04.855343	1	1101091001300	2499.00	101.38.1	03090000000000000
731	142	00214	\N	2	1	2026-03-01 11:45:04.855344	1	1101091001320	2499.00	101.38.1	03090000000000000
732	142	00216	\N	2	1	2026-03-01 11:45:04.855345	1	1101091001244	2499.00	101.38.1	03090000000000000
733	142	00217	\N	2	1	2026-03-01 11:45:04.855346	1	1101091001308	2499.00	101.38.1	03090000000000000
734	142	00218	\N	2	1	2026-03-01 11:45:04.855348	1	1101091001291	2499.00	101.38.1	03090000000000000
735	142	00220	\N	2	1	2026-03-01 11:45:04.855349	1	1101091001280	2499.00	101.38.1	03090000000000000
736	142	00221	\N	2	1	2026-03-01 11:45:04.85535	1	1101091001304	2499.00	101.38.1	03090000000000000
737	142	00222	\N	2	1	2026-03-01 11:45:04.855351	1	1101091001299	2499.00	101.38.1	03090000000000000
738	142	00223	\N	2	1	2026-03-01 11:45:04.855352	1	1101091001309	2499.00	101.38.1	03090000000000000
739	142	00224	\N	2	1	2026-03-01 11:45:04.855353	1	1101091001306	2499.00	101.38.1	03090000000000000
740	142	00225	\N	2	1	2026-03-01 11:45:04.855354	1	1101091001248	2499.00	101.38.1	03090000000000000
741	142	00226	\N	2	1	2026-03-01 11:45:04.855356	1	1101091001289	2499.00	101.38.1	03090000000000000
742	142	00228	\N	2	1	2026-03-01 11:45:04.855357	1	1101091001357	2499.00	101.38.1	03090000000000000
743	142	00230	\N	2	1	2026-03-01 11:45:04.855358	1	1101091001235	2499.00	101.38.1	03090000000000000
744	142	00231	\N	2	1	2026-03-01 11:45:04.855359	1	1101091001279	2499.00	101.38.1	03090000000000000
745	142	00234	\N	2	1	2026-03-01 11:45:04.85536	1	1101091001294	2499.00	101.38.1	03090000000000000
746	142	00235	\N	2	1	2026-03-01 11:45:04.855361	1	1101091001284	2499.00	101.38.1	03090000000000000
747	142	00239	\N	2	1	2026-03-01 11:45:04.855362	1	1101091001239	2499.00	101.38.1	03090000000000000
748	142	00241	\N	2	1	2026-03-01 11:45:04.855363	1	1101091001238	2499.00	101.38.1	03090000000000000
749	142	00245	\N	2	1	2026-03-01 11:45:04.855365	1	1101091001241	2499.00	101.38.1	03090000000000000
750	142	00247	\N	2	1	2026-03-01 11:45:04.855366	1	1101091001246	2499.00	101.38.1	03090000000000000
1602	287	ВО 6010	\N	1	1	2026-03-01 11:45:05.643998	1	\N	1000.00	21.38.1	\N
751	142	00248	\N	2	1	2026-03-01 11:45:04.855367	1	1101091001240	2499.00	101.38.1	03090000000000000
752	142	00249	\N	2	1	2026-03-01 11:45:04.855368	1	1101091001286	2499.00	101.38.1	03090000000000000
753	142	00108	\N	2	1	2026-03-01 11:45:04.855369	1	1101091001317	2499.00	101.38.1	03090000000000000
754	142	00131	\N	2	1	2026-03-01 11:45:04.85537	1	1101091001381	2499.00	101.38.1	03090000000000000
755	143	00053	\N	2	1	2026-03-01 11:45:04.855371	1	1101091001378	2499.00	101.38.1	03090000000000000
756	144	Инв.1101091000025	\N	2	1	2026-03-01 11:45:04.855372	1	1101091000025	5500.00	101.38.1	03090000000000000
757	145	Инв.1101091000027	\N	2	1	2026-03-01 11:45:04.855374	1	1101091000027	11500.00	101.38.1	03090000000000000
758	145	Инв.1101091000028	\N	2	1	2026-03-01 11:45:04.855375	1	1101091000028	11500.00	101.38.1	03090000000000000
759	145	Инв.1101091000026	\N	2	1	2026-03-01 11:45:04.855376	1	1101091000026	11500.00	101.38.1	03090000000000000
760	146	Инв.1101091001383	\N	2	1	2026-03-01 11:45:04.855377	1	1101091001383	21410.00	101.38.1	03090000000000000
761	146	Инв.1101091001386	\N	2	1	2026-03-01 11:45:04.855378	1	1101091001386	21410.00	101.38.1	03090000000000000
762	146	Инв.1101091001384	\N	2	1	2026-03-01 11:45:04.855379	1	1101091001384	21410.00	101.38.1	03090000000000000
763	146	Инв.1101091001385	\N	2	1	2026-03-01 11:45:04.855381	1	1101091001385	21410.00	101.38.1	03090000000000000
764	147	Инв.1101091000030	\N	2	1	2026-03-01 11:45:04.855382	1	1101091000030	45000.00	101.38.1	03090000000000000
765	148	Инв.1101091001396	\N	2	1	2026-03-01 11:45:04.855383	1	1101091001396	6720.00	101.38.1	03090000000000000
766	148	Инв.1101091001397	\N	2	1	2026-03-01 11:45:04.855384	1	1101091001397	6720.00	101.38.1	03090000000000000
767	148	Инв.1101091001405	\N	2	1	2026-03-01 11:45:04.855385	1	1101091001405	6720.00	101.38.1	03090000000000000
768	148	Инв.1101091001404	\N	2	1	2026-03-01 11:45:04.855386	1	1101091001404	6720.00	101.38.1	03090000000000000
769	148	Инв.1101091001403	\N	2	1	2026-03-01 11:45:04.855387	1	1101091001403	6720.00	101.38.1	03090000000000000
770	148	Инв.1101091001395	\N	2	1	2026-03-01 11:45:04.855389	1	1101091001395	6720.00	101.38.1	03090000000000000
771	148	Инв.1101091001389	\N	2	1	2026-03-01 11:45:04.85539	1	1101091001389	6720.00	101.38.1	03090000000000000
772	148	Инв.1101091001407	\N	2	1	2026-03-01 11:45:04.855391	1	1101091001407	6720.00	101.38.1	03090000000000000
773	148	Инв.1101091001388	\N	2	1	2026-03-01 11:45:04.855392	1	1101091001388	6720.00	101.38.1	03090000000000000
774	148	Инв.1101091001406	\N	2	1	2026-03-01 11:45:04.855393	1	1101091001406	6720.00	101.38.1	03090000000000000
775	148	Инв.1101091001392	\N	2	1	2026-03-01 11:45:04.855394	1	1101091001392	6720.00	101.38.1	03090000000000000
776	148	Инв.1101091001402	\N	2	1	2026-03-01 11:45:04.855396	1	1101091001402	6720.00	101.38.1	03090000000000000
777	148	Инв.1101091001387	\N	2	1	2026-03-01 11:45:04.855397	1	1101091001387	6720.00	101.38.1	03090000000000000
778	148	Инв.1101091001401	\N	2	1	2026-03-01 11:45:04.855398	1	1101091001401	6720.00	101.38.1	03090000000000000
779	148	Инв.1101091001390	\N	2	1	2026-03-01 11:45:04.855399	1	1101091001390	6720.00	101.38.1	03090000000000000
780	148	Инв.1101091001398	\N	2	1	2026-03-01 11:45:04.8554	1	1101091001398	6720.00	101.38.1	03090000000000000
781	148	Инв.1101091001393	\N	2	1	2026-03-01 11:45:04.855401	1	1101091001393	6720.00	101.38.1	03090000000000000
782	148	Инв.1101091001399	\N	2	1	2026-03-01 11:45:04.855402	1	1101091001399	6720.00	101.38.1	03090000000000000
783	148	Инв.1101091001400	\N	2	1	2026-03-01 11:45:04.855403	1	1101091001400	6720.00	101.38.1	03090000000000000
784	148	Инв.1101091001391	\N	2	1	2026-03-01 11:45:04.855405	1	1101091001391	6720.00	101.38.1	03090000000000000
785	148	Инв.1101091001394	\N	2	1	2026-03-01 11:45:04.855406	1	1101091001394	6720.00	101.38.1	03090000000000000
786	149	Инв.1101091001469	\N	2	1	2026-03-01 11:45:04.855407	1	1101091001469	180.00	101.38.1	03090000000000000
787	149	Инв.1101091001450	\N	2	1	2026-03-01 11:45:04.855408	1	1101091001450	180.00	101.38.1	03090000000000000
788	149	Инв.1101091001457	\N	2	1	2026-03-01 11:45:04.855409	1	1101091001457	180.00	101.38.1	03090000000000000
789	149	Инв.1101091001464	\N	2	1	2026-03-01 11:45:04.85541	1	1101091001464	180.00	101.38.1	03090000000000000
790	149	Инв.1101091001427	\N	2	1	2026-03-01 11:45:04.855411	1	1101091001427	180.00	101.38.1	03090000000000000
791	149	Инв.1101091001420	\N	2	1	2026-03-01 11:45:04.855413	1	1101091001420	180.00	101.38.1	03090000000000000
792	149	Инв.1101091001428	\N	2	1	2026-03-01 11:45:04.855414	1	1101091001428	180.00	101.38.1	03090000000000000
793	149	Инв.1101091001439	\N	2	1	2026-03-01 11:45:04.855415	1	1101091001439	180.00	101.38.1	03090000000000000
794	149	Инв.1101091001465	\N	2	1	2026-03-01 11:45:04.855416	1	1101091001465	180.00	101.38.1	03090000000000000
795	149	Инв.1101091001426	\N	2	1	2026-03-01 11:45:04.855417	1	1101091001426	180.00	101.38.1	03090000000000000
796	149	Инв.1101091001429	\N	2	1	2026-03-01 11:45:04.855418	1	1101091001429	180.00	101.38.1	03090000000000000
797	149	Инв.1101091001458	\N	2	1	2026-03-01 11:45:04.855419	1	1101091001458	180.00	101.38.1	03090000000000000
798	149	Инв.1101091001438	\N	2	1	2026-03-01 11:45:04.85542	1	1101091001438	180.00	101.38.1	03090000000000000
799	149	Инв.1101091001460	\N	2	1	2026-03-01 11:45:04.855422	1	1101091001460	180.00	101.38.1	03090000000000000
800	149	Инв.1101091001422	\N	2	1	2026-03-01 11:45:04.855423	1	1101091001422	180.00	101.38.1	03090000000000000
801	149	Инв.1101091001432	\N	2	1	2026-03-01 11:45:04.855424	1	1101091001432	180.00	101.38.1	03090000000000000
802	149	Инв.1101091001431	\N	2	1	2026-03-01 11:45:04.855425	1	1101091001431	180.00	101.38.1	03090000000000000
803	149	Инв.1101091001419	\N	2	1	2026-03-01 11:45:04.855426	1	1101091001419	180.00	101.38.1	03090000000000000
804	149	Инв.1101091001433	\N	2	1	2026-03-01 11:45:04.855428	1	1101091001433	180.00	101.38.1	03090000000000000
805	149	Инв.1101091001430	\N	2	1	2026-03-01 11:45:04.855429	1	1101091001430	180.00	101.38.1	03090000000000000
806	149	Инв.1101091001456	\N	2	1	2026-03-01 11:45:04.85543	1	1101091001456	180.00	101.38.1	03090000000000000
807	149	Инв.1101091001409	\N	2	1	2026-03-01 11:45:04.855431	1	1101091001409	180.00	101.38.1	03090000000000000
808	149	Инв.1101091001468	\N	2	1	2026-03-01 11:45:04.855432	1	1101091001468	180.00	101.38.1	03090000000000000
1603	287	МБ8891	\N	1	1	2026-03-01 11:45:05.643999	1	\N	1117.90	21.38.1	\N
809	149	Инв.1101091001467	\N	2	1	2026-03-01 11:45:04.855433	1	1101091001467	180.00	101.38.1	03090000000000000
810	149	Инв.1101091001440	\N	2	1	2026-03-01 11:45:04.855434	1	1101091001440	180.00	101.38.1	03090000000000000
811	149	Инв.1101091001421	\N	2	1	2026-03-01 11:45:04.855436	1	1101091001421	180.00	101.38.1	03090000000000000
812	149	Инв.1101091001436	\N	2	1	2026-03-01 11:45:04.855437	1	1101091001436	180.00	101.38.1	03090000000000000
813	149	Инв.1101091001446	\N	2	1	2026-03-01 11:45:04.855438	1	1101091001446	180.00	101.38.1	03090000000000000
814	149	Инв.1101091001434	\N	2	1	2026-03-01 11:45:04.855439	1	1101091001434	180.00	101.38.1	03090000000000000
815	149	Инв.1101091001455	\N	2	1	2026-03-01 11:45:04.85544	1	1101091001455	180.00	101.38.1	03090000000000000
816	149	Инв.1101091001413	\N	2	1	2026-03-01 11:45:04.855441	1	1101091001413	180.00	101.38.1	03090000000000000
817	149	Инв.1101091001418	\N	2	1	2026-03-01 11:45:04.855442	1	1101091001418	180.00	101.38.1	03090000000000000
818	149	Инв.1101091001463	\N	2	1	2026-03-01 11:45:04.855444	1	1101091001463	180.00	101.38.1	03090000000000000
819	149	Инв.1101091001442	\N	2	1	2026-03-01 11:45:04.855445	1	1101091001442	180.00	101.38.1	03090000000000000
820	149	Инв.1101091001443	\N	2	1	2026-03-01 11:45:04.855446	1	1101091001443	180.00	101.38.1	03090000000000000
821	149	Инв.1101091001410	\N	2	1	2026-03-01 11:45:04.855447	1	1101091001410	180.00	101.38.1	03090000000000000
822	149	Инв.1101091001448	\N	2	1	2026-03-01 11:45:04.855448	1	1101091001448	180.00	101.38.1	03090000000000000
823	149	Инв.1101091001462	\N	2	1	2026-03-01 11:45:04.855449	1	1101091001462	180.00	101.38.1	03090000000000000
824	149	Инв.1101091001452	\N	2	1	2026-03-01 11:45:04.855451	1	1101091001452	180.00	101.38.1	03090000000000000
825	149	Инв.1101091001414	\N	2	1	2026-03-01 11:45:04.855452	1	1101091001414	180.00	101.38.1	03090000000000000
826	149	Инв.1101091001437	\N	2	1	2026-03-01 11:45:04.855453	1	1101091001437	180.00	101.38.1	03090000000000000
827	149	Инв.1101091001441	\N	2	1	2026-03-01 11:45:04.855454	1	1101091001441	180.00	101.38.1	03090000000000000
828	149	Инв.1101091001425	\N	2	1	2026-03-01 11:45:04.855455	1	1101091001425	180.00	101.38.1	03090000000000000
829	149	Инв.1101091001417	\N	2	1	2026-03-01 11:45:04.855456	1	1101091001417	180.00	101.38.1	03090000000000000
830	149	Инв.1101091001451	\N	2	1	2026-03-01 11:45:04.855457	1	1101091001451	180.00	101.38.1	03090000000000000
831	149	Инв.1101091001447	\N	2	1	2026-03-01 11:45:04.855459	1	1101091001447	180.00	101.38.1	03090000000000000
832	149	Инв.1101091001423	\N	2	1	2026-03-01 11:45:04.85546	1	1101091001423	180.00	101.38.1	03090000000000000
833	149	Инв.1101091001459	\N	2	1	2026-03-01 11:45:04.855461	1	1101091001459	180.00	101.38.1	03090000000000000
834	149	Инв.1101091001466	\N	2	1	2026-03-01 11:45:04.855462	1	1101091001466	180.00	101.38.1	03090000000000000
835	149	Инв.1101091001424	\N	2	1	2026-03-01 11:45:04.855463	1	1101091001424	180.00	101.38.1	03090000000000000
836	149	Инв.1101091001454	\N	2	1	2026-03-01 11:45:04.855464	1	1101091001454	180.00	101.38.1	03090000000000000
837	149	Инв.1101091001461	\N	2	1	2026-03-01 11:45:04.855466	1	1101091001461	180.00	101.38.1	03090000000000000
838	149	Инв.1101091001453	\N	2	1	2026-03-01 11:45:04.855467	1	1101091001453	180.00	101.38.1	03090000000000000
839	149	Инв.1101091001412	\N	2	1	2026-03-01 11:45:04.855468	1	1101091001412	180.00	101.38.1	03090000000000000
840	149	Инв.1101091001435	\N	2	1	2026-03-01 11:45:04.855469	1	1101091001435	180.00	101.38.1	03090000000000000
841	149	Инв.1101091001416	\N	2	1	2026-03-01 11:45:04.85547	1	1101091001416	180.00	101.38.1	03090000000000000
842	149	Инв.1101091001411	\N	2	1	2026-03-01 11:45:04.855471	1	1101091001411	180.00	101.38.1	03090000000000000
843	149	Инв.1101091001408	\N	2	1	2026-03-01 11:45:04.855472	1	1101091001408	180.00	101.38.1	03090000000000000
844	149	Инв.1101091001445	\N	2	1	2026-03-01 11:45:04.855474	1	1101091001445	180.00	101.38.1	03090000000000000
845	149	Инв.1101091001415	\N	2	1	2026-03-01 11:45:04.855475	1	1101091001415	180.00	101.38.1	03090000000000000
846	149	Инв.1101091001449	\N	2	1	2026-03-01 11:45:04.855476	1	1101091001449	180.00	101.38.1	03090000000000000
847	149	Инв.1101091001444	\N	2	1	2026-03-01 11:45:04.855477	1	1101091001444	180.00	101.38.1	03090000000000000
848	150	8В205	\N	2	1	2026-03-01 11:45:04.855478	1	1101091001477	89748.00	101.38.1	03090000000000000
849	150	БЛ0490Л	\N	2	1	2026-03-01 11:45:04.855479	1	1101091001476	89748.00	101.38.1	03090000000000000
850	151	АН7978	\N	2	1	2026-03-01 11:45:04.855481	1	1101381003382	60000.00	101.38.1	03090000000000000
851	151	АР 2698	\N	2	1	2026-03-01 11:45:04.855482	1	1101381003383	60000.00	101.38.1	03090000000000000
852	151	ТО № 9247	\N	2	1	2026-03-01 11:45:04.855483	1	1101381003384	60000.00	101.38.1	03090000000000000
853	152	Инв.1101091001491	\N	2	1	2026-03-01 11:45:04.855484	1	1101091001491	8000.00	101.38.1	03090000000000000
854	152	Инв.1101091001489	\N	2	1	2026-03-01 11:45:04.855485	1	1101091001489	8000.00	101.38.1	03090000000000000
855	152	Инв.1101091001486	\N	2	1	2026-03-01 11:45:04.855486	1	1101091001486	8000.00	101.38.1	03090000000000000
856	152	Инв.1101091001483	\N	2	1	2026-03-01 11:45:04.855488	1	1101091001483	8000.00	101.38.1	03090000000000000
857	152	Инв.1101091001478	\N	2	1	2026-03-01 11:45:04.855489	1	1101091001478	8000.00	101.38.1	03090000000000000
858	152	Инв.1101091001481	\N	2	1	2026-03-01 11:45:04.85549	1	1101091001481	8000.00	101.38.1	03090000000000000
859	152	Инв.1101091001488	\N	2	1	2026-03-01 11:45:04.855491	1	1101091001488	8000.00	101.38.1	03090000000000000
860	152	Инв.1101091001485	\N	2	1	2026-03-01 11:45:04.855492	1	1101091001485	8000.00	101.38.1	03090000000000000
861	152	Инв.1101091001484	\N	2	1	2026-03-01 11:45:04.855494	1	1101091001484	8000.00	101.38.1	03090000000000000
862	152	Инв.1101091001479	\N	2	1	2026-03-01 11:45:04.855495	1	1101091001479	8000.00	101.38.1	03090000000000000
863	152	Инв.1101091001487	\N	2	1	2026-03-01 11:45:04.855496	1	1101091001487	8000.00	101.38.1	03090000000000000
864	152	Инв.1101091001482	\N	2	1	2026-03-01 11:45:04.855497	1	1101091001482	8000.00	101.38.1	03090000000000000
865	152	Инв.1101091001490	\N	2	1	2026-03-01 11:45:04.855498	1	1101091001490	8000.00	101.38.1	03090000000000000
866	152	Инв.1101091001492	\N	2	1	2026-03-01 11:45:04.855499	1	1101091001492	8000.00	101.38.1	03090000000000000
867	152	Инв.1101091001480	\N	2	1	2026-03-01 11:45:04.855501	1	1101091001480	8000.00	101.38.1	03090000000000000
868	153	Инв.1101091000063	\N	2	1	2026-03-01 11:45:04.855502	1	1101091000063	6270.00	101.38.1	03090000000000000
869	154	00026	\N	1	1	2026-03-01 11:45:04.855503	1	1101091000227	22500.00	101.38.1	03090000000000000
870	154	00028	\N	1	1	2026-03-01 11:45:04.855504	1	1101091000229	22500.00	101.38.1	03090000000000000
871	155	КА 1480	\N	2	1	2026-03-01 11:45:04.855505	1	1101091000312	520.00	101.38.1	03090000000000000
872	156	Инв.1101091000018	\N	2	1	2026-03-01 11:45:04.855506	1	1101091000018	10879.00	101.38.1	03090000000000000
873	157	13675646	\N	2	1	2026-03-01 11:45:04.855508	1	1101381002972	14820.00	101.38.1	03090000000000000
874	157	13675751	\N	2	1	2026-03-01 11:45:04.855509	1	1101381002978	14820.00	101.38.1	03090000000000000
875	157	13675784	\N	2	1	2026-03-01 11:45:04.85551	1	1101381002979	14820.00	101.38.1	03090000000000000
876	157	13675808	\N	2	1	2026-03-01 11:45:04.855511	1	1101381002980	14820.00	101.38.1	03090000000000000
877	157	13675898	\N	2	1	2026-03-01 11:45:04.855512	1	1101381002981	14820.00	101.38.1	03090000000000000
878	157	13675920	\N	2	1	2026-03-01 11:45:04.855513	1	1101381002982	14820.00	101.38.1	03090000000000000
879	158	0010392	\N	2	1	2026-03-01 11:45:04.855514	1	1101091001585	3500.00	101.38.1	03090000000000000
880	158	0010395	\N	2	1	2026-03-01 11:45:04.855516	1	1101091001586	3500.00	101.38.1	03090000000000000
881	158	0010425	\N	2	1	2026-03-01 11:45:04.855517	1	1101091001587	3500.00	101.38.1	03090000000000000
882	159	Т/Ж 0400	\N	1	1	2026-03-01 11:45:04.855518	1	1101091002443	30000.00	101.38.1	03090000000000000
883	160	ТЖ 0463	\N	1	1	2026-03-01 11:45:04.855519	1	1101381002940	5329.00	101.38.1	03090000000000000
884	160	ТЖ 0467	\N	1	1	2026-03-01 11:45:04.85552	1	1101381002944	5329.00	101.38.1	03090000000000000
885	160	ТЖ 0468	\N	1	1	2026-03-01 11:45:04.855521	1	1101381002945	5329.00	101.38.1	03090000000000000
886	160	ТЖ 0469	\N	1	1	2026-03-01 11:45:04.855523	1	1101381002946	5329.00	101.38.1	03090000000000000
887	160	ТЖ 0471	\N	1	1	2026-03-01 11:45:04.855524	1	1101381002948	5329.00	101.38.1	03090000000000000
888	160	ТЖ 0472	\N	1	1	2026-03-01 11:45:04.855525	1	1101381002949	5329.00	101.38.1	03090000000000000
889	160	ТЖ 0473	\N	1	1	2026-03-01 11:45:04.855526	1	1101381002950	5329.00	101.38.1	03090000000000000
890	160	ТЖ 0474	\N	1	1	2026-03-01 11:45:04.855527	1	1101381002951	5329.00	101.38.1	03090000000000000
891	160	ТЖ 0475	\N	1	1	2026-03-01 11:45:04.855528	1	1101381002952	5329.00	101.38.1	03090000000000000
892	160	ТЖ 0488	\N	1	1	2026-03-01 11:45:04.85553	1	1101381002965	5329.00	101.38.1	03090000000000000
893	160	ТЖ 0489	\N	1	1	2026-03-01 11:45:04.855531	1	1101381002966	5329.00	101.38.1	03090000000000000
894	160	ТЖ 0490	\N	1	1	2026-03-01 11:45:04.855532	1	1101381002967	5329.00	101.38.1	03090000000000000
895	160	ТЖ 0491	\N	1	1	2026-03-01 11:45:04.855533	1	1101381002968	5329.00	101.38.1	03090000000000000
896	160	ТЖ 0492	\N	1	1	2026-03-01 11:45:04.855534	1	1101381002969	5329.00	101.38.1	03090000000000000
897	160	ТЖ 0493	\N	1	1	2026-03-01 11:45:04.855535	1	1101381002970	5329.00	101.38.1	03090000000000000
898	160	ТЖ 0494	\N	1	1	2026-03-01 11:45:04.855537	1	1101381002971	5329.00	101.38.1	03090000000000000
899	161	950537	\N	2	1	2026-03-01 11:45:04.855538	1	1101091001691	3925.00	101.38.1	03090000000000000
900	161	951207	\N	2	1	2026-03-01 11:45:04.855539	1	1101091001692	3925.00	101.38.1	03090000000000000
901	162	Б/Н-922	\N	2	1	2026-03-01 11:45:04.85554	1	\N	784.70	101.38.1	03090000000000000
902	163	Инв.1101091001697	\N	2	1	2026-03-01 11:45:04.855541	1	1101091001697	55160.00	101.38.1	03090000000000000
903	163	Инв.1101091001700	\N	2	1	2026-03-01 11:45:04.855542	1	1101091001700	55160.00	101.38.1	03090000000000000
904	163	Инв.1101091001696	\N	2	1	2026-03-01 11:45:04.855543	1	1101091001696	55160.00	101.38.1	03090000000000000
905	163	Инв.1101091001693	\N	2	1	2026-03-01 11:45:04.855545	1	1101091001693	55160.00	101.38.1	03090000000000000
906	163	Инв.1101091001706	\N	2	1	2026-03-01 11:45:04.855546	1	1101091001706	55160.00	101.38.1	03090000000000000
907	163	Инв.1101091001695	\N	2	1	2026-03-01 11:45:04.855547	1	1101091001695	55160.00	101.38.1	03090000000000000
908	163	Инв.1101091001698	\N	2	1	2026-03-01 11:45:04.855548	1	1101091001698	55160.00	101.38.1	03090000000000000
909	163	Инв.1101091001704	\N	2	1	2026-03-01 11:45:04.855549	1	1101091001704	55160.00	101.38.1	03090000000000000
910	163	Инв.1101091001694	\N	2	1	2026-03-01 11:45:04.85555	1	1101091001694	55160.00	101.38.1	03090000000000000
911	163	Инв.1101091001703	\N	2	1	2026-03-01 11:45:04.855551	1	1101091001703	55160.00	101.38.1	03090000000000000
912	163	Инв.1101091001701	\N	2	1	2026-03-01 11:45:04.855553	1	1101091001701	55160.00	101.38.1	03090000000000000
913	163	Инв.1101091001705	\N	2	1	2026-03-01 11:45:04.855554	1	1101091001705	55160.00	101.38.1	03090000000000000
914	163	Инв.1101091001707	\N	2	1	2026-03-01 11:45:04.855555	1	1101091001707	55160.00	101.38.1	03090000000000000
915	163	Инв.1101091001702	\N	2	1	2026-03-01 11:45:04.855556	1	1101091001702	55160.00	101.38.1	03090000000000000
916	163	Инв.1101091001699	\N	2	1	2026-03-01 11:45:04.855557	1	1101091001699	55160.00	101.38.1	03090000000000000
917	164	Инв.1101090000024	\N	2	1	2026-03-01 11:45:04.855559	1	1101090000024	3060.00	101.38.1	03090000000000000
918	165	950016	\N	2	1	2026-03-01 11:45:04.85556	1	1101090000023	1428.00	101.38.1	03090000000000000
919	166	9602562	\N	2	1	2026-03-01 11:45:04.855561	1	1101091001712	1437.00	101.38.1	03090000000000000
920	166	9602836	\N	2	1	2026-03-01 11:45:04.855562	1	1101091001708	1437.00	101.38.1	03090000000000000
921	166	9602933	\N	2	1	2026-03-01 11:45:04.855563	1	1101091001711	1437.00	101.38.1	03090000000000000
922	166	9602951	\N	2	1	2026-03-01 11:45:04.855564	1	1101091001709	1437.00	101.38.1	03090000000000000
923	166	9602965	\N	2	1	2026-03-01 11:45:04.855565	1	1101091001710	1437.00	101.38.1	03090000000000000
924	167	94315	\N	2	1	2026-03-01 11:45:04.855567	1	1101090000021	1437.00	101.38.1	03090000000000000
925	168	0102968	\N	2	1	2026-03-01 11:45:04.855568	1	1101091001714	1500.00	101.38.1	03090000000000000
926	168	0105257	\N	2	1	2026-03-01 11:45:04.855569	1	1101091001713	1500.00	101.38.1	03090000000000000
927	168	0105398	\N	2	1	2026-03-01 11:45:04.85557	1	1101091001715	1500.00	101.38.1	03090000000000000
1604	116	ГИ 1760	\N	2	1	2026-03-01 11:45:05.644	1	\N	3770.00	21.38.1	\N
928	169	Инв.1101091001717	\N	2	1	2026-03-01 11:45:04.855572	1	1101091001717	700.00	101.38.1	03090000000000000
929	169	Инв.1101091001719	\N	2	1	2026-03-01 11:45:04.855573	1	1101091001719	700.00	101.38.1	03090000000000000
930	169	Инв.1101091001718	\N	2	1	2026-03-01 11:45:04.855574	1	1101091001718	700.00	101.38.1	03090000000000000
931	169	Инв.1101091001716	\N	2	1	2026-03-01 11:45:04.855575	1	1101091001716	700.00	101.38.1	03090000000000000
932	169	Инв.1101091001720	\N	2	1	2026-03-01 11:45:04.855576	1	1101091001720	700.00	101.38.1	03090000000000000
933	170	б/н	\N	2	1	2026-03-01 11:45:04.855578	1	1101091000019	1437.00	101.38.1	03090000000000000
934	171	Р722	\N	2	1	2026-03-01 11:45:04.855579	1	1101091000003	65360.00	101.38.1	03090000000000000
935	172	К04467	\N	2	1	2026-03-01 11:45:04.85558	1	1101091000004	7800.00	101.38.1	03090000000000000
936	173	У0039	\N	2	1	2026-03-01 11:45:04.855581	1	1101091000005	70833.00	101.38.1	03090000000000000
937	174	У09599	\N	2	1	2026-03-01 11:45:04.855582	1	1101091000056	12000.00	101.38.1	03090000000000000
938	175	0071	\N	2	1	2026-03-01 11:45:04.855584	1	1101091000058	1437.00	101.38.1	03090000000000000
939	176	940654	\N	2	1	2026-03-01 11:45:04.855585	1	1101091000059	4212.00	101.38.1	03090000000000000
940	177	Инв.1101381002983	\N	2	1	2026-03-01 11:45:04.855586	1	1101381002983	8980.00	101.38.1	03090000000000000
941	178	Л 0009	\N	1	1	2026-03-01 11:45:04.855587	1	1101341301910	12000.00	101.38.1	03090000000000000
942	178	Л 0011	\N	1	1	2026-03-01 11:45:04.855588	1	1101341301912	12000.00	101.38.1	03090000000000000
943	178	Л 0013	\N	1	1	2026-03-01 11:45:04.855589	1	1101341301914	12000.00	101.38.1	03090000000000000
944	178	Л 0015	\N	1	1	2026-03-01 11:45:04.85559	1	1101341301916	12000.00	101.38.1	03090000000000000
945	178	Л 0017	\N	1	1	2026-03-01 11:45:04.855592	1	1101341301917	12000.00	101.38.1	03090000000000000
946	178	Л 0020	\N	1	1	2026-03-01 11:45:04.855593	1	1101341301918	12000.00	101.38.1	03090000000000000
947	179	0815325483	\N	2	1	2026-03-01 11:45:04.855594	1	1101381003377	33000.00	101.38.1	03090000000000000
948	179	0815360751	\N	2	1	2026-03-01 11:45:04.855595	1	1101381003378	33000.00	101.38.1	03090000000000000
949	180	0515316356	\N	2	1	2026-03-01 11:45:04.855596	1	1101381003441	33000.00	101.38.1	03090000000000000
950	180	0515321283	\N	2	1	2026-03-01 11:45:04.855597	1	1101381003445	33000.00	101.38.1	03090000000000000
951	180	0515339122	\N	2	1	2026-03-01 11:45:04.855598	1	1101381003443	33000.00	101.38.1	03090000000000000
952	180	0615313411	\N	2	1	2026-03-01 11:45:04.8556	1	1101381003440	33000.00	101.38.1	03090000000000000
953	180	0715330337	\N	2	1	2026-03-01 11:45:04.855601	1	1101381003444	33000.00	101.38.1	03090000000000000
954	180	07П213	\N	2	1	2026-03-01 11:45:04.855602	1	1101381003447	33000.00	101.38.1	03090000000000000
955	180	0815357695	\N	2	1	2026-03-01 11:45:04.855603	1	1101381003446	33000.00	101.38.1	03090000000000000
956	180	0915340387	\N	2	1	2026-03-01 11:45:04.855604	1	1101381003442	33000.00	101.38.1	03090000000000000
957	181	0715358184	\N	2	1	2026-03-01 11:45:04.855605	1	1101381003448	33000.00	101.38.1	03090000000000000
958	182	1515504451	\N	2	1	2026-03-01 11:45:04.855606	1	1101381003381	20000.00	101.38.1	03090000000000000
959	182	1515504671	\N	2	1	2026-03-01 11:45:04.855608	1	1101381003380	20000.00	101.38.1	03090000000000000
960	182	1515523861	\N	2	1	2026-03-01 11:45:04.855609	1	1101381003449	20000.00	101.38.1	03090000000000000
961	182	1715532224	\N	2	1	2026-03-01 11:45:04.85561	1	1101381003379	20000.00	101.38.1	03090000000000000
962	183	Инв.1101381003283	\N	2	1	2026-03-01 11:45:04.855611	1	1101381003283	36900.00	101.38.1	03090000000000000
963	183	Инв.1101381003284	\N	2	1	2026-03-01 11:45:04.855612	1	1101381003284	36900.00	101.38.1	03090000000000000
964	183	Инв.1101091000200	\N	2	1	2026-03-01 11:45:04.855613	1	1101091000200	36900.00	101.38.1	03090000000000000
1546	278	Б/Н-1585	\N	2	1	2026-03-01 11:45:05.643932	1	\N	4800.00	21.34.1	\N
965	184	Курс-С	\N	2	1	2026-03-01 11:45:04.855615	5	1101381003426	24500.00	101.38.1	03090000000000000
967	185	0433710633	\N	2	1	2026-03-01 11:45:05.643246	1	1101091001724	7000.00	101.38.1	03090000000000000
968	185	0433710886	\N	2	1	2026-03-01 11:45:05.643248	1	1101091001725	7000.00	101.38.1	03090000000000000
969	185	0433710908	\N	2	1	2026-03-01 11:45:05.643249	1	1101091001723	7000.00	101.38.1	03090000000000000
970	186	Инв.1101091000171	\N	1	1	2026-03-01 11:45:05.64325	1	1101091000171	6000.00	101.38.1	03090000000000000
971	186	Инв.1101091000173	\N	1	1	2026-03-01 11:45:05.643251	1	1101091000173	6000.00	101.38.1	03090000000000000
972	186	Инв.1101091000170	\N	1	1	2026-03-01 11:45:05.643253	1	1101091000170	6000.00	101.38.1	03090000000000000
973	186	Инв.1101091000168	\N	1	1	2026-03-01 11:45:05.643254	1	1101091000168	6000.00	101.38.1	03090000000000000
974	186	Инв.1101091000167	\N	1	1	2026-03-01 11:45:05.643255	1	1101091000167	6000.00	101.38.1	03090000000000000
975	186	Инв.1101091000169	\N	1	1	2026-03-01 11:45:05.643256	1	1101091000169	6000.00	101.38.1	03090000000000000
976	186	Инв.1101091000166	\N	1	1	2026-03-01 11:45:05.643257	1	1101091000166	6000.00	101.38.1	03090000000000000
977	187	Инв.1101091000011	\N	1	1	2026-03-01 11:45:05.643259	1	1101091000011	3900.00	101.38.1	03090000000000000
978	188	Инв.1101381003009	\N	1	1	2026-03-01 11:45:05.64326	1	1101381003009	4500.00	101.38.1	03090000000000000
979	188	Инв.1101381003010	\N	1	1	2026-03-01 11:45:05.643261	1	1101381003010	4500.00	101.38.1	03090000000000000
980	188	Инв.1101381003013	\N	1	1	2026-03-01 11:45:05.643262	1	1101381003013	4500.00	101.38.1	03090000000000000
981	188	Инв.1101381003012	\N	1	1	2026-03-01 11:45:05.643264	1	1101381003012	4500.00	101.38.1	03090000000000000
982	188	Инв.1101381003011	\N	1	1	2026-03-01 11:45:05.643265	1	1101381003011	4500.00	101.38.1	03090000000000000
983	189	041	\N	2	1	2026-03-01 11:45:05.643266	1	1101381002511	8400.00	101.38.1	03090000000000000
984	189	043	\N	2	1	2026-03-01 11:45:05.643267	1	1101381002513	8400.00	101.38.1	03090000000000000
985	189	044	\N	2	1	2026-03-01 11:45:05.643269	1	1101381002514	8400.00	101.38.1	03090000000000000
986	189	045	\N	2	1	2026-03-01 11:45:05.64327	1	1101381002515	8400.00	101.38.1	03090000000000000
987	189	047	\N	2	1	2026-03-01 11:45:05.643271	1	1101381002517	8400.00	101.38.1	03090000000000000
988	189	048	\N	2	1	2026-03-01 11:45:05.643272	1	1101381002518	8400.00	101.38.1	03090000000000000
1605	116	ДУ 2492	\N	2	1	2026-03-01 11:45:05.644001	1	\N	3770.00	21.38.1	\N
989	189	049	\N	2	1	2026-03-01 11:45:05.643273	1	1101381002519	8400.00	101.38.1	03090000000000000
990	189	050	\N	2	1	2026-03-01 11:45:05.643274	1	1101381002520	8400.00	101.38.1	03090000000000000
991	189	051	\N	2	1	2026-03-01 11:45:05.643276	1	1101381002521	8400.00	101.38.1	03090000000000000
992	189	052	\N	2	1	2026-03-01 11:45:05.643277	1	1101381002522	8400.00	101.38.1	03090000000000000
993	189	053	\N	2	1	2026-03-01 11:45:05.643278	1	1101381002523	8400.00	101.38.1	03090000000000000
994	189	097	\N	2	1	2026-03-01 11:45:05.643279	1	1101381002537	8400.00	101.38.1	03090000000000000
995	189	098	\N	2	1	2026-03-01 11:45:05.64328	1	1101381002538	8400.00	101.38.1	03090000000000000
996	189	099	\N	2	1	2026-03-01 11:45:05.643282	1	1101381002539	8400.00	101.38.1	03090000000000000
997	189	100	\N	2	1	2026-03-01 11:45:05.643283	1	1101381002540	8400.00	101.38.1	03090000000000000
998	189	101	\N	2	1	2026-03-01 11:45:05.643284	1	1101381002541	8400.00	101.38.1	03090000000000000
999	189	102	\N	2	1	2026-03-01 11:45:05.643285	1	1101381002542	8400.00	101.38.1	03090000000000000
1000	189	103	\N	2	1	2026-03-01 11:45:05.643286	1	1101381002543	8400.00	101.38.1	03090000000000000
1001	189	105	\N	2	1	2026-03-01 11:45:05.643287	1	1101381002545	8400.00	101.38.1	03090000000000000
1002	189	209	\N	2	1	2026-03-01 11:45:05.643289	1	1101381002574	8400.00	101.38.1	03090000000000000
1003	189	210	\N	2	1	2026-03-01 11:45:05.64329	1	1101381002575	8400.00	101.38.1	03090000000000000
1004	190	Инв.1101091001756	\N	2	1	2026-03-01 11:45:05.643291	1	1101091001756	12500.00	101.38.1	03090000000000000
1005	190	Инв.1101091001735	\N	2	1	2026-03-01 11:45:05.643292	1	1101091001735	12500.00	101.38.1	03090000000000000
1006	190	Инв.1101091001731	\N	2	1	2026-03-01 11:45:05.643293	1	1101091001731	12500.00	101.38.1	03090000000000000
1007	190	Инв.1101091001749	\N	2	1	2026-03-01 11:45:05.643295	1	1101091001749	12500.00	101.38.1	03090000000000000
1008	190	Инв.1101091001781	\N	2	1	2026-03-01 11:45:05.643296	1	1101091001781	12500.00	101.38.1	03090000000000000
1009	190	Инв.1101091001764	\N	2	1	2026-03-01 11:45:05.643298	1	1101091001764	12500.00	101.38.1	03090000000000000
1010	190	Инв.1101091001745	\N	2	1	2026-03-01 11:45:05.643299	1	1101091001745	12500.00	101.38.1	03090000000000000
1011	190	Инв.1101091001774	\N	2	1	2026-03-01 11:45:05.643301	1	1101091001774	12500.00	101.38.1	03090000000000000
1012	190	Инв.1101091001748	\N	2	1	2026-03-01 11:45:05.643302	1	1101091001748	12500.00	101.38.1	03090000000000000
1013	190	Инв.1101091001773	\N	2	1	2026-03-01 11:45:05.643303	1	1101091001773	12500.00	101.38.1	03090000000000000
1014	190	Инв.1101091001738	\N	2	1	2026-03-01 11:45:05.643304	1	1101091001738	12500.00	101.38.1	03090000000000000
1015	190	Инв.1101091001772	\N	2	1	2026-03-01 11:45:05.643305	1	1101091001772	12500.00	101.38.1	03090000000000000
1016	190	Инв.1101091001777	\N	2	1	2026-03-01 11:45:05.643306	1	1101091001777	12500.00	101.38.1	03090000000000000
1017	190	Инв.1101091001760	\N	2	1	2026-03-01 11:45:05.643308	1	1101091001760	12500.00	101.38.1	03090000000000000
1018	190	Инв.1101091001782	\N	2	1	2026-03-01 11:45:05.643309	1	1101091001782	12500.00	101.38.1	03090000000000000
1019	190	Инв.1101091001739	\N	2	1	2026-03-01 11:45:05.64331	1	1101091001739	12500.00	101.38.1	03090000000000000
1020	190	Инв.1101091001767	\N	2	1	2026-03-01 11:45:05.643311	1	1101091001767	12500.00	101.38.1	03090000000000000
1021	190	Инв.1101091001734	\N	2	1	2026-03-01 11:45:05.643312	1	1101091001734	12500.00	101.38.1	03090000000000000
1022	190	Инв.1101091001787	\N	2	1	2026-03-01 11:45:05.643313	1	1101091001787	12500.00	101.38.1	03090000000000000
1023	190	Инв.1101091001743	\N	2	1	2026-03-01 11:45:05.643315	1	1101091001743	12500.00	101.38.1	03090000000000000
1024	190	Инв.1101091001789	\N	2	1	2026-03-01 11:45:05.643316	1	1101091001789	12500.00	101.38.1	03090000000000000
1025	190	Инв.1101091001733	\N	2	1	2026-03-01 11:45:05.643317	1	1101091001733	12500.00	101.38.1	03090000000000000
1026	190	Инв.1101091001784	\N	2	1	2026-03-01 11:45:05.643318	1	1101091001784	12500.00	101.38.1	03090000000000000
1027	190	Инв.1101091001753	\N	2	1	2026-03-01 11:45:05.643319	1	1101091001753	12500.00	101.38.1	03090000000000000
1028	190	Инв.1101091001786	\N	2	1	2026-03-01 11:45:05.64332	1	1101091001786	12500.00	101.38.1	03090000000000000
1029	190	Инв.1101091001776	\N	2	1	2026-03-01 11:45:05.643322	1	1101091001776	12500.00	101.38.1	03090000000000000
1030	190	Инв.1101091001736	\N	2	1	2026-03-01 11:45:05.643323	1	1101091001736	12500.00	101.38.1	03090000000000000
1031	190	Инв.1101091001732	\N	2	1	2026-03-01 11:45:05.643324	1	1101091001732	12500.00	101.38.1	03090000000000000
1032	190	Инв.1101091001754	\N	2	1	2026-03-01 11:45:05.643325	1	1101091001754	12500.00	101.38.1	03090000000000000
1033	190	Инв.1101091001761	\N	2	1	2026-03-01 11:45:05.643326	1	1101091001761	12500.00	101.38.1	03090000000000000
1034	190	Инв.1101091001766	\N	2	1	2026-03-01 11:45:05.643327	1	1101091001766	12500.00	101.38.1	03090000000000000
1035	190	Инв.1101091001750	\N	2	1	2026-03-01 11:45:05.643329	1	1101091001750	12500.00	101.38.1	03090000000000000
1036	190	Инв.1101091001740	\N	2	1	2026-03-01 11:45:05.64333	1	1101091001740	12500.00	101.38.1	03090000000000000
1037	190	Инв.1101091001737	\N	2	1	2026-03-01 11:45:05.643331	1	1101091001737	12500.00	101.38.1	03090000000000000
1038	190	Инв.1101091001790	\N	2	1	2026-03-01 11:45:05.643332	1	1101091001790	12500.00	101.38.1	03090000000000000
1039	190	Инв.1101091001778	\N	2	1	2026-03-01 11:45:05.643333	1	1101091001778	12500.00	101.38.1	03090000000000000
1040	190	Инв.1101091001780	\N	2	1	2026-03-01 11:45:05.643334	1	1101091001780	12500.00	101.38.1	03090000000000000
1041	190	Инв.1101091001752	\N	2	1	2026-03-01 11:45:05.643335	1	1101091001752	12500.00	101.38.1	03090000000000000
1042	190	Инв.1101091001770	\N	2	1	2026-03-01 11:45:05.643337	1	1101091001770	12500.00	101.38.1	03090000000000000
1043	190	Инв.1101091001747	\N	2	1	2026-03-01 11:45:05.643338	1	1101091001747	12500.00	101.38.1	03090000000000000
1044	190	Инв.1101091001783	\N	2	1	2026-03-01 11:45:05.643339	1	1101091001783	12500.00	101.38.1	03090000000000000
1045	190	Инв.1101091001741	\N	2	1	2026-03-01 11:45:05.64334	1	1101091001741	12500.00	101.38.1	03090000000000000
1046	190	Инв.1101091001765	\N	2	1	2026-03-01 11:45:05.643341	1	1101091001765	12500.00	101.38.1	03090000000000000
1047	190	Инв.1101091001785	\N	2	1	2026-03-01 11:45:05.643343	1	1101091001785	12500.00	101.38.1	03090000000000000
1048	190	Инв.1101091001775	\N	2	1	2026-03-01 11:45:05.643344	1	1101091001775	12500.00	101.38.1	03090000000000000
1049	190	Инв.1101091001755	\N	2	1	2026-03-01 11:45:05.643345	1	1101091001755	12500.00	101.38.1	03090000000000000
1050	190	Инв.1101091001744	\N	2	1	2026-03-01 11:45:05.643346	1	1101091001744	12500.00	101.38.1	03090000000000000
1051	190	Инв.1101091001751	\N	2	1	2026-03-01 11:45:05.643347	1	1101091001751	12500.00	101.38.1	03090000000000000
1052	190	Инв.1101091001779	\N	2	1	2026-03-01 11:45:05.643349	1	1101091001779	12500.00	101.38.1	03090000000000000
1053	190	Инв.1101091001758	\N	2	1	2026-03-01 11:45:05.64335	1	1101091001758	12500.00	101.38.1	03090000000000000
1054	190	Инв.1101091001759	\N	2	1	2026-03-01 11:45:05.643351	1	1101091001759	12500.00	101.38.1	03090000000000000
1055	190	Инв.1101091001771	\N	2	1	2026-03-01 11:45:05.643352	1	1101091001771	12500.00	101.38.1	03090000000000000
1056	190	Инв.1101091001762	\N	2	1	2026-03-01 11:45:05.643353	1	1101091001762	12500.00	101.38.1	03090000000000000
1057	190	Инв.1101091001788	\N	2	1	2026-03-01 11:45:05.643354	1	1101091001788	12500.00	101.38.1	03090000000000000
1058	190	Инв.1101091001757	\N	2	1	2026-03-01 11:45:05.643356	1	1101091001757	12500.00	101.38.1	03090000000000000
1059	190	Инв.1101091001742	\N	2	1	2026-03-01 11:45:05.643357	1	1101091001742	12500.00	101.38.1	03090000000000000
1060	190	Инв.1101091001763	\N	2	1	2026-03-01 11:45:05.643358	1	1101091001763	12500.00	101.38.1	03090000000000000
1061	190	Инв.1101091001746	\N	2	1	2026-03-01 11:45:05.643359	1	1101091001746	12500.00	101.38.1	03090000000000000
1062	191	Инв.1101091001799	\N	2	1	2026-03-01 11:45:05.64336	1	1101091001799	12500.00	101.38.1	03090000000000000
1063	191	Инв.1101091001794	\N	2	1	2026-03-01 11:45:05.643361	1	1101091001794	12500.00	101.38.1	03090000000000000
1064	191	Инв.1101091001795	\N	2	1	2026-03-01 11:45:05.643362	1	1101091001795	12500.00	101.38.1	03090000000000000
1065	191	Инв.1101091001791	\N	2	1	2026-03-01 11:45:05.643364	1	1101091001791	12500.00	101.38.1	03090000000000000
1066	191	Инв.1101091001801	\N	2	1	2026-03-01 11:45:05.643365	1	1101091001801	12500.00	101.38.1	03090000000000000
1067	191	Инв.1101091001793	\N	2	1	2026-03-01 11:45:05.643366	1	1101091001793	12500.00	101.38.1	03090000000000000
1068	191	Инв.1101091001805	\N	2	1	2026-03-01 11:45:05.643367	1	1101091001805	12500.00	101.38.1	03090000000000000
1069	191	Инв.1101091001809	\N	2	1	2026-03-01 11:45:05.643368	1	1101091001809	12500.00	101.38.1	03090000000000000
1070	191	Инв.1101091001796	\N	2	1	2026-03-01 11:45:05.64337	1	1101091001796	12500.00	101.38.1	03090000000000000
1071	191	Инв.1101091001804	\N	2	1	2026-03-01 11:45:05.643371	1	1101091001804	12500.00	101.38.1	03090000000000000
1072	191	Инв.1101091001798	\N	2	1	2026-03-01 11:45:05.643372	1	1101091001798	12500.00	101.38.1	03090000000000000
1073	191	Инв.1101091001797	\N	2	1	2026-03-01 11:45:05.643373	1	1101091001797	12500.00	101.38.1	03090000000000000
1074	191	Инв.1101091001806	\N	2	1	2026-03-01 11:45:05.643374	1	1101091001806	12500.00	101.38.1	03090000000000000
1075	191	Инв.1101091001800	\N	2	1	2026-03-01 11:45:05.643375	1	1101091001800	12500.00	101.38.1	03090000000000000
1076	191	Инв.1101091001808	\N	2	1	2026-03-01 11:45:05.643376	1	1101091001808	12500.00	101.38.1	03090000000000000
1077	191	Инв.1101091001807	\N	2	1	2026-03-01 11:45:05.643378	1	1101091001807	12500.00	101.38.1	03090000000000000
1078	191	Инв.1101091001792	\N	2	1	2026-03-01 11:45:05.643379	1	1101091001792	12500.00	101.38.1	03090000000000000
1079	191	Инв.1101091001802	\N	2	1	2026-03-01 11:45:05.64338	1	1101091001802	12500.00	101.38.1	03090000000000000
1080	191	Инв.1101091001803	\N	2	1	2026-03-01 11:45:05.643381	1	1101091001803	12500.00	101.38.1	03090000000000000
1081	192	Инв.1101091001963	\N	2	1	2026-03-01 11:45:05.643382	1	1101091001963	7240.00	101.38.1	03090000000000000
1082	192	Инв.1101091002027	\N	2	1	2026-03-01 11:45:05.643383	1	1101091002027	7240.00	101.38.1	03090000000000000
1083	192	Инв.1101091002054	\N	2	1	2026-03-01 11:45:05.643384	1	1101091002054	7240.00	101.38.1	03090000000000000
1084	192	Инв.1101091002008	\N	2	1	2026-03-01 11:45:05.643386	1	1101091002008	7240.00	101.38.1	03090000000000000
1085	192	Инв.1101091001975	\N	2	1	2026-03-01 11:45:05.643387	1	1101091001975	7240.00	101.38.1	03090000000000000
1086	192	Инв.1101091001944	\N	2	1	2026-03-01 11:45:05.643388	1	1101091001944	7240.00	101.38.1	03090000000000000
1087	192	Инв.1101091001973	\N	2	1	2026-03-01 11:45:05.643389	1	1101091001973	7240.00	101.38.1	03090000000000000
1088	192	Инв.1101091001969	\N	2	1	2026-03-01 11:45:05.64339	1	1101091001969	7240.00	101.38.1	03090000000000000
1089	192	Инв.1101091001947	\N	2	1	2026-03-01 11:45:05.643391	1	1101091001947	7240.00	101.38.1	03090000000000000
1090	192	Инв.1101091002041	\N	2	1	2026-03-01 11:45:05.643393	1	1101091002041	7240.00	101.38.1	03090000000000000
1091	192	Инв.1101091001953	\N	2	1	2026-03-01 11:45:05.643394	1	1101091001953	7240.00	101.38.1	03090000000000000
1092	192	Инв.1101091001984	\N	2	1	2026-03-01 11:45:05.643395	1	1101091001984	7240.00	101.38.1	03090000000000000
1093	192	Инв.1101091001912	\N	2	1	2026-03-01 11:45:05.643396	1	1101091001912	7240.00	101.38.1	03090000000000000
1094	192	Инв.1101091002007	\N	2	1	2026-03-01 11:45:05.643397	1	1101091002007	7240.00	101.38.1	03090000000000000
1095	192	Инв.1101091001979	\N	2	1	2026-03-01 11:45:05.643398	1	1101091001979	7240.00	101.38.1	03090000000000000
1096	192	Инв.1101091001904	\N	2	1	2026-03-01 11:45:05.6434	1	1101091001904	7240.00	101.38.1	03090000000000000
1097	192	Инв.1101091001981	\N	2	1	2026-03-01 11:45:05.643401	1	1101091001981	7240.00	101.38.1	03090000000000000
1098	192	Инв.1101091002048	\N	2	1	2026-03-01 11:45:05.643402	1	1101091002048	7240.00	101.38.1	03090000000000000
1099	192	Инв.1101091001917	\N	2	1	2026-03-01 11:45:05.643403	1	1101091001917	7240.00	101.38.1	03090000000000000
1100	192	Инв.1101091001959	\N	2	1	2026-03-01 11:45:05.643404	1	1101091001959	7240.00	101.38.1	03090000000000000
1101	192	Инв.1101091001906	\N	2	1	2026-03-01 11:45:05.643405	1	1101091001906	7240.00	101.38.1	03090000000000000
1102	192	Инв.1101091002053	\N	2	1	2026-03-01 11:45:05.643407	1	1101091002053	7240.00	101.38.1	03090000000000000
1103	192	Инв.1101091001996	\N	2	1	2026-03-01 11:45:05.643408	1	1101091001996	7240.00	101.38.1	03090000000000000
1104	192	Инв.1101091002030	\N	2	1	2026-03-01 11:45:05.643409	1	1101091002030	7240.00	101.38.1	03090000000000000
1105	192	Инв.1101091002004	\N	2	1	2026-03-01 11:45:05.64341	1	1101091002004	7240.00	101.38.1	03090000000000000
1106	192	Инв.1101091002058	\N	2	1	2026-03-01 11:45:05.643411	1	1101091002058	7240.00	101.38.1	03090000000000000
1107	192	Инв.1101091002003	\N	2	1	2026-03-01 11:45:05.643412	1	1101091002003	7240.00	101.38.1	03090000000000000
1108	192	Инв.1101091001928	\N	2	1	2026-03-01 11:45:05.643413	1	1101091001928	7240.00	101.38.1	03090000000000000
1109	192	Инв.1101091001983	\N	2	1	2026-03-01 11:45:05.643415	1	1101091001983	7240.00	101.38.1	03090000000000000
1110	192	Инв.1101091001925	\N	2	1	2026-03-01 11:45:05.643416	1	1101091001925	7240.00	101.38.1	03090000000000000
1111	192	Инв.1101091001998	\N	2	1	2026-03-01 11:45:05.643417	1	1101091001998	7240.00	101.38.1	03090000000000000
1112	192	Инв.1101091001878	\N	2	1	2026-03-01 11:45:05.643418	1	1101091001878	7240.00	101.38.1	03090000000000000
1113	192	Инв.1101091001956	\N	2	1	2026-03-01 11:45:05.643419	1	1101091001956	7240.00	101.38.1	03090000000000000
1114	192	Инв.1101091001934	\N	2	1	2026-03-01 11:45:05.64342	1	1101091001934	7240.00	101.38.1	03090000000000000
1115	192	Инв.1101091002043	\N	2	1	2026-03-01 11:45:05.643421	1	1101091002043	7240.00	101.38.1	03090000000000000
1116	192	Инв.1101091001960	\N	2	1	2026-03-01 11:45:05.643423	1	1101091001960	7240.00	101.38.1	03090000000000000
1117	192	Инв.1101091002038	\N	2	1	2026-03-01 11:45:05.643424	1	1101091002038	7240.00	101.38.1	03090000000000000
1118	192	Инв.1101091002037	\N	2	1	2026-03-01 11:45:05.643425	1	1101091002037	7240.00	101.38.1	03090000000000000
1119	192	Инв.1101091001891	\N	2	1	2026-03-01 11:45:05.643426	1	1101091001891	7240.00	101.38.1	03090000000000000
1120	192	Инв.1101091001972	\N	2	1	2026-03-01 11:45:05.643427	1	1101091001972	7240.00	101.38.1	03090000000000000
1121	192	Инв.1101091001910	\N	2	1	2026-03-01 11:45:05.643428	1	1101091001910	7240.00	101.38.1	03090000000000000
1122	192	Инв.1101091001938	\N	2	1	2026-03-01 11:45:05.64343	1	1101091001938	7240.00	101.38.1	03090000000000000
1123	192	Инв.1101091001994	\N	2	1	2026-03-01 11:45:05.643431	1	1101091001994	7240.00	101.38.1	03090000000000000
1124	192	Инв.1101091001971	\N	2	1	2026-03-01 11:45:05.643432	1	1101091001971	7240.00	101.38.1	03090000000000000
1125	192	Инв.1101091001940	\N	2	1	2026-03-01 11:45:05.643433	1	1101091001940	7240.00	101.38.1	03090000000000000
1126	192	Инв.1101091002050	\N	2	1	2026-03-01 11:45:05.643434	1	1101091002050	7240.00	101.38.1	03090000000000000
1127	192	Инв.1101091001993	\N	2	1	2026-03-01 11:45:05.643435	1	1101091001993	7240.00	101.38.1	03090000000000000
1128	192	Инв.1101091002031	\N	2	1	2026-03-01 11:45:05.643437	1	1101091002031	7240.00	101.38.1	03090000000000000
1129	192	Инв.1101091002036	\N	2	1	2026-03-01 11:45:05.643438	1	1101091002036	7240.00	101.38.1	03090000000000000
1130	192	Инв.1101091001900	\N	2	1	2026-03-01 11:45:05.643439	1	1101091001900	7240.00	101.38.1	03090000000000000
1131	192	Инв.1101091001935	\N	2	1	2026-03-01 11:45:05.64344	1	1101091001935	7240.00	101.38.1	03090000000000000
1132	192	Инв.1101091001978	\N	2	1	2026-03-01 11:45:05.643441	1	1101091001978	7240.00	101.38.1	03090000000000000
1133	192	Инв.1101091001902	\N	2	1	2026-03-01 11:45:05.643442	1	1101091001902	7240.00	101.38.1	03090000000000000
1134	192	Инв.1101091002000	\N	2	1	2026-03-01 11:45:05.643444	1	1101091002000	7240.00	101.38.1	03090000000000000
1135	192	Инв.1101091001895	\N	2	1	2026-03-01 11:45:05.643445	1	1101091001895	7240.00	101.38.1	03090000000000000
1136	192	Инв.1101091002051	\N	2	1	2026-03-01 11:45:05.643446	1	1101091002051	7240.00	101.38.1	03090000000000000
1137	192	Инв.1101091001930	\N	2	1	2026-03-01 11:45:05.643447	1	1101091001930	7240.00	101.38.1	03090000000000000
1138	192	Инв.1101091002022	\N	2	1	2026-03-01 11:45:05.643448	1	1101091002022	7240.00	101.38.1	03090000000000000
1139	192	Инв.1101091001952	\N	2	1	2026-03-01 11:45:05.64345	1	1101091001952	7240.00	101.38.1	03090000000000000
1140	192	Инв.1101091001915	\N	2	1	2026-03-01 11:45:05.643452	1	1101091001915	7240.00	101.38.1	03090000000000000
1141	192	Инв.1101091001933	\N	2	1	2026-03-01 11:45:05.643453	1	1101091001933	7240.00	101.38.1	03090000000000000
1142	192	Инв.1101091002056	\N	2	1	2026-03-01 11:45:05.643454	1	1101091002056	7240.00	101.38.1	03090000000000000
1143	192	Инв.1101091002021	\N	2	1	2026-03-01 11:45:05.643455	1	1101091002021	7240.00	101.38.1	03090000000000000
1144	192	Инв.1101091001899	\N	2	1	2026-03-01 11:45:05.643456	1	1101091001899	7240.00	101.38.1	03090000000000000
1145	192	Инв.1101091001931	\N	2	1	2026-03-01 11:45:05.643457	1	1101091001931	7240.00	101.38.1	03090000000000000
1146	192	Инв.1101091001943	\N	2	1	2026-03-01 11:45:05.643459	1	1101091001943	7240.00	101.38.1	03090000000000000
1147	192	Инв.1101091001958	\N	2	1	2026-03-01 11:45:05.64346	1	1101091001958	7240.00	101.38.1	03090000000000000
1148	192	Инв.1101091001948	\N	2	1	2026-03-01 11:45:05.643461	1	1101091001948	7240.00	101.38.1	03090000000000000
1149	192	Инв.1101091002049	\N	2	1	2026-03-01 11:45:05.643462	1	1101091002049	7240.00	101.38.1	03090000000000000
1150	192	Инв.1101091001957	\N	2	1	2026-03-01 11:45:05.643464	1	1101091001957	7240.00	101.38.1	03090000000000000
1151	192	Инв.1101091001897	\N	2	1	2026-03-01 11:45:05.643465	1	1101091001897	7240.00	101.38.1	03090000000000000
1152	192	Инв.1101091001905	\N	2	1	2026-03-01 11:45:05.643466	1	1101091001905	7240.00	101.38.1	03090000000000000
1153	192	Инв.1101091001908	\N	2	1	2026-03-01 11:45:05.643467	1	1101091001908	7240.00	101.38.1	03090000000000000
1154	192	Инв.1101091001950	\N	2	1	2026-03-01 11:45:05.643468	1	1101091001950	7240.00	101.38.1	03090000000000000
1155	192	Инв.1101091001916	\N	2	1	2026-03-01 11:45:05.64347	1	1101091001916	7240.00	101.38.1	03090000000000000
1156	192	Инв.1101091001987	\N	2	1	2026-03-01 11:45:05.643471	1	1101091001987	7240.00	101.38.1	03090000000000000
1157	192	Инв.1101091002015	\N	2	1	2026-03-01 11:45:05.643472	1	1101091002015	7240.00	101.38.1	03090000000000000
1158	192	Инв.1101091001921	\N	2	1	2026-03-01 11:45:05.643473	1	1101091001921	7240.00	101.38.1	03090000000000000
1159	192	Инв.1101091002019	\N	2	1	2026-03-01 11:45:05.643474	1	1101091002019	7240.00	101.38.1	03090000000000000
1160	192	Инв.1101091001964	\N	2	1	2026-03-01 11:45:05.643476	1	1101091001964	7240.00	101.38.1	03090000000000000
1161	192	Инв.1101091002045	\N	2	1	2026-03-01 11:45:05.643477	1	1101091002045	7240.00	101.38.1	03090000000000000
1162	192	Инв.1101091002006	\N	2	1	2026-03-01 11:45:05.643478	1	1101091002006	7240.00	101.38.1	03090000000000000
1163	192	Инв.1101091002016	\N	2	1	2026-03-01 11:45:05.643479	1	1101091002016	7240.00	101.38.1	03090000000000000
1164	192	Инв.1101091001990	\N	2	1	2026-03-01 11:45:05.64348	1	1101091001990	7240.00	101.38.1	03090000000000000
1165	192	Инв.1101091001813	\N	2	1	2026-03-01 11:45:05.643481	1	1101091001813	7240.00	101.38.1	03090000000000000
1166	192	Инв.1101091001894	\N	2	1	2026-03-01 11:45:05.643483	1	1101091001894	7240.00	101.38.1	03090000000000000
1167	192	Инв.1101091001965	\N	2	1	2026-03-01 11:45:05.643484	1	1101091001965	7240.00	101.38.1	03090000000000000
1168	192	Инв.1101091001985	\N	2	1	2026-03-01 11:45:05.643485	1	1101091001985	7240.00	101.38.1	03090000000000000
1169	192	Инв.1101091001991	\N	2	1	2026-03-01 11:45:05.643486	1	1101091001991	7240.00	101.38.1	03090000000000000
1170	192	Инв.1101091001967	\N	2	1	2026-03-01 11:45:05.643487	1	1101091001967	7240.00	101.38.1	03090000000000000
1171	192	Инв.1101091001920	\N	2	1	2026-03-01 11:45:05.643489	1	1101091001920	7240.00	101.38.1	03090000000000000
1172	192	Инв.1101091001939	\N	2	1	2026-03-01 11:45:05.64349	1	1101091001939	7240.00	101.38.1	03090000000000000
1173	192	Инв.1101091001810	\N	2	1	2026-03-01 11:45:05.643491	1	1101091001810	7240.00	101.38.1	03090000000000000
1174	192	Инв.1101091001877	\N	2	1	2026-03-01 11:45:05.643492	1	1101091001877	7240.00	101.38.1	03090000000000000
1175	192	Инв.1101091002012	\N	2	1	2026-03-01 11:45:05.643494	1	1101091002012	7240.00	101.38.1	03090000000000000
1176	192	Инв.1101091002017	\N	2	1	2026-03-01 11:45:05.643495	1	1101091002017	7240.00	101.38.1	03090000000000000
1177	192	Инв.1101091002052	\N	2	1	2026-03-01 11:45:05.643496	1	1101091002052	7240.00	101.38.1	03090000000000000
1178	192	Инв.1101091001903	\N	2	1	2026-03-01 11:45:05.643497	1	1101091001903	7240.00	101.38.1	03090000000000000
1179	192	Инв.1101091001997	\N	2	1	2026-03-01 11:45:05.643498	1	1101091001997	7240.00	101.38.1	03090000000000000
1180	192	Инв.1101091002057	\N	2	1	2026-03-01 11:45:05.643499	1	1101091002057	7240.00	101.38.1	03090000000000000
1181	192	Инв.1101091001961	\N	2	1	2026-03-01 11:45:05.643501	1	1101091001961	7240.00	101.38.1	03090000000000000
1182	192	Инв.1101091001892	\N	2	1	2026-03-01 11:45:05.643502	1	1101091001892	7240.00	101.38.1	03090000000000000
1183	192	Инв.1101091002023	\N	2	1	2026-03-01 11:45:05.643503	1	1101091002023	7240.00	101.38.1	03090000000000000
1184	192	Инв.1101091001811	\N	2	1	2026-03-01 11:45:05.643504	1	1101091001811	7240.00	101.38.1	03090000000000000
1185	192	Инв.1101091001988	\N	2	1	2026-03-01 11:45:05.643505	1	1101091001988	7240.00	101.38.1	03090000000000000
1186	192	Инв.1101091001913	\N	2	1	2026-03-01 11:45:05.643507	1	1101091001913	7240.00	101.38.1	03090000000000000
1187	192	Инв.1101091001989	\N	2	1	2026-03-01 11:45:05.643508	1	1101091001989	7240.00	101.38.1	03090000000000000
1188	192	Инв.1101091002020	\N	2	1	2026-03-01 11:45:05.643509	1	1101091002020	7240.00	101.38.1	03090000000000000
1189	192	Инв.1101091002042	\N	2	1	2026-03-01 11:45:05.64351	1	1101091002042	7240.00	101.38.1	03090000000000000
1190	192	Инв.1101091001955	\N	2	1	2026-03-01 11:45:05.643511	1	1101091001955	7240.00	101.38.1	03090000000000000
1191	192	Инв.1101091001922	\N	2	1	2026-03-01 11:45:05.643512	1	1101091001922	7240.00	101.38.1	03090000000000000
1192	192	Инв.1101091002055	\N	2	1	2026-03-01 11:45:05.643514	1	1101091002055	7240.00	101.38.1	03090000000000000
1193	192	Инв.1101091001976	\N	2	1	2026-03-01 11:45:05.643515	1	1101091001976	7240.00	101.38.1	03090000000000000
1194	192	Инв.1101091001999	\N	2	1	2026-03-01 11:45:05.643516	1	1101091001999	7240.00	101.38.1	03090000000000000
1195	192	Инв.1101091001918	\N	2	1	2026-03-01 11:45:05.643517	1	1101091001918	7240.00	101.38.1	03090000000000000
1196	192	Инв.1101091001932	\N	2	1	2026-03-01 11:45:05.643518	1	1101091001932	7240.00	101.38.1	03090000000000000
1197	192	Инв.1101091002044	\N	2	1	2026-03-01 11:45:05.643519	1	1101091002044	7240.00	101.38.1	03090000000000000
1198	192	Инв.1101091001914	\N	2	1	2026-03-01 11:45:05.64352	1	1101091001914	7240.00	101.38.1	03090000000000000
1199	192	Инв.1101091001968	\N	2	1	2026-03-01 11:45:05.643522	1	1101091001968	7240.00	101.38.1	03090000000000000
1200	192	Инв.1101091001970	\N	2	1	2026-03-01 11:45:05.643523	1	1101091001970	7240.00	101.38.1	03090000000000000
1201	192	Инв.1101091001907	\N	2	1	2026-03-01 11:45:05.643524	1	1101091001907	7240.00	101.38.1	03090000000000000
1202	192	Инв.1101091002025	\N	2	1	2026-03-01 11:45:05.643525	1	1101091002025	7240.00	101.38.1	03090000000000000
1203	192	Инв.1101091001937	\N	2	1	2026-03-01 11:45:05.643526	1	1101091001937	7240.00	101.38.1	03090000000000000
1204	192	Инв.1101091002039	\N	2	1	2026-03-01 11:45:05.643528	1	1101091002039	7240.00	101.38.1	03090000000000000
1205	192	Инв.1101091001986	\N	2	1	2026-03-01 11:45:05.643529	1	1101091001986	7240.00	101.38.1	03090000000000000
1206	192	Инв.1101091001946	\N	2	1	2026-03-01 11:45:05.64353	1	1101091001946	7240.00	101.38.1	03090000000000000
1207	192	Инв.1101091001962	\N	2	1	2026-03-01 11:45:05.643531	1	1101091001962	7240.00	101.38.1	03090000000000000
1208	192	Инв.1101091002001	\N	2	1	2026-03-01 11:45:05.643532	1	1101091002001	7240.00	101.38.1	03090000000000000
1209	192	Инв.1101091002040	\N	2	1	2026-03-01 11:45:05.643534	1	1101091002040	7240.00	101.38.1	03090000000000000
1210	192	Инв.1101091002013	\N	2	1	2026-03-01 11:45:05.643535	1	1101091002013	7240.00	101.38.1	03090000000000000
1211	192	Инв.1101091001949	\N	2	1	2026-03-01 11:45:05.643536	1	1101091001949	7240.00	101.38.1	03090000000000000
1212	192	Инв.1101091001898	\N	2	1	2026-03-01 11:45:05.643537	1	1101091001898	7240.00	101.38.1	03090000000000000
1213	192	Инв.1101091002024	\N	2	1	2026-03-01 11:45:05.643538	1	1101091002024	7240.00	101.38.1	03090000000000000
1214	192	Инв.1101091001888	\N	2	1	2026-03-01 11:45:05.643539	1	1101091001888	7240.00	101.38.1	03090000000000000
1215	192	Инв.1101091001951	\N	2	1	2026-03-01 11:45:05.64354	1	1101091001951	7240.00	101.38.1	03090000000000000
1216	192	Инв.1101091002002	\N	2	1	2026-03-01 11:45:05.643542	1	1101091002002	7240.00	101.38.1	03090000000000000
1217	192	Инв.1101091001942	\N	2	1	2026-03-01 11:45:05.643543	1	1101091001942	7240.00	101.38.1	03090000000000000
1218	192	Инв.1101091002032	\N	2	1	2026-03-01 11:45:05.643544	1	1101091002032	7240.00	101.38.1	03090000000000000
1219	192	Инв.1101091002046	\N	2	1	2026-03-01 11:45:05.643545	1	1101091002046	7240.00	101.38.1	03090000000000000
1220	192	Инв.1101091001927	\N	2	1	2026-03-01 11:45:05.643547	1	1101091001927	7240.00	101.38.1	03090000000000000
1221	192	Инв.1101091001966	\N	2	1	2026-03-01 11:45:05.643548	1	1101091001966	7240.00	101.38.1	03090000000000000
1222	192	Инв.1101091002035	\N	2	1	2026-03-01 11:45:05.643549	1	1101091002035	7240.00	101.38.1	03090000000000000
1223	192	Инв.1101091001909	\N	2	1	2026-03-01 11:45:05.64355	1	1101091001909	7240.00	101.38.1	03090000000000000
1224	192	Инв.1101091002033	\N	2	1	2026-03-01 11:45:05.643551	1	1101091002033	7240.00	101.38.1	03090000000000000
1225	192	Инв.1101091002028	\N	2	1	2026-03-01 11:45:05.643553	1	1101091002028	7240.00	101.38.1	03090000000000000
1226	192	Инв.1101091002029	\N	2	1	2026-03-01 11:45:05.643554	1	1101091002029	7240.00	101.38.1	03090000000000000
1227	192	Инв.1101091001936	\N	2	1	2026-03-01 11:45:05.643555	1	1101091001936	7240.00	101.38.1	03090000000000000
1228	192	Инв.1101091001974	\N	2	1	2026-03-01 11:45:05.643556	1	1101091001974	7240.00	101.38.1	03090000000000000
1229	192	Инв.1101091002047	\N	2	1	2026-03-01 11:45:05.643557	1	1101091002047	7240.00	101.38.1	03090000000000000
1230	192	Инв.1101091001995	\N	2	1	2026-03-01 11:45:05.643558	1	1101091001995	7240.00	101.38.1	03090000000000000
1231	192	Инв.1101091001919	\N	2	1	2026-03-01 11:45:05.64356	1	1101091001919	7240.00	101.38.1	03090000000000000
1232	192	Инв.1101091001893	\N	2	1	2026-03-01 11:45:05.643561	1	1101091001893	7240.00	101.38.1	03090000000000000
1233	192	Инв.1101091001992	\N	2	1	2026-03-01 11:45:05.643562	1	1101091001992	7240.00	101.38.1	03090000000000000
1234	192	Инв.1101091002011	\N	2	1	2026-03-01 11:45:05.643563	1	1101091002011	7240.00	101.38.1	03090000000000000
1235	192	Инв.1101091001945	\N	2	1	2026-03-01 11:45:05.643564	1	1101091001945	7240.00	101.38.1	03090000000000000
1236	192	Инв.1101091001901	\N	2	1	2026-03-01 11:45:05.643566	1	1101091001901	7240.00	101.38.1	03090000000000000
1237	192	Инв.1101091001941	\N	2	1	2026-03-01 11:45:05.643567	1	1101091001941	7240.00	101.38.1	03090000000000000
1238	192	Инв.1101091001896	\N	2	1	2026-03-01 11:45:05.643568	1	1101091001896	7240.00	101.38.1	03090000000000000
1239	192	Инв.1101091001980	\N	2	1	2026-03-01 11:45:05.643569	1	1101091001980	7240.00	101.38.1	03090000000000000
1240	192	Инв.1101091001911	\N	2	1	2026-03-01 11:45:05.64357	1	1101091001911	7240.00	101.38.1	03090000000000000
1241	192	Инв.1101091002005	\N	2	1	2026-03-01 11:45:05.643572	1	1101091002005	7240.00	101.38.1	03090000000000000
1242	192	Инв.1101091001954	\N	2	1	2026-03-01 11:45:05.643573	1	1101091001954	7240.00	101.38.1	03090000000000000
1243	192	Инв.1101091001923	\N	2	1	2026-03-01 11:45:05.643574	1	1101091001923	7240.00	101.38.1	03090000000000000
1244	192	Инв.1101091001929	\N	2	1	2026-03-01 11:45:05.643575	1	1101091001929	7240.00	101.38.1	03090000000000000
1245	192	Инв.1101091001977	\N	2	1	2026-03-01 11:45:05.643576	1	1101091001977	7240.00	101.38.1	03090000000000000
1246	192	Инв.1101091002009	\N	2	1	2026-03-01 11:45:05.643578	1	1101091002009	7240.00	101.38.1	03090000000000000
1247	192	Инв.1101091001812	\N	2	1	2026-03-01 11:45:05.643579	1	1101091001812	7240.00	101.38.1	03090000000000000
1248	192	Инв.1101091002026	\N	2	1	2026-03-01 11:45:05.64358	1	1101091002026	7240.00	101.38.1	03090000000000000
1249	192	Инв.1101091001924	\N	2	1	2026-03-01 11:45:05.643581	1	1101091001924	7240.00	101.38.1	03090000000000000
1250	192	Инв.1101091002010	\N	2	1	2026-03-01 11:45:05.643582	1	1101091002010	7240.00	101.38.1	03090000000000000
1251	192	Инв.1101091002034	\N	2	1	2026-03-01 11:45:05.643584	1	1101091002034	7240.00	101.38.1	03090000000000000
1252	192	Инв.1101091002014	\N	2	1	2026-03-01 11:45:05.643585	1	1101091002014	7240.00	101.38.1	03090000000000000
1253	192	Инв.1101091001982	\N	2	1	2026-03-01 11:45:05.643586	1	1101091001982	7240.00	101.38.1	03090000000000000
1254	192	Инв.1101091001926	\N	2	1	2026-03-01 11:45:05.643587	1	1101091001926	7240.00	101.38.1	03090000000000000
1255	192	Инв.1101091002018	\N	2	1	2026-03-01 11:45:05.643588	1	1101091002018	7240.00	101.38.1	03090000000000000
1256	193	Инв.1101091002206	\N	2	1	2026-03-01 11:45:05.643589	1	1101091002206	7240.00	101.38.1	03090000000000000
1257	193	Инв.1101091002099	\N	2	1	2026-03-01 11:45:05.643591	1	1101091002099	7240.00	101.38.1	03090000000000000
1258	193	Инв.1101091002202	\N	2	1	2026-03-01 11:45:05.643592	1	1101091002202	7240.00	101.38.1	03090000000000000
1259	193	Инв.1101091002177	\N	2	1	2026-03-01 11:45:05.643593	1	1101091002177	7240.00	101.38.1	03090000000000000
1260	193	Инв.1101091002166	\N	2	1	2026-03-01 11:45:05.643594	1	1101091002166	7240.00	101.38.1	03090000000000000
1261	193	Инв.1101091002154	\N	2	1	2026-03-01 11:45:05.643595	1	1101091002154	7240.00	101.38.1	03090000000000000
1262	193	Инв.1101091002079	\N	2	1	2026-03-01 11:45:05.643596	1	1101091002079	7240.00	101.38.1	03090000000000000
1263	193	Инв.1101091002127	\N	2	1	2026-03-01 11:45:05.643598	1	1101091002127	7240.00	101.38.1	03090000000000000
1264	193	Инв.1101091002204	\N	2	1	2026-03-01 11:45:05.643599	1	1101091002204	7240.00	101.38.1	03090000000000000
1265	193	Инв.1101091002102	\N	2	1	2026-03-01 11:45:05.6436	1	1101091002102	7240.00	101.38.1	03090000000000000
1266	193	Инв.1101091002132	\N	2	1	2026-03-01 11:45:05.643601	1	1101091002132	7240.00	101.38.1	03090000000000000
1267	193	Инв.1101091002139	\N	2	1	2026-03-01 11:45:05.643602	1	1101091002139	7240.00	101.38.1	03090000000000000
1268	193	Инв.1101091002201	\N	2	1	2026-03-01 11:45:05.643604	1	1101091002201	7240.00	101.38.1	03090000000000000
1269	193	Инв.1101091002074	\N	2	1	2026-03-01 11:45:05.643605	1	1101091002074	7240.00	101.38.1	03090000000000000
1270	193	Инв.1101091002187	\N	2	1	2026-03-01 11:45:05.643606	1	1101091002187	7240.00	101.38.1	03090000000000000
1271	193	Инв.1101091002155	\N	2	1	2026-03-01 11:45:05.643607	1	1101091002155	7240.00	101.38.1	03090000000000000
1272	193	Инв.1101091002157	\N	2	1	2026-03-01 11:45:05.643608	1	1101091002157	7240.00	101.38.1	03090000000000000
1273	193	Инв.1101091002093	\N	2	1	2026-03-01 11:45:05.64361	1	1101091002093	7240.00	101.38.1	03090000000000000
1274	193	Инв.1101091002183	\N	2	1	2026-03-01 11:45:05.643611	1	1101091002183	7240.00	101.38.1	03090000000000000
1275	193	Инв.1101091002176	\N	2	1	2026-03-01 11:45:05.643612	1	1101091002176	7240.00	101.38.1	03090000000000000
1276	193	Инв.1101091002076	\N	2	1	2026-03-01 11:45:05.643613	1	1101091002076	7240.00	101.38.1	03090000000000000
1277	193	Инв.1101091002081	\N	2	1	2026-03-01 11:45:05.643614	1	1101091002081	7240.00	101.38.1	03090000000000000
1278	193	Инв.1101091002109	\N	2	1	2026-03-01 11:45:05.643615	1	1101091002109	7240.00	101.38.1	03090000000000000
1279	193	Инв.1101091002125	\N	2	1	2026-03-01 11:45:05.643617	1	1101091002125	7240.00	101.38.1	03090000000000000
1280	193	Инв.1101091002108	\N	2	1	2026-03-01 11:45:05.643618	1	1101091002108	7240.00	101.38.1	03090000000000000
1281	193	Инв.1101091002164	\N	2	1	2026-03-01 11:45:05.64362	1	1101091002164	7240.00	101.38.1	03090000000000000
1282	193	Инв.1101091002113	\N	2	1	2026-03-01 11:45:05.643621	1	1101091002113	7240.00	101.38.1	03090000000000000
1283	193	Инв.1101091002126	\N	2	1	2026-03-01 11:45:05.643622	1	1101091002126	7240.00	101.38.1	03090000000000000
1284	193	Инв.1101091002152	\N	2	1	2026-03-01 11:45:05.643624	1	1101091002152	7240.00	101.38.1	03090000000000000
1285	193	Инв.1101091002077	\N	2	1	2026-03-01 11:45:05.643625	1	1101091002077	7240.00	101.38.1	03090000000000000
1286	193	Инв.1101091002119	\N	2	1	2026-03-01 11:45:05.643626	1	1101091002119	7240.00	101.38.1	03090000000000000
1287	193	Инв.1101091002137	\N	2	1	2026-03-01 11:45:05.643628	1	1101091002137	7240.00	101.38.1	03090000000000000
1288	193	Инв.1101091002160	\N	2	1	2026-03-01 11:45:05.643629	1	1101091002160	7240.00	101.38.1	03090000000000000
1289	193	Инв.1101091002083	\N	2	1	2026-03-01 11:45:05.64363	1	1101091002083	7240.00	101.38.1	03090000000000000
1290	193	Инв.1101091002086	\N	2	1	2026-03-01 11:45:05.643631	1	1101091002086	7240.00	101.38.1	03090000000000000
1291	193	Инв.1101091002089	\N	2	1	2026-03-01 11:45:05.643632	1	1101091002089	7240.00	101.38.1	03090000000000000
1292	193	Инв.1101091002130	\N	2	1	2026-03-01 11:45:05.643633	1	1101091002130	7240.00	101.38.1	03090000000000000
1293	193	Инв.1101091002118	\N	2	1	2026-03-01 11:45:05.643635	1	1101091002118	7240.00	101.38.1	03090000000000000
1294	193	Инв.1101091002162	\N	2	1	2026-03-01 11:45:05.643636	1	1101091002162	7240.00	101.38.1	03090000000000000
1295	193	Инв.1101091002090	\N	2	1	2026-03-01 11:45:05.643637	1	1101091002090	7240.00	101.38.1	03090000000000000
1296	193	Инв.1101091002186	\N	2	1	2026-03-01 11:45:05.643638	1	1101091002186	7240.00	101.38.1	03090000000000000
1297	193	Инв.1101091002060	\N	2	1	2026-03-01 11:45:05.643639	1	1101091002060	7240.00	101.38.1	03090000000000000
1298	193	Инв.1101091002100	\N	2	1	2026-03-01 11:45:05.64364	1	1101091002100	7240.00	101.38.1	03090000000000000
1299	193	Инв.1101091002101	\N	2	1	2026-03-01 11:45:05.643642	1	1101091002101	7240.00	101.38.1	03090000000000000
1300	193	Инв.1101091002188	\N	2	1	2026-03-01 11:45:05.643643	1	1101091002188	7240.00	101.38.1	03090000000000000
1301	193	Инв.1101091002071	\N	2	1	2026-03-01 11:45:05.643644	1	1101091002071	7240.00	101.38.1	03090000000000000
1302	193	Инв.1101091002122	\N	2	1	2026-03-01 11:45:05.643645	1	1101091002122	7240.00	101.38.1	03090000000000000
1303	193	Инв.1101091002121	\N	2	1	2026-03-01 11:45:05.643646	1	1101091002121	7240.00	101.38.1	03090000000000000
1304	193	Инв.1101091002150	\N	2	1	2026-03-01 11:45:05.643647	1	1101091002150	7240.00	101.38.1	03090000000000000
1305	193	Инв.1101091002199	\N	2	1	2026-03-01 11:45:05.643648	1	1101091002199	7240.00	101.38.1	03090000000000000
1306	193	Инв.1101091002134	\N	2	1	2026-03-01 11:45:05.64365	1	1101091002134	7240.00	101.38.1	03090000000000000
1307	193	Инв.1101091002181	\N	2	1	2026-03-01 11:45:05.643651	1	1101091002181	7240.00	101.38.1	03090000000000000
1308	193	Инв.1101091002097	\N	2	1	2026-03-01 11:45:05.643652	1	1101091002097	7240.00	101.38.1	03090000000000000
1309	193	Инв.1101091002165	\N	2	1	2026-03-01 11:45:05.643653	1	1101091002165	7240.00	101.38.1	03090000000000000
1310	193	Инв.1101091002196	\N	2	1	2026-03-01 11:45:05.643654	1	1101091002196	7240.00	101.38.1	03090000000000000
1311	193	Инв.1101091002104	\N	2	1	2026-03-01 11:45:05.643655	1	1101091002104	7240.00	101.38.1	03090000000000000
1312	193	Инв.1101091002072	\N	2	1	2026-03-01 11:45:05.643657	1	1101091002072	7240.00	101.38.1	03090000000000000
1313	193	Инв.1101091002175	\N	2	1	2026-03-01 11:45:05.643658	1	1101091002175	7240.00	101.38.1	03090000000000000
1314	193	Инв.1101091002128	\N	2	1	2026-03-01 11:45:05.643659	1	1101091002128	7240.00	101.38.1	03090000000000000
1315	193	Инв.1101091002065	\N	2	1	2026-03-01 11:45:05.64366	1	1101091002065	7240.00	101.38.1	03090000000000000
1316	193	Инв.1101091002158	\N	2	1	2026-03-01 11:45:05.643661	1	1101091002158	7240.00	101.38.1	03090000000000000
1317	193	Инв.1101091002069	\N	2	1	2026-03-01 11:45:05.643663	1	1101091002069	7240.00	101.38.1	03090000000000000
1318	193	Инв.1101091002080	\N	2	1	2026-03-01 11:45:05.643664	1	1101091002080	7240.00	101.38.1	03090000000000000
1319	193	Инв.1101091002138	\N	2	1	2026-03-01 11:45:05.643665	1	1101091002138	7240.00	101.38.1	03090000000000000
1320	193	Инв.1101091002120	\N	2	1	2026-03-01 11:45:05.643666	1	1101091002120	7240.00	101.38.1	03090000000000000
1321	193	Инв.1101091002171	\N	2	1	2026-03-01 11:45:05.643667	1	1101091002171	7240.00	101.38.1	03090000000000000
1322	193	Инв.1101091002105	\N	2	1	2026-03-01 11:45:05.643668	1	1101091002105	7240.00	101.38.1	03090000000000000
1323	193	Инв.1101091002068	\N	2	1	2026-03-01 11:45:05.64367	1	1101091002068	7240.00	101.38.1	03090000000000000
1324	193	Инв.1101091002172	\N	2	1	2026-03-01 11:45:05.643671	1	1101091002172	7240.00	101.38.1	03090000000000000
1325	193	Инв.1101091002191	\N	2	1	2026-03-01 11:45:05.643672	1	1101091002191	7240.00	101.38.1	03090000000000000
1326	193	Инв.1101091002194	\N	2	1	2026-03-01 11:45:05.643673	1	1101091002194	7240.00	101.38.1	03090000000000000
1327	193	Инв.1101091002180	\N	2	1	2026-03-01 11:45:05.643674	1	1101091002180	7240.00	101.38.1	03090000000000000
1328	193	Инв.1101091002161	\N	2	1	2026-03-01 11:45:05.643676	1	1101091002161	7240.00	101.38.1	03090000000000000
1329	193	Инв.1101091002107	\N	2	1	2026-03-01 11:45:05.643677	1	1101091002107	7240.00	101.38.1	03090000000000000
1330	193	Инв.1101091002073	\N	2	1	2026-03-01 11:45:05.643678	1	1101091002073	7240.00	101.38.1	03090000000000000
1331	193	Инв.1101091002085	\N	2	1	2026-03-01 11:45:05.643679	1	1101091002085	7240.00	101.38.1	03090000000000000
1332	193	Инв.1101091002195	\N	2	1	2026-03-01 11:45:05.64368	1	1101091002195	7240.00	101.38.1	03090000000000000
1333	193	Инв.1101091002147	\N	2	1	2026-03-01 11:45:05.643681	1	1101091002147	7240.00	101.38.1	03090000000000000
1334	193	Инв.1101091002103	\N	2	1	2026-03-01 11:45:05.643683	1	1101091002103	7240.00	101.38.1	03090000000000000
1335	193	Инв.1101091002075	\N	2	1	2026-03-01 11:45:05.643684	1	1101091002075	7240.00	101.38.1	03090000000000000
1336	193	Инв.1101091002153	\N	2	1	2026-03-01 11:45:05.643685	1	1101091002153	7240.00	101.38.1	03090000000000000
1337	193	Инв.1101091002131	\N	2	1	2026-03-01 11:45:05.643686	1	1101091002131	7240.00	101.38.1	03090000000000000
1338	193	Инв.1101091002095	\N	2	1	2026-03-01 11:45:05.643687	1	1101091002095	7240.00	101.38.1	03090000000000000
1339	193	Инв.1101091002098	\N	2	1	2026-03-01 11:45:05.643688	1	1101091002098	7240.00	101.38.1	03090000000000000
1340	193	Инв.1101091002078	\N	2	1	2026-03-01 11:45:05.64369	1	1101091002078	7240.00	101.38.1	03090000000000000
1341	193	Инв.1101091002197	\N	2	1	2026-03-01 11:45:05.643691	1	1101091002197	7240.00	101.38.1	03090000000000000
1342	193	Инв.1101091002129	\N	2	1	2026-03-01 11:45:05.643692	1	1101091002129	7240.00	101.38.1	03090000000000000
1343	193	Инв.1101091002111	\N	2	1	2026-03-01 11:45:05.643693	1	1101091002111	7240.00	101.38.1	03090000000000000
1344	193	Инв.1101091002193	\N	2	1	2026-03-01 11:45:05.643694	1	1101091002193	7240.00	101.38.1	03090000000000000
1345	193	Инв.1101091002145	\N	2	1	2026-03-01 11:45:05.643695	1	1101091002145	7240.00	101.38.1	03090000000000000
1346	193	Инв.1101091002140	\N	2	1	2026-03-01 11:45:05.643697	1	1101091002140	7240.00	101.38.1	03090000000000000
1347	193	Инв.1101091002061	\N	2	1	2026-03-01 11:45:05.643698	1	1101091002061	7240.00	101.38.1	03090000000000000
1348	193	Инв.1101091002096	\N	2	1	2026-03-01 11:45:05.643699	1	1101091002096	7240.00	101.38.1	03090000000000000
1349	193	Инв.1101091002088	\N	2	1	2026-03-01 11:45:05.6437	1	1101091002088	7240.00	101.38.1	03090000000000000
1350	193	Инв.1101091002192	\N	2	1	2026-03-01 11:45:05.643702	1	1101091002192	7240.00	101.38.1	03090000000000000
1351	193	Инв.1101091002190	\N	2	1	2026-03-01 11:45:05.643703	1	1101091002190	7240.00	101.38.1	03090000000000000
1352	193	Инв.1101091002066	\N	2	1	2026-03-01 11:45:05.643704	1	1101091002066	7240.00	101.38.1	03090000000000000
1353	193	Инв.1101091002142	\N	2	1	2026-03-01 11:45:05.643705	1	1101091002142	7240.00	101.38.1	03090000000000000
1354	193	Инв.1101091002116	\N	2	1	2026-03-01 11:45:05.643706	1	1101091002116	7240.00	101.38.1	03090000000000000
1355	193	Инв.1101091002063	\N	2	1	2026-03-01 11:45:05.643707	1	1101091002063	7240.00	101.38.1	03090000000000000
1356	193	Инв.1101091002110	\N	2	1	2026-03-01 11:45:05.643709	1	1101091002110	7240.00	101.38.1	03090000000000000
1357	193	Инв.1101091002200	\N	2	1	2026-03-01 11:45:05.64371	1	1101091002200	7240.00	101.38.1	03090000000000000
1358	193	Инв.1101091002091	\N	2	1	2026-03-01 11:45:05.643711	1	1101091002091	7240.00	101.38.1	03090000000000000
1359	193	Инв.1101091002087	\N	2	1	2026-03-01 11:45:05.643712	1	1101091002087	7240.00	101.38.1	03090000000000000
1360	193	Инв.1101091002205	\N	2	1	2026-03-01 11:45:05.643713	1	1101091002205	7240.00	101.38.1	03090000000000000
1361	193	Инв.1101091002144	\N	2	1	2026-03-01 11:45:05.643714	1	1101091002144	7240.00	101.38.1	03090000000000000
1362	193	Инв.1101091002136	\N	2	1	2026-03-01 11:45:05.643716	1	1101091002136	7240.00	101.38.1	03090000000000000
1363	193	Инв.1101091002189	\N	2	1	2026-03-01 11:45:05.643717	1	1101091002189	7240.00	101.38.1	03090000000000000
1364	193	Инв.1101091002159	\N	2	1	2026-03-01 11:45:05.643718	1	1101091002159	7240.00	101.38.1	03090000000000000
1365	193	Инв.1101091002115	\N	2	1	2026-03-01 11:45:05.643719	1	1101091002115	7240.00	101.38.1	03090000000000000
1366	193	Инв.1101091002123	\N	2	1	2026-03-01 11:45:05.64372	1	1101091002123	7240.00	101.38.1	03090000000000000
1367	193	Инв.1101091002184	\N	2	1	2026-03-01 11:45:05.643721	1	1101091002184	7240.00	101.38.1	03090000000000000
1368	193	Инв.1101091002146	\N	2	1	2026-03-01 11:45:05.643723	1	1101091002146	7240.00	101.38.1	03090000000000000
1369	193	Инв.1101091002178	\N	2	1	2026-03-01 11:45:05.643724	1	1101091002178	7240.00	101.38.1	03090000000000000
1370	193	Инв.1101091002170	\N	2	1	2026-03-01 11:45:05.643725	1	1101091002170	7240.00	101.38.1	03090000000000000
1371	193	Инв.1101091002182	\N	2	1	2026-03-01 11:45:05.643726	1	1101091002182	7240.00	101.38.1	03090000000000000
1372	193	Инв.1101091002168	\N	2	1	2026-03-01 11:45:05.643727	1	1101091002168	7240.00	101.38.1	03090000000000000
1373	193	Инв.1101091002174	\N	2	1	2026-03-01 11:45:05.643728	1	1101091002174	7240.00	101.38.1	03090000000000000
1374	193	Инв.1101091002198	\N	2	1	2026-03-01 11:45:05.643729	1	1101091002198	7240.00	101.38.1	03090000000000000
1375	193	Инв.1101091002112	\N	2	1	2026-03-01 11:45:05.643731	1	1101091002112	7240.00	101.38.1	03090000000000000
1376	193	Инв.1101091002114	\N	2	1	2026-03-01 11:45:05.643732	1	1101091002114	7240.00	101.38.1	03090000000000000
1377	193	Инв.1101091002067	\N	2	1	2026-03-01 11:45:05.643733	1	1101091002067	7240.00	101.38.1	03090000000000000
1378	193	Инв.1101091002062	\N	2	1	2026-03-01 11:45:05.643734	1	1101091002062	7240.00	101.38.1	03090000000000000
1379	193	Инв.1101091002133	\N	2	1	2026-03-01 11:45:05.643735	1	1101091002133	7240.00	101.38.1	03090000000000000
1380	193	Инв.1101091002064	\N	2	1	2026-03-01 11:45:05.643736	1	1101091002064	7240.00	101.38.1	03090000000000000
1381	193	Инв.1101091002156	\N	2	1	2026-03-01 11:45:05.643738	1	1101091002156	7240.00	101.38.1	03090000000000000
1382	193	Инв.1101091002082	\N	2	1	2026-03-01 11:45:05.643739	1	1101091002082	7240.00	101.38.1	03090000000000000
1383	193	Инв.1101091002141	\N	2	1	2026-03-01 11:45:05.64374	1	1101091002141	7240.00	101.38.1	03090000000000000
1384	193	Инв.1101091002070	\N	2	1	2026-03-01 11:45:05.643741	1	1101091002070	7240.00	101.38.1	03090000000000000
1385	193	Инв.1101091002208	\N	2	1	2026-03-01 11:45:05.643742	1	1101091002208	7240.00	101.38.1	03090000000000000
1386	193	Инв.1101091002059	\N	2	1	2026-03-01 11:45:05.643743	1	1101091002059	7240.00	101.38.1	03090000000000000
1387	193	Инв.1101091002173	\N	2	1	2026-03-01 11:45:05.643745	1	1101091002173	7240.00	101.38.1	03090000000000000
1388	193	Инв.1101091002163	\N	2	1	2026-03-01 11:45:05.643746	1	1101091002163	7240.00	101.38.1	03090000000000000
1389	193	Инв.1101091002094	\N	2	1	2026-03-01 11:45:05.643747	1	1101091002094	7240.00	101.38.1	03090000000000000
1390	193	Инв.1101091002084	\N	2	1	2026-03-01 11:45:05.643748	1	1101091002084	7240.00	101.38.1	03090000000000000
1391	193	Инв.1101091002207	\N	2	1	2026-03-01 11:45:05.643749	1	1101091002207	7240.00	101.38.1	03090000000000000
1392	193	Инв.1101091002167	\N	2	1	2026-03-01 11:45:05.64375	1	1101091002167	7240.00	101.38.1	03090000000000000
1393	193	Инв.1101091002148	\N	2	1	2026-03-01 11:45:05.643752	1	1101091002148	7240.00	101.38.1	03090000000000000
1394	193	Инв.1101091002124	\N	2	1	2026-03-01 11:45:05.643753	1	1101091002124	7240.00	101.38.1	03090000000000000
1395	193	Инв.1101091002106	\N	2	1	2026-03-01 11:45:05.643754	1	1101091002106	7240.00	101.38.1	03090000000000000
1396	193	Инв.1101091002092	\N	2	1	2026-03-01 11:45:05.643755	1	1101091002092	7240.00	101.38.1	03090000000000000
1397	193	Инв.1101091002185	\N	2	1	2026-03-01 11:45:05.643756	1	1101091002185	7240.00	101.38.1	03090000000000000
1398	193	Инв.1101091002169	\N	2	1	2026-03-01 11:45:05.643758	1	1101091002169	7240.00	101.38.1	03090000000000000
1399	193	Инв.1101091002117	\N	2	1	2026-03-01 11:45:05.643759	1	1101091002117	7240.00	101.38.1	03090000000000000
1400	193	Инв.1101091002203	\N	2	1	2026-03-01 11:45:05.64376	1	1101091002203	7240.00	101.38.1	03090000000000000
1401	193	Инв.1101091002143	\N	2	1	2026-03-01 11:45:05.643761	1	1101091002143	7240.00	101.38.1	03090000000000000
1402	193	Инв.1101091002151	\N	2	1	2026-03-01 11:45:05.643762	1	1101091002151	7240.00	101.38.1	03090000000000000
1403	193	Инв.1101091002179	\N	2	1	2026-03-01 11:45:05.643764	1	1101091002179	7240.00	101.38.1	03090000000000000
1404	193	Инв.1101091002135	\N	2	1	2026-03-01 11:45:05.643765	1	1101091002135	7240.00	101.38.1	03090000000000000
1405	193	Инв.1101091002149	\N	2	1	2026-03-01 11:45:05.643766	1	1101091002149	7240.00	101.38.1	03090000000000000
1406	194	Инв.1101091002307	\N	2	1	2026-03-01 11:45:05.643767	1	1101091002307	4992.00	101.38.1	03090000000000000
1407	194	Инв.1101091002306	\N	2	1	2026-03-01 11:45:05.643768	1	1101091002306	4992.00	101.38.1	03090000000000000
1408	194	Инв.1101091002312	\N	2	1	2026-03-01 11:45:05.643769	1	1101091002312	4992.00	101.38.1	03090000000000000
1409	194	Инв.1101091002310	\N	2	1	2026-03-01 11:45:05.643771	1	1101091002310	4992.00	101.38.1	03090000000000000
1410	194	Инв.1101091002309	\N	2	1	2026-03-01 11:45:05.643772	1	1101091002309	4992.00	101.38.1	03090000000000000
1411	194	Инв.1101091002305	\N	2	1	2026-03-01 11:45:05.643773	1	1101091002305	4992.00	101.38.1	03090000000000000
1412	194	Инв.1101091002311	\N	2	1	2026-03-01 11:45:05.643774	1	1101091002311	4992.00	101.38.1	03090000000000000
1413	194	Инв.1101091002308	\N	2	1	2026-03-01 11:45:05.643775	1	1101091002308	4992.00	101.38.1	03090000000000000
1414	195	Инв.1101091002319	\N	2	1	2026-03-01 11:45:05.643776	1	1101091002319	4992.00	101.38.1	03090000000000000
1415	195	Инв.1101091002346	\N	2	1	2026-03-01 11:45:05.643778	1	1101091002346	4992.00	101.38.1	03090000000000000
1416	195	Инв.1101091002345	\N	2	1	2026-03-01 11:45:05.643779	1	1101091002345	4992.00	101.38.1	03090000000000000
1417	195	Инв.1101091002321	\N	2	1	2026-03-01 11:45:05.64378	1	1101091002321	4992.00	101.38.1	03090000000000000
1418	195	Инв.1101091002340	\N	2	1	2026-03-01 11:45:05.643781	1	1101091002340	4992.00	101.38.1	03090000000000000
1419	195	Инв.1101091002333	\N	2	1	2026-03-01 11:45:05.643782	1	1101091002333	4992.00	101.38.1	03090000000000000
1420	195	Инв.1101091002344	\N	2	1	2026-03-01 11:45:05.643783	1	1101091002344	4992.00	101.38.1	03090000000000000
1421	195	Инв.1101091002348	\N	2	1	2026-03-01 11:45:05.643785	1	1101091002348	4992.00	101.38.1	03090000000000000
1422	195	Инв.1101091002347	\N	2	1	2026-03-01 11:45:05.643786	1	1101091002347	4992.00	101.38.1	03090000000000000
1423	195	Инв.1101091002334	\N	2	1	2026-03-01 11:45:05.643787	1	1101091002334	4992.00	101.38.1	03090000000000000
1424	195	Инв.1101091002337	\N	2	1	2026-03-01 11:45:05.643788	1	1101091002337	4992.00	101.38.1	03090000000000000
1425	195	Инв.1101091002331	\N	2	1	2026-03-01 11:45:05.643789	1	1101091002331	4992.00	101.38.1	03090000000000000
1426	195	Инв.1101091002316	\N	2	1	2026-03-01 11:45:05.643791	1	1101091002316	4992.00	101.38.1	03090000000000000
1427	195	Инв.1101091002315	\N	2	1	2026-03-01 11:45:05.643792	1	1101091002315	4992.00	101.38.1	03090000000000000
1428	195	Инв.1101091002332	\N	2	1	2026-03-01 11:45:05.643793	1	1101091002332	4992.00	101.38.1	03090000000000000
1429	195	Инв.1101091002351	\N	2	1	2026-03-01 11:45:05.643794	1	1101091002351	4992.00	101.38.1	03090000000000000
1430	195	Инв.1101091002336	\N	2	1	2026-03-01 11:45:05.643795	1	1101091002336	4992.00	101.38.1	03090000000000000
1431	195	Инв.1101091002335	\N	2	1	2026-03-01 11:45:05.643796	1	1101091002335	4992.00	101.38.1	03090000000000000
1432	195	Инв.1101091002349	\N	2	1	2026-03-01 11:45:05.643798	1	1101091002349	4992.00	101.38.1	03090000000000000
1433	195	Инв.1101091002399	\N	2	1	2026-03-01 11:45:05.643799	1	1101091002399	4992.00	101.38.1	03090000000000000
1434	195	Инв.1101091002350	\N	2	1	2026-03-01 11:45:05.6438	1	1101091002350	4992.00	101.38.1	03090000000000000
1435	195	Инв.1101091002343	\N	2	1	2026-03-01 11:45:05.643801	1	1101091002343	4992.00	101.38.1	03090000000000000
1436	195	Инв.1101091002313	\N	2	1	2026-03-01 11:45:05.643802	1	1101091002313	4992.00	101.38.1	03090000000000000
1437	195	Инв.1101091002318	\N	2	1	2026-03-01 11:45:05.643803	1	1101091002318	4992.00	101.38.1	03090000000000000
1438	195	Инв.1101091002323	\N	2	1	2026-03-01 11:45:05.643805	1	1101091002323	4992.00	101.38.1	03090000000000000
1439	195	Инв.1101091002401	\N	2	1	2026-03-01 11:45:05.643806	1	1101091002401	4992.00	101.38.1	03090000000000000
1440	195	Инв.1101091002341	\N	2	1	2026-03-01 11:45:05.643807	1	1101091002341	4992.00	101.38.1	03090000000000000
1441	195	Инв.1101091002325	\N	2	1	2026-03-01 11:45:05.643808	1	1101091002325	4992.00	101.38.1	03090000000000000
1442	195	Инв.1101091002403	\N	2	1	2026-03-01 11:45:05.643809	1	1101091002403	4992.00	101.38.1	03090000000000000
1443	195	Инв.1101091002402	\N	2	1	2026-03-01 11:45:05.64381	1	1101091002402	4992.00	101.38.1	03090000000000000
1444	195	Инв.1101091002329	\N	2	1	2026-03-01 11:45:05.643812	1	1101091002329	4992.00	101.38.1	03090000000000000
1445	195	Инв.1101091002352	\N	2	1	2026-03-01 11:45:05.643813	1	1101091002352	4992.00	101.38.1	03090000000000000
1446	195	Инв.1101091002324	\N	2	1	2026-03-01 11:45:05.643814	1	1101091002324	4992.00	101.38.1	03090000000000000
1447	195	Инв.1101091002339	\N	2	1	2026-03-01 11:45:05.643815	1	1101091002339	4992.00	101.38.1	03090000000000000
1448	195	Инв.1101091002327	\N	2	1	2026-03-01 11:45:05.643816	1	1101091002327	4992.00	101.38.1	03090000000000000
1449	195	Инв.1101091002338	\N	2	1	2026-03-01 11:45:05.643817	1	1101091002338	4992.00	101.38.1	03090000000000000
1450	195	Инв.1101091002314	\N	2	1	2026-03-01 11:45:05.643819	1	1101091002314	4992.00	101.38.1	03090000000000000
1451	195	Инв.1101091002317	\N	2	1	2026-03-01 11:45:05.64382	1	1101091002317	4992.00	101.38.1	03090000000000000
1452	195	Инв.1101091002400	\N	2	1	2026-03-01 11:45:05.643821	1	1101091002400	4992.00	101.38.1	03090000000000000
1453	195	Инв.1101091002342	\N	2	1	2026-03-01 11:45:05.643822	1	1101091002342	4992.00	101.38.1	03090000000000000
1454	195	Инв.1101091002320	\N	2	1	2026-03-01 11:45:05.643823	1	1101091002320	4992.00	101.38.1	03090000000000000
1455	195	Инв.1101091002328	\N	2	1	2026-03-01 11:45:05.643824	1	1101091002328	4992.00	101.38.1	03090000000000000
1456	195	Инв.1101091002326	\N	2	1	2026-03-01 11:45:05.643826	1	1101091002326	4992.00	101.38.1	03090000000000000
1457	195	Инв.1101091002330	\N	2	1	2026-03-01 11:45:05.643827	1	1101091002330	4992.00	101.38.1	03090000000000000
1458	195	Инв.1101091002322	\N	2	1	2026-03-01 11:45:05.643828	1	1101091002322	4992.00	101.38.1	03090000000000000
1459	196	Партия 1	\N	2	1	2026-03-01 11:45:05.643829	4	\N	70.15	105.34.1	03090000000000000
1460	197	Партия 1	\N	2	1	2026-03-01 11:45:05.64383	30	\N	85000.00	105.35.1	03100000000000000
1461	198	Гк 188Б	\N	2	1	2026-03-01 11:45:05.643832	40	\N	138686.10	105.35.1	03100000000000000
1462	199	Партия 1	\N	2	1	2026-03-01 11:45:05.643833	30	\N	36360.00	105.35.1	03100000000000000
1463	200	Партия 1	\N	2	1	2026-03-01 11:45:05.643834	2	\N	39262.33	105.35.1	03090000000000000
1464	201	Партия 1	\N	2	1	2026-03-01 11:45:05.643835	4	\N	39262.33	105.35.1	03090000000000000
1465	202	Партия 1	\N	2	1	2026-03-01 11:45:05.643836	1	\N	39262.33	105.35.1	03090000000000000
1466	203	Партия 1	\N	2	1	2026-03-01 11:45:05.643837	7	\N	5690.78	105.35.1	03090000000000000
1467	204	Партия 1	\N	2	1	2026-03-01 11:45:05.643839	7	\N	7379.56	105.35.1	03090000000000000
1468	205	синего цвета	\N	2	1	2026-03-01 11:45:05.64384	9	\N	600.00	105.35.1	03090000000000000
1469	206	белого цвета с цветными вставками	\N	2	1	2026-03-01 11:45:05.643841	50	\N	900.00	105.35.1	03090000000000000
1470	206	камуфляжного цвета	\N	2	1	2026-03-01 11:45:05.643842	50	\N	600.00	105.35.1	03090000000000000
1471	207	Партия 1	\N	2	1	2026-03-01 11:45:05.643843	24450	\N	2.00	105.36.1	03090000000000000
1472	208	Партия 1	\N	2	1	2026-03-01 11:45:05.643845	283	\N	1.39	105.36.1	03090000000000000
1473	208	Партия 1	\N	1	1	2026-03-01 11:45:05.643846	3360	\N	1.39	105.36.1	03090000000000000
1474	209	Партия 1	\N	2	1	2026-03-01 11:45:05.643847	120174	\N	2.25	105.36.1	03090000000000000
1475	210	Партия 1	\N	2	1	2026-03-01 11:45:05.643848	6480	\N	26.41	105.36.1	03090000000000000
1476	211	Партия 1	\N	2	1	2026-03-01 11:45:05.643849	2520	\N	1.50	105.36.1	03090000000000000
1477	212	Партия 1	\N	2	1	2026-03-01 11:45:05.64385	31	\N	1.00	105.36.1	03090000000000000
1478	212	Партия 1	\N	1	1	2026-03-01 11:45:05.643852	671	\N	1.00	105.36.1	03090000000000000
1479	213	Партия 1	\N	1	1	2026-03-01 11:45:05.643853	745	\N	1.25	105.36.1	03090000000000000
1480	214	Партия 1	\N	2	1	2026-03-01 11:45:05.643854	10803	\N	1.62	105.36.1	03090000000000000
1481	215	Партия 1	\N	2	1	2026-03-01 11:45:05.643855	7207	\N	2.28	105.36.1	03090000000000000
1482	216	Партия 1	\N	1	1	2026-03-01 11:45:05.643856	519	\N	4.97	105.36.1	03090000000000000
1483	217	Партия 1	\N	2	1	2026-03-01 11:45:05.643857	25600	\N	2.28	105.36.1	03090000000000000
1484	218	инд. 57-Н-181С	\N	2	1	2026-03-01 11:45:05.643859	80	\N	3.17	105.36.1	03090000000000000
1485	219	ПП	\N	2	1	2026-03-01 11:45:05.64386	4216	\N	12.04	105.36.1	03090000000000000
1486	220	Партия 1	\N	2	1	2026-03-01 11:45:05.643861	4	\N	255.00	105.36.1	03090000000000000
1487	221	Партия 1	\N	2	1	2026-03-01 11:45:05.643862	73	\N	174.63	105.36.1	03090000000000000
1488	222	Партия 1	\N	2	1	2026-03-01 11:45:05.643863	2	\N	59.00	105.36.1	03090000000000000
1489	223	Партия 1	\N	2	1	2026-03-01 11:45:05.643865	2	\N	408.01	105.36.1	03090000000000000
1490	224	Партия 1	\N	1	1	2026-03-01 11:45:05.643866	21	\N	391.03	105.36.1	03090000000000000
1491	225	Партия 1	\N	1	1	2026-03-01 11:45:05.643867	12	\N	380.00	105.36.1	03090000000000000
1492	226	Партия 1	\N	2	1	2026-03-01 11:45:05.643868	295	\N	1709.40	105.36.1	03090000000000000
1493	227	Партия 1	\N	2	1	2026-03-01 11:45:05.643869	2	\N	650.00	105.36.1	03090000000000000
1494	228	Партия 1	\N	1	1	2026-03-01 11:45:05.64387	8	\N	796.01	105.36.1	03090000000000000
1495	229	Партия 1	\N	1	1	2026-03-01 11:45:05.643872	12	\N	911.00	105.36.1	03090000000000000
1496	230	Партия 1	\N	1	1	2026-03-01 11:45:05.643873	4	\N	815.00	105.36.1	03090000000000000
1497	231	Партия 1	\N	1	1	2026-03-01 11:45:05.643874	6	\N	481.01	105.36.1	03090000000000000
1498	232	Партия 1	\N	2	1	2026-03-01 11:45:05.643875	19	\N	50.00	105.36.1	03090000000000000
1499	233	для автоматов	\N	2	1	2026-03-01 11:45:05.643876	164	\N	299.43	105.36.1	03090000000000000
1500	234	Партия 1	\N	2	1	2026-03-01 11:45:05.643877	8	\N	225.00	105.36.1	03090000000000000
1501	235	ПМ	\N	2	1	2026-03-01 11:45:05.643879	15	\N	100.00	105.36.1	03090000000000000
1502	236	Партия 1	\N	2	1	2026-03-01 11:45:05.64388	2	\N	255.00	105.36.1	03090000000000000
1503	237	9мм, 8патр.	\N	2	1	2026-03-01 11:45:05.643881	3	\N	395.00	105.36.1	03090000000000000
1504	238	Партия 1	\N	2	1	2026-03-01 11:45:05.643882	329	\N	373.30	105.36.1	03090000000000000
1505	239	100	\N	1	1	2026-03-01 11:45:05.643883	4	\N	290.00	105.36.1	03090000000000000
1506	240	Партия 1	\N	2	1	2026-03-01 11:45:05.643885	2006	\N	5.07	105.36.1	03090000000000000
1507	241	Партия 1	\N	2	1	2026-03-01 11:45:05.643886	2120	\N	26.41	105.36.1	03090000000000000
1508	242	Партия 1	\N	2	1	2026-03-01 11:45:05.643887	156	\N	1.62	105.36.1	03090000000000000
1509	243	ОБ БПЗ	\N	1	1	2026-03-01 11:45:05.643888	34	\N	16.00	105.36.1	03090000000000000
1510	244	Партия 1	\N	2	1	2026-03-01 11:45:05.643889	245	\N	30.00	105.36.1	03090000000000000
1511	245	Партия 1	\N	2	1	2026-03-01 11:45:05.64389	1062	\N	3.15	105.36.1	03090000000000000
1512	246	Партия 1	\N	2	1	2026-03-01 11:45:05.643892	4424	\N	32.85	105.36.1	03090000000000000
1513	247	Партия 1	\N	2	1	2026-03-01 11:45:05.643893	50	\N	2.00	105.36.1	03090000000000000
1514	248	Партия 1	\N	2	1	2026-03-01 11:45:05.643894	20	\N	59.00	105.36.1	03090000000000000
1515	249	Партия 1	\N	2	1	2026-03-01 11:45:05.643895	6	\N	2000.00	105.36.1	03090000000000000
1516	250	Партия 1	\N	2	1	2026-03-01 11:45:05.643896	545	\N	82.93	105.36.1	03090000000000000
1517	251	пистолета "Ярыгина"	\N	2	1	2026-03-01 11:45:05.643897	2	\N	251.00	105.36.1	03090000000000000
1518	252	Партия 1	\N	1	1	2026-03-01 11:45:05.643898	22	\N	195.00	105.36.1	03090000000000000
1519	253	Партия 1	\N	2	1	2026-03-01 11:45:05.6439	6	\N	300.00	105.36.1	03090000000000000
1520	254	Партия 1	\N	2	1	2026-03-01 11:45:05.643901	8	\N	149.00	105.36.1	03090000000000000
1521	255	Партия 1	\N	2	1	2026-03-01 11:45:05.643902	2	\N	249.00	105.36.1	03090000000000000
1522	256	Партия 1	\N	2	1	2026-03-01 11:45:05.643903	100	\N	140.32	105.36.1	03090000000000000
1523	257	Партия 1	\N	2	1	2026-03-01 11:45:05.643904	2	\N	50.00	105.36.1	03090000000000000
1524	258	Партия 1	\N	1	1	2026-03-01 11:45:05.643906	2	\N	200000.00	105.36.1	03100000000000000
1525	259	Партия 1	\N	2	1	2026-03-01 11:45:05.643907	2	\N	69.00	105.36.1	03090000000000000
1526	260	Партия 1	\N	2	1	2026-03-01 11:45:05.643908	6	\N	400.00	105.36.1	03090000000000000
1527	261	Партия 1	\N	2	1	2026-03-01 11:45:05.643909	4	\N	632.00	105.36.1	03090000000000000
1528	262	Партия 1	\N	2	1	2026-03-01 11:45:05.64391	22	\N	28.95	105.36.1	03090000000000000
1529	263	Партия 1	\N	1	1	2026-03-01 11:45:05.643912	3	\N	7600.00	105.36.1	03090000000000000
1530	264	Партия 1	\N	1	1	2026-03-01 11:45:05.643913	2	\N	7600.00	105.36.1	03090000000000000
1531	265	Партия 1	\N	1	1	2026-03-01 11:45:05.643914	3	\N	2005.12	105.36.1	03090000000000000
1532	266	Партия 1	\N	1	1	2026-03-01 11:45:05.643915	2	\N	160000.00	105.36.1	03090000000000000
1533	267	Партия 1	\N	1	1	2026-03-01 11:45:05.643916	5	\N	6064.00	105.36.1	03090000000000000
1534	268	Партия 1	\N	1	1	2026-03-01 11:45:05.643917	1	\N	6064.00	105.36.1	03090000000000000
1535	269	Beretta-92 FS	\N	1	1	2026-03-01 11:45:05.643919	4	\N	6064.00	105.36.1	03090000000000000
1536	270	кобура к пистолетам	\N	1	1	2026-03-01 11:45:05.64392	19	\N	860.00	105.36.1	03090000000000000
1537	271	ПМ,ПММ,ПСМ,АПС	\N	2	1	2026-03-01 11:45:05.643921	14	\N	300.00	105.36.1	03090000000000000
1538	272	Партия 1	\N	2	1	2026-03-01 11:45:05.643922	4	\N	6600.00	105.36.1	03090000000000000
1539	273	Партия 1	\N	1	1	2026-03-01 11:45:05.643923	1	\N	153000.00	105.36.1	03090000000000000
1540	274	Партия 1	\N	2	1	2026-03-01 11:45:05.643925	68	\N	69.00	105.36.1	03090000000000000
1541	275	Партия 1	\N	2	1	2026-03-01 11:45:05.643926	6	1С01060700331	475.00	21.38.1	03090000000000000
1542	276	10л	\N	2	1	2026-03-01 11:45:05.643927	1	\N	590.00	21.34.1	\N
1543	277	Инв.1101040700125	\N	2	1	2026-03-01 11:45:05.643928	1	1101040700125	1357.52	21.34.1	\N
1544	277	Инв.1101040700124	\N	2	1	2026-03-01 11:45:05.643929	1	1101040700124	1357.52	21.34.1	\N
1545	277	Инв.1101040700105	\N	2	1	2026-03-01 11:45:05.64393	1	1101040700105	1357.52	21.34.1	\N
1547	279	Б/Н-1586	\N	2	1	2026-03-01 11:45:05.643933	1	\N	1300.00	21.34.1	\N
1548	280	Б/Н-1587	\N	2	1	2026-03-01 11:45:05.643934	1	\N	4242.00	21.36.1	\N
1549	280	Б/Н-1588	\N	2	1	2026-03-01 11:45:05.643935	1	\N	4242.00	21.36.1	\N
1550	280	Б/Н-1589	\N	2	1	2026-03-01 11:45:05.643936	1	\N	4242.00	21.36.1	\N
1551	281	140х60х75	\N	2	1	2026-03-01 11:45:05.643937	1	\N	2007.32	21.36.1	\N
1552	282	Б/Н-1591	\N	2	1	2026-03-01 11:45:05.643939	1	\N	2774.51	21.36.1	\N
1553	283	Инв.1101361003481	\N	2	1	2026-03-01 11:45:05.64394	1	1101361003481	5263.00	21.36.1	\N
1554	109	ПЕ552, ГМ4004	\N	1	1	2026-03-01 11:45:05.643941	1	\N	657.00	21.38.1	\N
1555	284	30887	\N	2	1	2026-03-01 11:45:05.643942	1	\N	1048.00	21.38.1	\N
1556	284	УФ754	\N	2	1	2026-03-01 11:45:05.643943	1	\N	1048.00	21.38.1	\N
1557	285	ДВ4209	\N	2	1	2026-03-01 11:45:05.643944	1	\N	788.00	21.38.1	\N
1558	285	ПП475	\N	2	1	2026-03-01 11:45:05.643946	1	\N	788.00	21.38.1	\N
1559	286	АС2077И	\N	2	1	2026-03-01 11:45:05.643947	1	\N	1228.00	21.38.1	\N
1560	286	ЛГ2428	\N	2	1	2026-03-01 11:45:05.643948	1	\N	1228.00	21.38.1	\N
1561	116	АБ 0500	\N	2	1	2026-03-01 11:45:05.643949	1	\N	3770.00	21.38.1	\N
1562	116	АБ 0502	\N	2	1	2026-03-01 11:45:05.643951	1	\N	3770.00	21.38.1	\N
1563	116	АБ 2440	\N	2	1	2026-03-01 11:45:05.643952	1	\N	3770.00	21.38.1	\N
1564	116	АБ 2886	\N	2	1	2026-03-01 11:45:05.643953	1	\N	3770.00	21.38.1	\N
1565	116	АБ 3281	\N	2	1	2026-03-01 11:45:05.643954	1	\N	3770.00	21.38.1	\N
1566	116	АБ 3415	\N	2	1	2026-03-01 11:45:05.643955	1	\N	3770.00	21.38.1	\N
1567	116	АБ 3446	\N	2	1	2026-03-01 11:45:05.643956	1	\N	3770.00	21.38.1	\N
1568	116	АБ 3475	\N	2	1	2026-03-01 11:45:05.643958	1	\N	3770.00	21.38.1	\N
1569	116	АБ 3583	\N	2	1	2026-03-01 11:45:05.643959	1	\N	3770.00	21.38.1	\N
1570	116	АБ 3791	\N	2	1	2026-03-01 11:45:05.64396	1	\N	3770.00	21.38.1	\N
1571	116	АБ 3980	\N	2	1	2026-03-01 11:45:05.643961	1	\N	3770.00	21.38.1	\N
1572	116	АБ 4020	\N	2	1	2026-03-01 11:45:05.643962	1	\N	3770.00	21.38.1	\N
1573	116	АБ 4080	\N	2	1	2026-03-01 11:45:05.643963	1	\N	3770.00	21.38.1	\N
1574	116	АБ 4086	\N	2	1	2026-03-01 11:45:05.643964	1	\N	3770.00	21.38.1	\N
1575	116	АБ 4152	\N	2	1	2026-03-01 11:45:05.643966	1	\N	3770.00	21.38.1	\N
1576	116	АБ 4191	\N	2	1	2026-03-01 11:45:05.643967	1	\N	3770.00	21.38.1	\N
1577	116	АБ 4417	\N	2	1	2026-03-01 11:45:05.643968	1	\N	3770.00	21.38.1	\N
1578	116	АБ 4486	\N	2	1	2026-03-01 11:45:05.643969	1	\N	3770.00	21.38.1	\N
1579	116	АБ 4532	\N	2	1	2026-03-01 11:45:05.64397	1	\N	3770.00	21.38.1	\N
1580	116	АБ 4568	\N	2	1	2026-03-01 11:45:05.643972	1	\N	3770.00	21.38.1	\N
1581	116	АБ 4589	\N	2	1	2026-03-01 11:45:05.643973	1	\N	3770.00	21.38.1	\N
1582	116	АБ 4651	\N	2	1	2026-03-01 11:45:05.643974	1	\N	3770.00	21.38.1	\N
1583	116	АБ 4671	\N	2	1	2026-03-01 11:45:05.643975	1	\N	3770.00	21.38.1	\N
1584	116	АБ 4695	\N	2	1	2026-03-01 11:45:05.643976	1	\N	3770.00	21.38.1	\N
1585	116	АБ 4745	\N	2	1	2026-03-01 11:45:05.643978	1	\N	3770.00	21.38.1	\N
1586	116	АБ 4750	\N	2	1	2026-03-01 11:45:05.643979	1	\N	3770.00	21.38.1	\N
1587	116	АБ 4839	\N	2	1	2026-03-01 11:45:05.64398	1	\N	3770.00	21.38.1	\N
1588	116	АБ 4871	\N	2	1	2026-03-01 11:45:05.643981	1	\N	3770.00	21.38.1	\N
1589	116	АБ 4875	\N	2	1	2026-03-01 11:45:05.643982	1	\N	3770.00	21.38.1	\N
1590	116	АБ 4886	\N	2	1	2026-03-01 11:45:05.643983	1	\N	3770.00	21.38.1	\N
1591	116	АБ 4915	\N	2	1	2026-03-01 11:45:05.643985	1	\N	3770.00	21.38.1	\N
1592	116	АБ 4921	\N	2	1	2026-03-01 11:45:05.643986	1	\N	3770.00	21.38.1	\N
1593	116	АБ 4927	\N	2	1	2026-03-01 11:45:05.643987	1	\N	3770.00	21.38.1	\N
1594	116	АБ 5002	\N	2	1	2026-03-01 11:45:05.643988	1	\N	3770.00	21.38.1	\N
1595	116	АБ 5062	\N	2	1	2026-03-01 11:45:05.643989	1	\N	3770.00	21.38.1	\N
1596	116	АБ 5155	\N	2	1	2026-03-01 11:45:05.643991	1	\N	3770.00	21.38.1	\N
1597	116	АБ 5234	\N	2	1	2026-03-01 11:45:05.643992	1	\N	3770.00	21.38.1	\N
1598	116	АБ 5261	\N	2	1	2026-03-01 11:45:05.643993	1	\N	3770.00	21.38.1	\N
1599	116	АБ 5340	\N	2	1	2026-03-01 11:45:05.643994	1	\N	3770.00	21.38.1	\N
1606	116	ЕО 2556	\N	2	1	2026-03-01 11:45:05.644003	1	\N	3770.00	21.38.1	\N
1607	116	ЕО 4882	\N	2	1	2026-03-01 11:45:05.644004	1	\N	3770.00	21.38.1	\N
1608	116	ЕО 5687	\N	2	1	2026-03-01 11:45:05.644005	1	\N	3770.00	21.38.1	\N
1609	116	ЕО 5896	\N	2	1	2026-03-01 11:45:05.644006	1	\N	3770.00	21.38.1	\N
1610	116	ЕР 1118	\N	2	1	2026-03-01 11:45:05.644007	1	\N	3770.00	21.38.1	\N
1611	116	ЕР 1501	\N	2	1	2026-03-01 11:45:05.644008	1	\N	3770.00	21.38.1	\N
1612	116	ЕР 832	\N	2	1	2026-03-01 11:45:05.644009	1	\N	3770.00	21.38.1	\N
1613	116	ЕР 940	\N	2	1	2026-03-01 11:45:05.644011	1	\N	3770.00	21.38.1	\N
1614	116	ИА 5772	\N	2	1	2026-03-01 11:45:05.644012	1	\N	3770.00	21.38.1	\N
1615	116	ИП 5210	\N	2	1	2026-03-01 11:45:05.644013	1	\N	3770.00	21.38.1	\N
1616	116	ИП 7102	\N	2	1	2026-03-01 11:45:05.644014	1	\N	3770.00	21.38.1	\N
1617	116	ИР 0923	\N	2	1	2026-03-01 11:45:05.644016	1	\N	3770.00	21.38.1	\N
1618	116	КР 6253	\N	2	1	2026-03-01 11:45:05.644017	1	\N	3770.00	21.38.1	\N
1619	116	КР 7988	\N	2	1	2026-03-01 11:45:05.644018	1	\N	3770.00	21.38.1	\N
1620	116	КС7565	\N	2	1	2026-03-01 11:45:05.644019	1	\N	1118.00	21.38.1	\N
1621	116	КШ 0380	\N	2	1	2026-03-01 11:45:05.644021	1	\N	3770.00	21.38.1	\N
1622	116	ЛА 0413	\N	2	1	2026-03-01 11:45:05.644022	1	\N	3770.00	21.38.1	\N
1623	116	ЛА 1705	\N	2	1	2026-03-01 11:45:05.644023	1	\N	3770.00	21.38.1	\N
1624	116	ЛЕ 0396	\N	2	1	2026-03-01 11:45:05.644024	1	\N	3770.00	21.38.1	\N
1625	116	ЛЕ 0484	\N	2	1	2026-03-01 11:45:05.644026	1	\N	3770.00	21.38.1	\N
1626	116	ЛЕ 4242	\N	2	1	2026-03-01 11:45:05.644027	1	\N	3770.00	21.38.1	\N
1627	116	ЛЕ 5184	\N	2	1	2026-03-01 11:45:05.644028	1	\N	3770.00	21.38.1	\N
1628	116	ЛЕ 5853	\N	2	1	2026-03-01 11:45:05.644029	1	\N	3770.00	21.38.1	\N
1629	116	ЛИ 3344 М	\N	2	1	2026-03-01 11:45:05.64403	1	\N	3770.00	21.38.1	\N
1630	116	ЛИ 7101	\N	2	1	2026-03-01 11:45:05.644031	1	\N	3770.00	21.38.1	\N
1631	116	ЛИ 8398	\N	2	1	2026-03-01 11:45:05.644033	1	\N	3770.00	21.38.1	\N
1632	116	ЛР 1656	\N	2	1	2026-03-01 11:45:05.644034	1	\N	3770.00	21.38.1	\N
1633	116	МЕ 5388	\N	2	1	2026-03-01 11:45:05.644035	1	\N	3770.00	21.38.1	\N
1634	116	МЕ 7195	\N	2	1	2026-03-01 11:45:05.644036	1	\N	3770.00	21.38.1	\N
1635	116	МЛ 1039 Р	\N	2	1	2026-03-01 11:45:05.644037	1	\N	3770.00	21.38.1	\N
1636	116	МЛ 1974 Р	\N	2	1	2026-03-01 11:45:05.644039	1	\N	3770.00	21.38.1	\N
1637	116	МЛ 368	\N	2	1	2026-03-01 11:45:05.64404	1	\N	3770.00	21.38.1	\N
1638	116	МО 3045	\N	2	1	2026-03-01 11:45:05.644041	1	\N	3770.00	21.38.1	\N
1639	116	МП 2383	\N	2	1	2026-03-01 11:45:05.644042	1	\N	3770.00	21.38.1	\N
1640	116	МП 5193	\N	2	1	2026-03-01 11:45:05.644043	1	\N	3770.00	21.38.1	\N
1641	116	МП 5777	\N	2	1	2026-03-01 11:45:05.644044	1	\N	3770.00	21.38.1	\N
1642	116	МП 5817	\N	2	1	2026-03-01 11:45:05.644046	1	\N	3770.00	21.38.1	\N
1643	116	МШ 7418	\N	2	1	2026-03-01 11:45:05.644047	1	\N	3770.00	21.38.1	\N
1644	116	МШ 7455	\N	2	1	2026-03-01 11:45:05.644048	1	\N	3770.00	21.38.1	\N
1645	116	НА 7006	\N	2	1	2026-03-01 11:45:05.644049	1	\N	3770.00	21.38.1	\N
1646	116	НЕ 2384	\N	2	1	2026-03-01 11:45:05.64405	1	\N	3770.00	21.38.1	\N
1647	116	НЕ 2912	\N	2	1	2026-03-01 11:45:05.644067	1	\N	3770.00	21.38.1	\N
1648	116	НЕ 3523	\N	2	1	2026-03-01 11:45:05.644069	1	\N	3770.00	21.38.1	\N
1649	116	НЕ 3684	\N	2	1	2026-03-01 11:45:05.644071	1	\N	3770.00	21.38.1	\N
1650	116	НЕ 4151	\N	2	1	2026-03-01 11:45:05.644072	1	\N	3770.00	21.38.1	\N
1651	116	НЕ 4578	\N	2	1	2026-03-01 11:45:05.644073	1	\N	3770.00	21.38.1	\N
1652	116	НЕ 5040	\N	2	1	2026-03-01 11:45:05.644075	1	\N	3770.00	21.38.1	\N
1653	116	НЕ 5085	\N	2	1	2026-03-01 11:45:05.644076	1	\N	3770.00	21.38.1	\N
1654	116	НЕ 5304	\N	2	1	2026-03-01 11:45:05.644077	1	\N	3770.00	21.38.1	\N
1655	116	НМ 4524	\N	2	1	2026-03-01 11:45:05.644079	1	\N	3770.00	21.38.1	\N
1656	116	НМ 4538	\N	2	1	2026-03-01 11:45:05.64408	1	\N	3770.00	21.38.1	\N
1657	116	НМ 4854	\N	2	1	2026-03-01 11:45:05.644081	1	\N	3770.00	21.38.1	\N
1658	116	НУ1362	\N	2	1	2026-03-01 11:45:05.644082	1	\N	1117.90	21.38.1	\N
1659	116	ОБ 6019	\N	2	1	2026-03-01 11:45:05.644083	1	\N	3770.00	21.38.1	\N
1660	116	ОГ 8683	\N	2	1	2026-03-01 11:45:05.644085	1	\N	3770.00	21.38.1	\N
1661	116	ОЕ 0149	\N	2	1	2026-03-01 11:45:05.644086	1	\N	3770.00	21.38.1	\N
1662	116	ОМ 0160	\N	2	1	2026-03-01 11:45:05.644087	1	\N	3770.00	21.38.1	\N
1663	116	ОМ 0545	\N	2	1	2026-03-01 11:45:05.644088	1	\N	3770.00	21.38.1	\N
1664	116	ОМ 0713	\N	2	1	2026-03-01 11:45:05.64409	1	\N	3770.00	21.38.1	\N
1665	116	ОМ 1046	\N	2	1	2026-03-01 11:45:05.644091	1	\N	3770.00	21.38.1	\N
1666	116	ОМ 1238	\N	2	1	2026-03-01 11:45:05.644092	1	\N	3770.00	21.38.1	\N
1667	116	ОМ 1392	\N	2	1	2026-03-01 11:45:05.644093	1	\N	3770.00	21.38.1	\N
1668	116	ОМ 1609	\N	2	1	2026-03-01 11:45:05.644094	1	\N	3770.00	21.38.1	\N
1669	116	ОМ 3341	\N	2	1	2026-03-01 11:45:05.644096	1	\N	3770.00	21.38.1	\N
1670	116	ОН 1746	\N	2	1	2026-03-01 11:45:05.644097	1	\N	3770.00	21.38.1	\N
1671	116	ОН 2208	\N	2	1	2026-03-01 11:45:05.644098	1	\N	3770.00	21.38.1	\N
1672	116	ОН 3353 К	\N	2	1	2026-03-01 11:45:05.644099	1	\N	3770.00	21.38.1	\N
1673	116	ОН 4921	\N	2	1	2026-03-01 11:45:05.6441	1	\N	3770.00	21.38.1	\N
1674	116	ОН 5964	\N	2	1	2026-03-01 11:45:05.644102	1	\N	3770.00	21.38.1	\N
1675	116	ОР 2673	\N	2	1	2026-03-01 11:45:05.644103	1	\N	3770.00	21.38.1	\N
1676	116	ОР 2790	\N	2	1	2026-03-01 11:45:05.644104	1	\N	3770.00	21.38.1	\N
1677	116	ОР 3005	\N	2	1	2026-03-01 11:45:05.644105	1	\N	3770.00	21.38.1	\N
1678	116	ОР 3096	\N	2	1	2026-03-01 11:45:05.644107	1	\N	3770.00	21.38.1	\N
1679	116	ОР 3488	\N	2	1	2026-03-01 11:45:05.644108	1	\N	3770.00	21.38.1	\N
1680	116	ОР 3958	\N	2	1	2026-03-01 11:45:05.644109	1	\N	3770.00	21.38.1	\N
1681	116	ОТ 1341	\N	2	1	2026-03-01 11:45:05.64411	1	\N	3770.00	21.38.1	\N
1682	116	ОТ 1641	\N	2	1	2026-03-01 11:45:05.644111	1	\N	3770.00	21.38.1	\N
1683	116	ОТ 3550	\N	2	1	2026-03-01 11:45:05.644113	1	\N	3770.00	21.38.1	\N
1684	116	ОТ 3635	\N	2	1	2026-03-01 11:45:05.644114	1	\N	3770.00	21.38.1	\N
1685	116	ОТ 660	\N	2	1	2026-03-01 11:45:05.644115	1	\N	3770.00	21.38.1	\N
1686	116	ОТ 8500	\N	2	1	2026-03-01 11:45:05.644116	1	\N	3770.00	21.38.1	\N
1687	116	ПА 1626	\N	2	1	2026-03-01 11:45:05.644118	1	\N	3770.00	21.38.1	\N
1688	116	ПИ 3053	\N	2	1	2026-03-01 11:45:05.644119	1	\N	3770.00	21.38.1	\N
1689	116	РВ 5024	\N	2	1	2026-03-01 11:45:05.64412	1	\N	3770.00	21.38.1	\N
1690	116	РЕ 6211	\N	2	1	2026-03-01 11:45:05.644121	1	\N	3770.00	21.38.1	\N
1691	116	РК 4300	\N	2	1	2026-03-01 11:45:05.644122	1	\N	3770.00	21.38.1	\N
1692	116	РЛ 1432	\N	2	1	2026-03-01 11:45:05.644124	1	\N	3770.00	21.38.1	\N
1693	116	РЛ 1557	\N	2	1	2026-03-01 11:45:05.644125	1	\N	3770.00	21.38.1	\N
1694	116	РЛ 1838	\N	2	1	2026-03-01 11:45:05.644126	1	\N	3770.00	21.38.1	\N
1695	116	РЛ 2350	\N	2	1	2026-03-01 11:45:05.644127	1	\N	3770.00	21.38.1	\N
1696	116	РЛ 3620	\N	2	1	2026-03-01 11:45:05.644129	1	\N	3770.00	21.38.1	\N
1697	116	РЛ 3676	\N	2	1	2026-03-01 11:45:05.64413	1	\N	3770.00	21.38.1	\N
1698	116	РЛ 3871	\N	2	1	2026-03-01 11:45:05.644131	1	\N	3770.00	21.38.1	\N
1699	116	РЛ 935	\N	2	1	2026-03-01 11:45:05.644132	1	\N	3770.00	21.38.1	\N
1700	116	РН 4343	\N	2	1	2026-03-01 11:45:05.644133	1	\N	3770.00	21.38.1	\N
1701	116	РТ 4332	\N	2	1	2026-03-01 11:45:05.644135	1	\N	3770.00	21.38.1	\N
1702	116	РТ 5399	\N	2	1	2026-03-01 11:45:05.644136	1	\N	3770.00	21.38.1	\N
1703	116	СЛ 1430	\N	2	1	2026-03-01 11:45:05.644137	1	\N	3770.00	21.38.1	\N
1704	116	СМ 4572	\N	2	1	2026-03-01 11:45:05.644138	1	\N	3770.00	21.38.1	\N
1705	116	УЕ 0098	\N	2	1	2026-03-01 11:45:05.644139	1	\N	3770.00	21.38.1	\N
1706	116	УЕ 0100	\N	2	1	2026-03-01 11:45:05.64414	1	\N	3770.00	21.38.1	\N
1707	116	УЕ 0255	\N	2	1	2026-03-01 11:45:05.644142	1	\N	3770.00	21.38.1	\N
1708	116	УЕ 0353	\N	2	1	2026-03-01 11:45:05.644143	1	\N	3770.00	21.38.1	\N
1709	116	УЕ 0522	\N	2	1	2026-03-01 11:45:05.644144	1	\N	3770.00	21.38.1	\N
1710	116	УЕ 0531	\N	2	1	2026-03-01 11:45:05.644145	1	\N	3770.00	21.38.1	\N
1711	116	УЕ 0557	\N	2	1	2026-03-01 11:45:05.644146	1	\N	3770.00	21.38.1	\N
1712	116	УЕ 0612	\N	2	1	2026-03-01 11:45:05.644147	1	\N	3770.00	21.38.1	\N
1713	116	УЕ 1096	\N	2	1	2026-03-01 11:45:05.644149	1	\N	3770.00	21.38.1	\N
1714	116	УЕ 1645	\N	2	1	2026-03-01 11:45:05.64415	1	\N	3770.00	21.38.1	\N
1715	116	УЕ 1649	\N	2	1	2026-03-01 11:45:05.644151	1	\N	3770.00	21.38.1	\N
1716	116	УЕ 1868	\N	2	1	2026-03-01 11:45:05.644152	1	\N	3770.00	21.38.1	\N
1717	116	УЕ 2087	\N	2	1	2026-03-01 11:45:05.644153	1	\N	3770.00	21.38.1	\N
1718	116	УЕ 2151	\N	2	1	2026-03-01 11:45:05.644155	1	\N	3770.00	21.38.1	\N
1719	116	УЕ 2207	\N	2	1	2026-03-01 11:45:05.644156	1	\N	3770.00	21.38.1	\N
1720	116	УЕ 2508	\N	2	1	2026-03-01 11:45:05.644157	1	\N	3770.00	21.38.1	\N
1721	116	УЕ 2945	\N	2	1	2026-03-01 11:45:05.644158	1	\N	3770.00	21.38.1	\N
1722	116	УЕ 3458	\N	2	1	2026-03-01 11:45:05.644159	1	\N	3770.00	21.38.1	\N
1723	116	УЕ 4225	\N	2	1	2026-03-01 11:45:05.644161	1	\N	3770.00	21.38.1	\N
1724	116	УЕ 4531	\N	2	1	2026-03-01 11:45:05.644162	1	\N	3770.00	21.38.1	\N
1725	116	УЕ 4602	\N	2	1	2026-03-01 11:45:05.644163	1	\N	3770.00	21.38.1	\N
1726	116	УЕ 4677	\N	2	1	2026-03-01 11:45:05.644164	1	\N	3770.00	21.38.1	\N
1727	116	УЕ 4978	\N	2	1	2026-03-01 11:45:05.644165	1	\N	3770.00	21.38.1	\N
1728	116	УЛ5354	\N	2	1	2026-03-01 11:45:05.644167	1	\N	1118.00	21.38.1	\N
1729	116	УП 2035	\N	2	1	2026-03-01 11:45:05.644168	1	\N	3770.00	21.38.1	\N
1730	116	УП 5511	\N	2	1	2026-03-01 11:45:05.644169	1	\N	3770.00	21.38.1	\N
1731	116	УП 5799	\N	2	1	2026-03-01 11:45:05.64417	1	\N	3770.00	21.38.1	\N
1732	116	УП 5895	\N	2	1	2026-03-01 11:45:05.644171	1	\N	3770.00	21.38.1	\N
1733	116	УП 6040	\N	2	1	2026-03-01 11:45:05.644173	1	\N	3770.00	21.38.1	\N
1734	116	УП 6772	\N	2	1	2026-03-01 11:45:05.644174	1	\N	3770.00	21.38.1	\N
1735	116	УП 6806	\N	2	1	2026-03-01 11:45:05.644175	1	\N	3770.00	21.38.1	\N
1736	116	УП 7159	\N	2	1	2026-03-01 11:45:05.644176	1	\N	3770.00	21.38.1	\N
1737	116	УП 7193	\N	2	1	2026-03-01 11:45:05.644177	1	\N	3770.00	21.38.1	\N
1738	116	УП 7419	\N	2	1	2026-03-01 11:45:05.644182	1	\N	3770.00	21.38.1	\N
1739	116	УП 7422	\N	2	1	2026-03-01 11:45:05.644183	1	\N	3770.00	21.38.1	\N
1740	116	УП 7460	\N	2	1	2026-03-01 11:45:05.644185	1	\N	3770.00	21.38.1	\N
1741	116	УП 7546	\N	2	1	2026-03-01 11:45:05.644186	1	\N	3770.00	21.38.1	\N
1742	116	УП 7593	\N	2	1	2026-03-01 11:45:05.644187	1	\N	3770.00	21.38.1	\N
1743	116	УП 7787	\N	2	1	2026-03-01 11:45:05.644188	1	\N	3770.00	21.38.1	\N
1744	116	УП 7840	\N	2	1	2026-03-01 11:45:05.644189	1	\N	3770.00	21.38.1	\N
1745	116	УП 8009	\N	2	1	2026-03-01 11:45:05.64419	1	\N	3770.00	21.38.1	\N
1746	116	УП 8061	\N	2	1	2026-03-01 11:45:05.644191	1	\N	3770.00	21.38.1	\N
1747	116	УП 8129	\N	2	1	2026-03-01 11:45:05.644192	1	\N	3770.00	21.38.1	\N
1748	116	УП 8297	\N	2	1	2026-03-01 11:45:05.644194	1	\N	3770.00	21.38.1	\N
1749	116	УП 8342	\N	2	1	2026-03-01 11:45:05.644195	1	\N	3770.00	21.38.1	\N
1750	116	УП 8459	\N	2	1	2026-03-01 11:45:05.644196	1	\N	3770.00	21.38.1	\N
1751	116	УП 8529	\N	2	1	2026-03-01 11:45:05.644197	1	\N	3770.00	21.38.1	\N
1752	116	УП 8567	\N	2	1	2026-03-01 11:45:05.644198	1	\N	3770.00	21.38.1	\N
1753	116	УП 8601	\N	2	1	2026-03-01 11:45:05.644199	1	\N	3770.00	21.38.1	\N
1754	116	УП 8612	\N	2	1	2026-03-01 11:45:05.644201	1	\N	3770.00	21.38.1	\N
1755	116	УП 8679	\N	2	1	2026-03-01 11:45:05.644202	1	\N	3770.00	21.38.1	\N
1756	116	УП 8826	\N	2	1	2026-03-01 11:45:05.644203	1	\N	3770.00	21.38.1	\N
1757	116	УП 8880	\N	2	1	2026-03-01 11:45:05.644204	1	\N	3770.00	21.38.1	\N
1758	116	УП 8906	\N	2	1	2026-03-01 11:45:05.644205	1	\N	3770.00	21.38.1	\N
1759	116	УП 8916	\N	2	1	2026-03-01 11:45:05.644206	1	\N	3770.00	21.38.1	\N
1760	116	УП 8973	\N	2	1	2026-03-01 11:45:05.644207	1	\N	3770.00	21.38.1	\N
1761	116	УР 6391	\N	2	1	2026-03-01 11:45:05.644209	1	\N	3770.00	21.38.1	\N
1762	116	УР 6502	\N	2	1	2026-03-01 11:45:05.64421	1	\N	3770.00	21.38.1	\N
1763	116	ХА 0156	\N	2	1	2026-03-01 11:45:05.644211	1	\N	3770.00	21.38.1	\N
1764	116	ХА 1093	\N	2	1	2026-03-01 11:45:05.644212	1	\N	3770.00	21.38.1	\N
1765	116	ХА 3546	\N	2	1	2026-03-01 11:45:05.644213	1	\N	3770.00	21.38.1	\N
1766	116	ХА 3909	\N	2	1	2026-03-01 11:45:05.644214	1	\N	3770.00	21.38.1	\N
1767	116	ХА5355	\N	2	1	2026-03-01 11:45:05.644216	1	\N	1118.00	21.38.1	\N
1768	116	ХК 3450	\N	2	1	2026-03-01 11:45:05.644217	1	\N	3770.00	21.38.1	\N
1769	116	ШХ 0729	\N	2	1	2026-03-01 11:45:05.644218	1	\N	3770.00	21.38.1	\N
1770	116	ШХ 2063	\N	2	1	2026-03-01 11:45:05.644219	1	\N	3770.00	21.38.1	\N
1771	116	ШХ 4828	\N	2	1	2026-03-01 11:45:05.64422	1	\N	3770.00	21.38.1	\N
1772	116	ШХ 6065	\N	2	1	2026-03-01 11:45:05.644222	1	\N	3770.00	21.38.1	\N
1773	116	ШХ 6340	\N	2	1	2026-03-01 11:45:05.644223	1	\N	3770.00	21.38.1	\N
1774	116	ШХ 8372	\N	2	1	2026-03-01 11:45:05.644224	1	\N	3770.00	21.38.1	\N
1775	116	ШХ 8553	\N	2	1	2026-03-01 11:45:05.644225	1	\N	3770.00	21.38.1	\N
1776	118	ГМ6036	\N	2	1	2026-03-01 11:45:05.644226	1	1101381003282	8000.00	21.38.1	\N
1777	288	06Я1519	\N	2	1	2026-03-01 11:45:05.644227	1	\N	8944.40	21.38.1	\N
1778	288	06Я1977	\N	2	1	2026-03-01 11:45:05.644229	1	\N	8944.40	21.38.1	\N
1779	288	06Я1985	\N	2	1	2026-03-01 11:45:05.64423	1	\N	8944.40	21.38.1	\N
1780	288	АБ2084	\N	2	1	2026-03-01 11:45:05.644231	1	\N	8438.00	21.38.1	\N
1781	288	АБ2085	\N	2	1	2026-03-01 11:45:05.644232	1	\N	8944.40	21.38.1	\N
1782	130	Инв.1101091001051	\N	2	1	2026-03-01 11:45:05.644233	1	1101091001051	1491.00	21.38.1	\N
1783	130	НС16936	\N	2	1	2026-03-01 11:45:05.644234	1	\N	1491.00	21.38.1	\N
1784	130	НС17625	\N	2	1	2026-03-01 11:45:05.644236	1	\N	1491.00	21.38.1	\N
1785	130	НС18424	\N	2	1	2026-03-01 11:45:05.644237	1	\N	1491.00	21.38.1	\N
1786	131	Б/Н-1825	\N	2	1	2026-03-01 11:45:05.644238	1	\N	1333.00	21.38.1	\N
1787	131	Инв.1101091001058	\N	2	1	2026-03-01 11:45:05.644239	1	1101091001058	1333.00	21.38.1	\N
1788	131	Инв.1101091001057	\N	2	1	2026-03-01 11:45:05.64424	1	1101091001057	1333.00	21.38.1	\N
1789	132	ТО70271	\N	2	1	2026-03-01 11:45:05.644241	1	1101091001078	1008.00	21.38.1	\N
1790	289	Б/Н-1829	\N	2	1	2026-03-01 11:45:05.644242	1	\N	470.00	21.38.1	\N
1791	290	Б/Н-1830	\N	2	1	2026-03-01 11:45:05.644244	1	\N	1544.00	21.38.1	\N
1792	291	Б/Н-1831	\N	2	1	2026-03-01 11:45:05.644245	1	\N	2152.00	21.38.1	\N
1793	292	СЕ2009	\N	2	1	2026-03-01 11:45:05.644246	1	\N	5250.00	21.38.1	\N
1794	292	СЕ2013	\N	2	1	2026-03-01 11:45:05.644247	1	\N	5250.00	21.38.1	\N
1795	293	Б/Н-1834	\N	2	1	2026-03-01 11:45:05.644248	1	\N	2084.00	21.38.1	\N
1796	293	Б/Н-1835	\N	2	1	2026-03-01 11:45:05.644249	1	\N	2084.00	21.38.1	\N
1797	293	Б/Н-1836	\N	2	1	2026-03-01 11:45:05.644251	1	\N	2084.00	21.38.1	\N
1798	293	Б/Н-1837	\N	2	1	2026-03-01 11:45:05.644252	1	\N	2084.00	21.38.1	\N
1799	293	Б/Н-1838	\N	2	1	2026-03-01 11:45:05.644253	1	\N	2084.00	21.38.1	\N
1800	293	Б/Н-1839	\N	2	1	2026-03-01 11:45:05.644254	1	\N	2084.00	21.38.1	\N
1801	293	Б/Н-1840	\N	2	1	2026-03-01 11:45:05.644255	1	\N	2084.00	21.38.1	\N
1802	293	Б/Н-1841	\N	2	1	2026-03-01 11:45:05.644256	1	\N	2084.00	21.38.1	\N
1803	294	Б/Н-1842	\N	2	1	2026-03-01 11:45:05.644258	1	\N	2426.00	21.38.1	\N
1804	294	Б/Н-1843	\N	2	1	2026-03-01 11:45:05.644259	1	\N	2426.00	21.38.1	\N
1805	294	Б/Н-1844	\N	2	1	2026-03-01 11:45:05.64426	1	\N	2426.00	21.38.1	\N
1806	294	Б/Н-1845	\N	2	1	2026-03-01 11:45:05.644261	1	\N	2426.00	21.38.1	\N
1807	294	Б/Н-1846	\N	2	1	2026-03-01 11:45:05.644262	1	\N	2426.00	21.38.1	\N
1808	294	Б/Н-1847	\N	2	1	2026-03-01 11:45:05.644263	1	\N	2426.00	21.38.1	\N
1809	294	Б/Н-1848	\N	2	1	2026-03-01 11:45:05.644265	1	\N	2426.00	21.38.1	\N
1810	294	Б/Н-1849	\N	2	1	2026-03-01 11:45:05.644266	1	\N	2426.00	21.38.1	\N
1811	294	Б/Н-1850	\N	2	1	2026-03-01 11:45:05.644267	1	\N	2426.00	21.38.1	\N
1812	294	Б/Н-1851	\N	2	1	2026-03-01 11:45:05.644268	1	\N	2426.00	21.38.1	\N
1813	294	Б/Н-1852	\N	2	1	2026-03-01 11:45:05.644269	1	\N	2426.00	21.38.1	\N
1814	294	Б/Н-1853	\N	2	1	2026-03-01 11:45:05.64427	1	\N	2426.00	21.38.1	\N
1815	295	019513	\N	2	1	2026-03-01 11:45:05.644271	1	\N	2460.00	21.38.1	\N
1816	295	069511	\N	2	1	2026-03-01 11:45:05.644273	1	\N	2460.00	21.38.1	\N
1817	295	06958	\N	2	1	2026-03-01 11:45:05.644274	1	\N	2460.00	21.38.1	\N
1818	295	06959	\N	2	1	2026-03-01 11:45:05.644275	1	\N	2460.00	21.38.1	\N
1819	295	07953	\N	2	1	2026-03-01 11:45:05.644276	1	\N	2460.00	21.38.1	\N
1820	295	07956	\N	2	1	2026-03-01 11:45:05.644277	1	\N	2460.00	21.38.1	\N
1821	295	07957	\N	2	1	2026-03-01 11:45:05.644279	1	\N	2460.00	21.38.1	\N
1822	296	039514	\N	2	1	2026-03-01 11:45:05.64428	1	\N	2084.00	21.38.1	\N
1823	297	15Г1987	\N	1	1	2026-03-01 11:45:05.644281	1	\N	88193.20	07.2.1	\N
1824	297	15Г1988	\N	1	1	2026-03-01 11:45:05.644282	1	\N	88193.20	07.2.1	\N
1825	297	15Г1989	\N	1	1	2026-03-01 11:45:05.644283	1	\N	88193.20	07.2.1	\N
1826	297	15Г1990	\N	1	1	2026-03-01 11:45:05.644284	1	\N	88193.20	07.2.1	\N
1827	297	15Г1991	\N	1	1	2026-03-01 11:45:05.644286	1	\N	88193.20	07.2.1	\N
1828	297	15Г1992	\N	1	1	2026-03-01 11:45:05.644287	1	\N	88193.20	07.2.1	\N
1829	297	15Г1993	\N	1	1	2026-03-01 11:45:05.644288	1	\N	88193.20	07.2.1	\N
1830	297	15Г1994	\N	1	1	2026-03-01 11:45:05.644289	1	\N	88193.20	07.2.1	\N
1831	297	15Г1995	\N	1	1	2026-03-01 11:45:05.64429	1	\N	88193.20	07.2.1	\N
1832	297	15Г1996	\N	1	1	2026-03-01 11:45:05.644291	1	\N	88193.20	07.2.1	\N
1833	297	15Г1997	\N	1	1	2026-03-01 11:45:05.644293	1	\N	88193.20	07.2.1	\N
1834	297	15Г1998	\N	1	1	2026-03-01 11:45:05.644294	1	\N	88193.20	07.2.1	\N
1835	297	15Г1999	\N	1	1	2026-03-01 11:45:05.644295	1	\N	88193.20	07.2.1	\N
1836	297	15Г2000	\N	1	1	2026-03-01 11:45:05.644296	1	\N	88193.20	07.2.1	\N
1837	297	15Г2001	\N	1	1	2026-03-01 11:45:05.644297	1	\N	88193.20	07.2.1	\N
1838	298	А022238Z	\N	1	1	2026-03-01 11:45:05.644299	1	\N	150000.00	07.2.1	\N
1839	298	А022248Z	\N	1	1	2026-03-01 11:45:05.6443	1	\N	150000.00	07.2.1	\N
1840	298	А022254Z	\N	1	1	2026-03-01 11:45:05.644301	1	\N	150000.00	07.2.1	\N
1841	298	А022256Z	\N	1	1	2026-03-01 11:45:05.644302	1	\N	150000.00	07.2.1	\N
1842	298	А022257Z	\N	1	1	2026-03-01 11:45:05.644304	1	\N	150000.00	07.2.1	\N
1843	298	А022483Z	\N	1	1	2026-03-01 11:45:05.644305	1	\N	150000.00	07.2.1	\N
1844	298	А061550Z	\N	1	1	2026-03-01 11:45:05.644306	1	\N	150000.00	07.2.1	\N
1845	298	А061553Z	\N	1	1	2026-03-01 11:45:05.644307	1	\N	150000.00	07.2.1	\N
1846	298	А061555Z	\N	1	1	2026-03-01 11:45:05.644308	1	\N	150000.00	07.2.1	\N
1847	298	А061562Z	\N	1	1	2026-03-01 11:45:05.644309	1	\N	150000.00	07.2.1	\N
1848	299	YTU051	\N	1	1	2026-03-01 11:45:05.64431	1	\N	147666.00	07.2.1	\N
1849	300	YTV019	\N	1	1	2026-03-01 11:45:05.644312	1	\N	140166.66	07.2.1	\N
1850	301	Б/Н-1890	\N	1	1	2026-03-01 11:45:05.644313	1	\N	25000.00	07.2.1	\N
1851	302	ШК 0074	\N	1	1	2026-03-01 11:45:05.644314	1	\N	295000.00	07.2.1	\N
1852	303	для 9 мм пистолета Макарова	\N	1	1	2026-03-01 11:45:05.644315	1	\N	6000.00	07.2.1	\N
1853	304	Б/Н-1893	\N	1	1	2026-03-01 11:45:05.644316	1	\N	3750.00	07.2.1	\N
1854	305	Б/Н-1894	\N	1	1	2026-03-01 11:45:05.644317	1	\N	3750.00	07.2.1	\N
1855	306	Б/Н-1895	\N	1	1	2026-03-01 11:45:05.644319	1	\N	12000.00	07.2.1	\N
1856	307	ПМ	\N	1	1	2026-03-01 11:45:05.64432	1	\N	7000.00	07.2.1	\N
\.


--
-- Name: accounting_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounting_objects_id_seq', 3, true);


--
-- Name: arsenal_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.arsenal_users_id_seq', 8, true);


--
-- Name: document_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.document_items_id_seq', 1, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, true);


--
-- Name: gsm_accounting_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_accounting_objects_id_seq', 1, false);


--
-- Name: gsm_document_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_document_items_id_seq', 1, false);


--
-- Name: gsm_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_documents_id_seq', 1, false);


--
-- Name: gsm_fuel_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_fuel_registry_id_seq', 1, false);


--
-- Name: gsm_nomenclature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_nomenclature_id_seq', 1, false);


--
-- Name: gsm_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_users_id_seq', 4, true);


--
-- Name: nomenclature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nomenclature_id_seq', 307, true);


--
-- Name: weapon_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.weapon_registry_id_seq', 1856, true);


--
-- Name: accounting_objects accounting_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects
    ADD CONSTRAINT accounting_objects_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: arsenal_users arsenal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users
    ADD CONSTRAINT arsenal_users_pkey PRIMARY KEY (id);


--
-- Name: document_items document_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: gsm_accounting_objects gsm_accounting_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_accounting_objects
    ADD CONSTRAINT gsm_accounting_objects_pkey PRIMARY KEY (id);


--
-- Name: gsm_document_items gsm_document_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items
    ADD CONSTRAINT gsm_document_items_pkey PRIMARY KEY (id);


--
-- Name: gsm_documents gsm_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents
    ADD CONSTRAINT gsm_documents_pkey PRIMARY KEY (id);


--
-- Name: gsm_fuel_registry gsm_fuel_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry
    ADD CONSTRAINT gsm_fuel_registry_pkey PRIMARY KEY (id);


--
-- Name: gsm_nomenclature gsm_nomenclature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_nomenclature
    ADD CONSTRAINT gsm_nomenclature_pkey PRIMARY KEY (id);


--
-- Name: gsm_users gsm_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_users
    ADD CONSTRAINT gsm_users_pkey PRIMARY KEY (id);


--
-- Name: nomenclature nomenclature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nomenclature
    ADD CONSTRAINT nomenclature_pkey PRIMARY KEY (id);


--
-- Name: gsm_fuel_registry uix_gsm_nom_batch_obj; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry
    ADD CONSTRAINT uix_gsm_nom_batch_obj UNIQUE (nomenclature_id, batch_number, current_object_id);


--
-- Name: weapon_registry uix_nom_serial_obj; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT uix_nom_serial_obj UNIQUE (nomenclature_id, serial_number, current_object_id);


--
-- Name: weapon_registry weapon_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_pkey PRIMARY KEY (id);


--
-- Name: ix_accounting_objects_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_accounting_objects_id ON public.accounting_objects USING btree (id);


--
-- Name: ix_arsenal_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_arsenal_users_id ON public.arsenal_users USING btree (id);


--
-- Name: ix_arsenal_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_arsenal_users_username ON public.arsenal_users USING btree (username);


--
-- Name: ix_document_items_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_document_items_id ON public.document_items USING btree (id);


--
-- Name: ix_documents_doc_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_documents_doc_number ON public.documents USING btree (doc_number);


--
-- Name: ix_documents_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_documents_id ON public.documents USING btree (id);


--
-- Name: ix_gsm_accounting_objects_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_accounting_objects_id ON public.gsm_accounting_objects USING btree (id);


--
-- Name: ix_gsm_document_items_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_document_items_id ON public.gsm_document_items USING btree (id);


--
-- Name: ix_gsm_documents_doc_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_documents_doc_number ON public.gsm_documents USING btree (doc_number);


--
-- Name: ix_gsm_documents_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_documents_id ON public.gsm_documents USING btree (id);


--
-- Name: ix_gsm_fuel_registry_batch_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_fuel_registry_batch_number ON public.gsm_fuel_registry USING btree (batch_number);


--
-- Name: ix_gsm_fuel_registry_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_fuel_registry_id ON public.gsm_fuel_registry USING btree (id);


--
-- Name: ix_gsm_nomenclature_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_nomenclature_code ON public.gsm_nomenclature USING btree (code);


--
-- Name: ix_gsm_nomenclature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_nomenclature_id ON public.gsm_nomenclature USING btree (id);


--
-- Name: ix_gsm_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_users_id ON public.gsm_users USING btree (id);


--
-- Name: ix_gsm_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_gsm_users_username ON public.gsm_users USING btree (username);


--
-- Name: ix_nomenclature_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_nomenclature_code ON public.nomenclature USING btree (code);


--
-- Name: ix_nomenclature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_nomenclature_id ON public.nomenclature USING btree (id);


--
-- Name: ix_weapon_registry_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_weapon_registry_id ON public.weapon_registry USING btree (id);


--
-- Name: ix_weapon_registry_inventory_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_weapon_registry_inventory_number ON public.weapon_registry USING btree (inventory_number);


--
-- Name: ix_weapon_registry_serial_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_weapon_registry_serial_number ON public.weapon_registry USING btree (serial_number);


--
-- Name: accounting_objects accounting_objects_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects
    ADD CONSTRAINT accounting_objects_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.accounting_objects(id);


--
-- Name: arsenal_users arsenal_users_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users
    ADD CONSTRAINT arsenal_users_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.accounting_objects(id);


--
-- Name: document_items document_items_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: document_items document_items_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.nomenclature(id);


--
-- Name: document_items document_items_weapon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_weapon_id_fkey FOREIGN KEY (weapon_id) REFERENCES public.weapon_registry(id);


--
-- Name: documents documents_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.arsenal_users(id);


--
-- Name: documents documents_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.accounting_objects(id);


--
-- Name: documents documents_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.accounting_objects(id);


--
-- Name: gsm_accounting_objects gsm_accounting_objects_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_accounting_objects
    ADD CONSTRAINT gsm_accounting_objects_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: gsm_document_items gsm_document_items_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items
    ADD CONSTRAINT gsm_document_items_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.gsm_documents(id);


--
-- Name: gsm_document_items gsm_document_items_fuel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items
    ADD CONSTRAINT gsm_document_items_fuel_id_fkey FOREIGN KEY (fuel_id) REFERENCES public.gsm_fuel_registry(id);


--
-- Name: gsm_document_items gsm_document_items_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items
    ADD CONSTRAINT gsm_document_items_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.gsm_nomenclature(id);


--
-- Name: gsm_documents gsm_documents_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents
    ADD CONSTRAINT gsm_documents_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.gsm_users(id);


--
-- Name: gsm_documents gsm_documents_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents
    ADD CONSTRAINT gsm_documents_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: gsm_documents gsm_documents_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents
    ADD CONSTRAINT gsm_documents_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: gsm_fuel_registry gsm_fuel_registry_current_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry
    ADD CONSTRAINT gsm_fuel_registry_current_object_id_fkey FOREIGN KEY (current_object_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: gsm_fuel_registry gsm_fuel_registry_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry
    ADD CONSTRAINT gsm_fuel_registry_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.gsm_nomenclature(id);


--
-- Name: gsm_users gsm_users_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_users
    ADD CONSTRAINT gsm_users_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: weapon_registry weapon_registry_current_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_current_object_id_fkey FOREIGN KEY (current_object_id) REFERENCES public.accounting_objects(id);


--
-- Name: weapon_registry weapon_registry_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.nomenclature(id);


--
-- PostgreSQL database dump complete
--

\unrestrict H3Xd3VstfQAOftt4VfOQOBuQUgipoi4OoMz71BjWCJ80QvxIKkCeLo3uzqsKo3J

