--
-- PostgreSQL database dump
--

\restrict 4dXyMAadHP9UTw3k4KPdNJoI1nHwBnbSby4gEJIBdAohc6BOZPsxyLtv1aZ1Nhv

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounting_objects (
    id integer NOT NULL,
    parent_id integer,
    name character varying NOT NULL,
    obj_type character varying NOT NULL
);


ALTER TABLE public.accounting_objects OWNER TO postgres;

--
-- Name: accounting_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounting_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_objects_id_seq OWNER TO postgres;

--
-- Name: accounting_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounting_objects_id_seq OWNED BY public.accounting_objects.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: arsenal_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.arsenal_users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying,
    created_at timestamp without time zone,
    role character varying,
    object_id integer
);


ALTER TABLE public.arsenal_users OWNER TO postgres;

--
-- Name: arsenal_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.arsenal_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.arsenal_users_id_seq OWNER TO postgres;

--
-- Name: arsenal_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.arsenal_users_id_seq OWNED BY public.arsenal_users.id;


--
-- Name: document_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_items (
    id integer NOT NULL,
    document_id integer,
    nomenclature_id integer,
    serial_number character varying,
    quantity integer,
    weapon_id integer
);


ALTER TABLE public.document_items OWNER TO postgres;

--
-- Name: document_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.document_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_items_id_seq OWNER TO postgres;

--
-- Name: document_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.document_items_id_seq OWNED BY public.document_items.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    doc_number character varying,
    doc_date timestamp without time zone,
    operation_date timestamp without time zone,
    operation_type character varying NOT NULL,
    source_id integer,
    target_id integer,
    comment text,
    created_at timestamp without time zone,
    author_id integer
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documents_id_seq OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: gsm_accounting_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_accounting_objects (
    id integer NOT NULL,
    parent_id integer,
    name character varying NOT NULL,
    obj_type character varying NOT NULL
);


ALTER TABLE public.gsm_accounting_objects OWNER TO postgres;

--
-- Name: gsm_accounting_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_accounting_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_accounting_objects_id_seq OWNER TO postgres;

--
-- Name: gsm_accounting_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_accounting_objects_id_seq OWNED BY public.gsm_accounting_objects.id;


--
-- Name: gsm_document_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_document_items (
    id integer NOT NULL,
    document_id integer,
    fuel_id integer,
    nomenclature_id integer,
    batch_number character varying,
    quantity numeric(15,3)
);


ALTER TABLE public.gsm_document_items OWNER TO postgres;

--
-- Name: gsm_document_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_document_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_document_items_id_seq OWNER TO postgres;

--
-- Name: gsm_document_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_document_items_id_seq OWNED BY public.gsm_document_items.id;


--
-- Name: gsm_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_documents (
    id integer NOT NULL,
    doc_number character varying,
    doc_date timestamp without time zone,
    operation_date timestamp without time zone,
    operation_type character varying NOT NULL,
    source_id integer,
    target_id integer,
    comment text,
    created_at timestamp without time zone,
    author_id integer
);


ALTER TABLE public.gsm_documents OWNER TO postgres;

--
-- Name: gsm_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_documents_id_seq OWNER TO postgres;

--
-- Name: gsm_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_documents_id_seq OWNED BY public.gsm_documents.id;


--
-- Name: gsm_fuel_registry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_fuel_registry (
    id integer NOT NULL,
    nomenclature_id integer NOT NULL,
    batch_number character varying NOT NULL,
    density numeric(10,4),
    current_object_id integer,
    status integer,
    quantity numeric(15,3),
    created_at timestamp without time zone
);


ALTER TABLE public.gsm_fuel_registry OWNER TO postgres;

--
-- Name: gsm_fuel_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_fuel_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_fuel_registry_id_seq OWNER TO postgres;

--
-- Name: gsm_fuel_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_fuel_registry_id_seq OWNED BY public.gsm_fuel_registry.id;


--
-- Name: gsm_nomenclature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_nomenclature (
    id integer NOT NULL,
    code character varying,
    name character varying NOT NULL,
    category character varying,
    is_packaged boolean NOT NULL
);


ALTER TABLE public.gsm_nomenclature OWNER TO postgres;

--
-- Name: gsm_nomenclature_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_nomenclature_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_nomenclature_id_seq OWNER TO postgres;

--
-- Name: gsm_nomenclature_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_nomenclature_id_seq OWNED BY public.gsm_nomenclature.id;


--
-- Name: gsm_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gsm_users (
    id integer NOT NULL,
    username character varying,
    hashed_password character varying,
    role character varying,
    object_id integer,
    created_at timestamp without time zone
);


ALTER TABLE public.gsm_users OWNER TO postgres;

--
-- Name: gsm_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gsm_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gsm_users_id_seq OWNER TO postgres;

--
-- Name: gsm_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gsm_users_id_seq OWNED BY public.gsm_users.id;


--
-- Name: nomenclature; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nomenclature (
    id integer NOT NULL,
    code character varying,
    name character varying NOT NULL,
    category character varying,
    is_numbered boolean DEFAULT true NOT NULL
);


ALTER TABLE public.nomenclature OWNER TO postgres;

--
-- Name: nomenclature_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nomenclature_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nomenclature_id_seq OWNER TO postgres;

--
-- Name: nomenclature_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nomenclature_id_seq OWNED BY public.nomenclature.id;


--
-- Name: weapon_registry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weapon_registry (
    id integer NOT NULL,
    nomenclature_id integer NOT NULL,
    serial_number character varying NOT NULL,
    year_of_manufacture integer,
    current_object_id integer,
    status integer,
    created_at timestamp without time zone,
    quantity integer
);


ALTER TABLE public.weapon_registry OWNER TO postgres;

--
-- Name: weapon_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.weapon_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.weapon_registry_id_seq OWNER TO postgres;

--
-- Name: weapon_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.weapon_registry_id_seq OWNED BY public.weapon_registry.id;


--
-- Name: accounting_objects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects ALTER COLUMN id SET DEFAULT nextval('public.accounting_objects_id_seq'::regclass);


--
-- Name: arsenal_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users ALTER COLUMN id SET DEFAULT nextval('public.arsenal_users_id_seq'::regclass);


--
-- Name: document_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items ALTER COLUMN id SET DEFAULT nextval('public.document_items_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: gsm_accounting_objects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_accounting_objects ALTER COLUMN id SET DEFAULT nextval('public.gsm_accounting_objects_id_seq'::regclass);


--
-- Name: gsm_document_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items ALTER COLUMN id SET DEFAULT nextval('public.gsm_document_items_id_seq'::regclass);


--
-- Name: gsm_documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents ALTER COLUMN id SET DEFAULT nextval('public.gsm_documents_id_seq'::regclass);


--
-- Name: gsm_fuel_registry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry ALTER COLUMN id SET DEFAULT nextval('public.gsm_fuel_registry_id_seq'::regclass);


--
-- Name: gsm_nomenclature id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_nomenclature ALTER COLUMN id SET DEFAULT nextval('public.gsm_nomenclature_id_seq'::regclass);


--
-- Name: gsm_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_users ALTER COLUMN id SET DEFAULT nextval('public.gsm_users_id_seq'::regclass);


--
-- Name: nomenclature id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nomenclature ALTER COLUMN id SET DEFAULT nextval('public.nomenclature_id_seq'::regclass);


--
-- Name: weapon_registry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry ALTER COLUMN id SET DEFAULT nextval('public.weapon_registry_id_seq'::regclass);


--
-- Data for Name: accounting_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounting_objects (id, parent_id, name, obj_type) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
74cc2ed1171b
\.


--
-- Data for Name: arsenal_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.arsenal_users (id, username, hashed_password, created_at, role, object_id) FROM stdin;
1	admin	$argon2id$v=19$m=65536,t=2,p=2$17pX6j2n1Hov5TwHYAzBmA$/zOEwFkbn+LNMBvlYTwoHhVczj4fCqoyZw0iprbSY0w	2026-02-27 11:25:55.870727	unit_head	\N
\.


--
-- Data for Name: document_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_items (id, document_id, nomenclature_id, serial_number, quantity, weapon_id) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, doc_number, doc_date, operation_date, operation_type, source_id, target_id, comment, created_at, author_id) FROM stdin;
\.


--
-- Data for Name: gsm_accounting_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_accounting_objects (id, parent_id, name, obj_type) FROM stdin;
\.


--
-- Data for Name: gsm_document_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_document_items (id, document_id, fuel_id, nomenclature_id, batch_number, quantity) FROM stdin;
\.


--
-- Data for Name: gsm_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_documents (id, doc_number, doc_date, operation_date, operation_type, source_id, target_id, comment, created_at, author_id) FROM stdin;
\.


--
-- Data for Name: gsm_fuel_registry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_fuel_registry (id, nomenclature_id, batch_number, density, current_object_id, status, quantity, created_at) FROM stdin;
\.


--
-- Data for Name: gsm_nomenclature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_nomenclature (id, code, name, category, is_packaged) FROM stdin;
\.


--
-- Data for Name: gsm_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gsm_users (id, username, hashed_password, role, object_id, created_at) FROM stdin;
\.


--
-- Data for Name: nomenclature; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nomenclature (id, code, name, category, is_numbered) FROM stdin;
\.


--
-- Data for Name: weapon_registry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weapon_registry (id, nomenclature_id, serial_number, year_of_manufacture, current_object_id, status, created_at, quantity) FROM stdin;
\.


--
-- Name: accounting_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounting_objects_id_seq', 1, false);


--
-- Name: arsenal_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.arsenal_users_id_seq', 1, true);


--
-- Name: document_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.document_items_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: gsm_accounting_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_accounting_objects_id_seq', 1, false);


--
-- Name: gsm_document_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_document_items_id_seq', 1, false);


--
-- Name: gsm_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_documents_id_seq', 1, false);


--
-- Name: gsm_fuel_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_fuel_registry_id_seq', 1, false);


--
-- Name: gsm_nomenclature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_nomenclature_id_seq', 1, false);


--
-- Name: gsm_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gsm_users_id_seq', 1, false);


--
-- Name: nomenclature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nomenclature_id_seq', 1, false);


--
-- Name: weapon_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.weapon_registry_id_seq', 1, false);


--
-- Name: accounting_objects accounting_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects
    ADD CONSTRAINT accounting_objects_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: arsenal_users arsenal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users
    ADD CONSTRAINT arsenal_users_pkey PRIMARY KEY (id);


--
-- Name: document_items document_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: gsm_accounting_objects gsm_accounting_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_accounting_objects
    ADD CONSTRAINT gsm_accounting_objects_pkey PRIMARY KEY (id);


--
-- Name: gsm_document_items gsm_document_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items
    ADD CONSTRAINT gsm_document_items_pkey PRIMARY KEY (id);


--
-- Name: gsm_documents gsm_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents
    ADD CONSTRAINT gsm_documents_pkey PRIMARY KEY (id);


--
-- Name: gsm_fuel_registry gsm_fuel_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry
    ADD CONSTRAINT gsm_fuel_registry_pkey PRIMARY KEY (id);


--
-- Name: gsm_nomenclature gsm_nomenclature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_nomenclature
    ADD CONSTRAINT gsm_nomenclature_pkey PRIMARY KEY (id);


--
-- Name: gsm_users gsm_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_users
    ADD CONSTRAINT gsm_users_pkey PRIMARY KEY (id);


--
-- Name: nomenclature nomenclature_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nomenclature
    ADD CONSTRAINT nomenclature_pkey PRIMARY KEY (id);


--
-- Name: gsm_fuel_registry uix_gsm_nom_batch_obj; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry
    ADD CONSTRAINT uix_gsm_nom_batch_obj UNIQUE (nomenclature_id, batch_number, current_object_id);


--
-- Name: weapon_registry uix_nom_serial_obj; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT uix_nom_serial_obj UNIQUE (nomenclature_id, serial_number, current_object_id);


--
-- Name: weapon_registry weapon_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_pkey PRIMARY KEY (id);


--
-- Name: ix_accounting_objects_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_accounting_objects_id ON public.accounting_objects USING btree (id);


--
-- Name: ix_arsenal_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_arsenal_users_id ON public.arsenal_users USING btree (id);


--
-- Name: ix_arsenal_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_arsenal_users_username ON public.arsenal_users USING btree (username);


--
-- Name: ix_document_items_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_document_items_id ON public.document_items USING btree (id);


--
-- Name: ix_documents_doc_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_documents_doc_number ON public.documents USING btree (doc_number);


--
-- Name: ix_documents_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_documents_id ON public.documents USING btree (id);


--
-- Name: ix_gsm_accounting_objects_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_accounting_objects_id ON public.gsm_accounting_objects USING btree (id);


--
-- Name: ix_gsm_document_items_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_document_items_id ON public.gsm_document_items USING btree (id);


--
-- Name: ix_gsm_documents_doc_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_documents_doc_number ON public.gsm_documents USING btree (doc_number);


--
-- Name: ix_gsm_documents_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_documents_id ON public.gsm_documents USING btree (id);


--
-- Name: ix_gsm_fuel_registry_batch_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_fuel_registry_batch_number ON public.gsm_fuel_registry USING btree (batch_number);


--
-- Name: ix_gsm_fuel_registry_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_fuel_registry_id ON public.gsm_fuel_registry USING btree (id);


--
-- Name: ix_gsm_nomenclature_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_nomenclature_code ON public.gsm_nomenclature USING btree (code);


--
-- Name: ix_gsm_nomenclature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_nomenclature_id ON public.gsm_nomenclature USING btree (id);


--
-- Name: ix_gsm_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_gsm_users_id ON public.gsm_users USING btree (id);


--
-- Name: ix_gsm_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_gsm_users_username ON public.gsm_users USING btree (username);


--
-- Name: ix_nomenclature_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_nomenclature_code ON public.nomenclature USING btree (code);


--
-- Name: ix_nomenclature_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_nomenclature_id ON public.nomenclature USING btree (id);


--
-- Name: ix_weapon_registry_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_weapon_registry_id ON public.weapon_registry USING btree (id);


--
-- Name: ix_weapon_registry_serial_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_weapon_registry_serial_number ON public.weapon_registry USING btree (serial_number);


--
-- Name: accounting_objects accounting_objects_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_objects
    ADD CONSTRAINT accounting_objects_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.accounting_objects(id);


--
-- Name: arsenal_users arsenal_users_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arsenal_users
    ADD CONSTRAINT arsenal_users_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.accounting_objects(id);


--
-- Name: document_items document_items_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: document_items document_items_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.nomenclature(id);


--
-- Name: document_items document_items_weapon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_weapon_id_fkey FOREIGN KEY (weapon_id) REFERENCES public.weapon_registry(id);


--
-- Name: documents documents_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.arsenal_users(id);


--
-- Name: documents documents_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.accounting_objects(id);


--
-- Name: documents documents_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.accounting_objects(id);


--
-- Name: gsm_accounting_objects gsm_accounting_objects_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_accounting_objects
    ADD CONSTRAINT gsm_accounting_objects_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: gsm_document_items gsm_document_items_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items
    ADD CONSTRAINT gsm_document_items_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.gsm_documents(id);


--
-- Name: gsm_document_items gsm_document_items_fuel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items
    ADD CONSTRAINT gsm_document_items_fuel_id_fkey FOREIGN KEY (fuel_id) REFERENCES public.gsm_fuel_registry(id);


--
-- Name: gsm_document_items gsm_document_items_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_document_items
    ADD CONSTRAINT gsm_document_items_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.gsm_nomenclature(id);


--
-- Name: gsm_documents gsm_documents_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents
    ADD CONSTRAINT gsm_documents_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.gsm_users(id);


--
-- Name: gsm_documents gsm_documents_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents
    ADD CONSTRAINT gsm_documents_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: gsm_documents gsm_documents_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_documents
    ADD CONSTRAINT gsm_documents_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: gsm_fuel_registry gsm_fuel_registry_current_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry
    ADD CONSTRAINT gsm_fuel_registry_current_object_id_fkey FOREIGN KEY (current_object_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: gsm_fuel_registry gsm_fuel_registry_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_fuel_registry
    ADD CONSTRAINT gsm_fuel_registry_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.gsm_nomenclature(id);


--
-- Name: gsm_users gsm_users_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gsm_users
    ADD CONSTRAINT gsm_users_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.gsm_accounting_objects(id);


--
-- Name: weapon_registry weapon_registry_current_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_current_object_id_fkey FOREIGN KEY (current_object_id) REFERENCES public.accounting_objects(id);


--
-- Name: weapon_registry weapon_registry_nomenclature_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weapon_registry
    ADD CONSTRAINT weapon_registry_nomenclature_id_fkey FOREIGN KEY (nomenclature_id) REFERENCES public.nomenclature(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 4dXyMAadHP9UTw3k4KPdNJoI1nHwBnbSby4gEJIBdAohc6BOZPsxyLtv1aZ1Nhv

